// Pearl OTC — shared UI primitives.
// Use plain function components. Names start with Pearl* to avoid collisions.

const { SAMPLE, STATE_BADGES, FAILURE_BANNERS, TL_EVENTS } = window.PearlData;

// ─── Browser chrome (subtle URL bar) ─────────────────────────────────────────
function Chrome({ path = "/quote" }) {
  return (
    <div className="chrome">
      <div className="chrome-dots">
        <span className="chrome-dot" />
        <span className="chrome-dot" />
        <span className="chrome-dot" />
      </div>
      <div className="chrome-url">
        <span className="scheme">https://</span>
        <span style={{ color: 'var(--ink-2)' }}>otc.pearl.dev</span>
        <span className="path">{path}</span>
      </div>
    </div>
  );
}

// ─── Top nav (app chrome) ────────────────────────────────────────────────────
function TopNav({ active = "trade", env = "testnet", role = "buyer" }) {
  const items = [
    { id: "offers",   label: "Offers",     href: "/offers" },
    { id: "quote",    label: "Quote",      href: "/quote" },
    { id: "trade",    label: "Trades",     href: "/trades" },
    { id: "my",       label: "My quotes",  href: "/my-quotes" },
    { id: "docs",     label: "Docs",       href: "/docs" },
  ];
  return (
    <div className="topnav">
      <div className="logo" style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
        <span className="glyph" />
        <span style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
          <span style={{ fontWeight: 600, fontSize: 14, letterSpacing: '-0.2px' }}>PRL Settlement Desk</span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--muted-2)', letterSpacing: 0.5, textTransform: 'uppercase', marginTop: 2 }}>by Oysters</span>
        </span>
      </div>
      <span className="env-pill">{env}</span>
      <nav>
        {items.map(i => (
          <a key={i.id} className={i.id === active ? "active" : ""} href="#">{i.label}</a>
        ))}
      </nav>
      <div className="spacer" />
      <div className="user">
        <span>desk@kaspacom</span>
        <span className="avatar">D</span>
      </div>
    </div>
  );
}

function AdminTopNav({ active = "trades" }) {
  return (
    <div className="topnav" style={{ background: '#1a1a17', borderBottom: '1px solid #2a2a25' }}>
      <div className="logo" style={{ color: '#fff', display: 'flex', alignItems: 'center', gap: 9 }}>
        <span className="glyph" />
        <span style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
          <span style={{ fontWeight: 600, fontSize: 14, letterSpacing: '-0.2px' }}>PRL Settlement Desk <span style={{ color: '#9a988f', fontWeight: 400 }}>· admin</span></span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: '#9a988f', letterSpacing: 0.5, textTransform: 'uppercase', marginTop: 2 }}>by Oysters</span>
        </span>
      </div>
      <span className="env-pill" style={{ background: 'transparent', color: '#e6d4a8', borderColor: '#5a4e2a' }}>testnet</span>
      <nav>
        {[
          { id: "trades", label: "Trades" },
          { id: "manual", label: "Manual review" },
          { id: "audit",  label: "Audit log" },
          { id: "ops",    label: "Operators" },
        ].map(i => (
          <a key={i.id} href="#" className={i.id === active ? "active" : ""}
             style={{ color: i.id === active ? '#fff' : '#9a988f' }}>{i.label}</a>
        ))}
      </nav>
      <div className="spacer" />
      <div className="user" style={{ color: '#9a988f' }}>
        <span>op_07 · marcus.q</span>
        <span className="avatar" style={{ background: '#c4a87a', color: '#1a1a17' }}>MQ</span>
      </div>
    </div>
  );
}

// ─── State badge ─────────────────────────────────────────────────────────────
function StateBadge({ state }) {
  const cfg = STATE_BADGES[state] || { tone: "neutral", label: state };
  return (
    <span className={`badge ${cfg.tone}`}>
      <span className="dot" />
      {cfg.label}
    </span>
  );
}

// ─── Network chip ────────────────────────────────────────────────────────────
function NetChip({ chain = "pearl", env = "testnet2" }) {
  const labels = {
    "pearl-main":  { name: "PRL · mainnet",   sq: "#2a2a25" },
    "pearl-test":  { name: "PRL · testnet2",  sq: "#8a6418" },
    "base-main":   { name: "BASE · mainnet",  sq: "#2c4a78" },
    "base-test":   { name: "BASE · sepolia",  sq: "#2c4a78" },
  };
  const key = `${chain}-${env.startsWith("test") || env === "sepolia" ? "test" : "main"}`;
  const c = labels[key] || labels["pearl-test"];
  return (
    <span className="chip">
      <span className="sq" style={{ background: c.sq }} />
      {c.name}
    </span>
  );
}

// ─── Copy icon (visual only) ─────────────────────────────────────────────────
function CopyIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.2">
      <rect x="3" y="3" width="6.5" height="6.5" rx="1" />
      <path d="M2 7V2.5A.5.5 0 0 1 2.5 2H7" />
    </svg>
  );
}

// ─── Address pill ────────────────────────────────────────────────────────────
function Addr({ value, mono = true }) {
  return (
    <div className="addr">
      <span>{value}</span>
      <span className="copy" title="Copy"><CopyIcon /></span>
    </div>
  );
}

// ─── Amount (big, with int/frac split) ───────────────────────────────────────
function AmountBig({ whole, frac, unit, plain }) {
  if (plain) {
    const m = plain.match(/^([\d,]+)(\.[\d_]+)?$/);
    if (m) { whole = m[1]; frac = m[2] || ''; }
  }
  return (
    <div className="amount-big">
      <span>{whole}</span>
      <span className="frac">{frac}</span>
      {unit && <span className="unit">{unit}</span>}
    </div>
  );
}
function AmountMed({ whole, frac, unit }) {
  return (
    <span className="amount-med">
      <span>{whole}</span>
      <span className="frac">{frac}</span>
      {unit && <span className="unit">{unit}</span>}
    </span>
  );
}

// ─── Trade ID (sticky header) ────────────────────────────────────────────────
function TradeId({ id = SAMPLE.tradeId }) {
  return (
    <span className="mono" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--ink)' }}>
      <span style={{ color: 'var(--muted-2)' }}>trade</span>
      {id}
      <span style={{ color: 'var(--muted-2)', cursor: 'pointer' }}><CopyIcon /></span>
    </span>
  );
}

// ─── Countdown deadline pill ─────────────────────────────────────────────────
function fmtCD(secs) {
  if (secs <= 0) return "expired";
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = secs % 60;
  if (h > 0) return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}

function Countdown({ label, value, secs, tone = "" }) {
  // Static display only — no live ticking (was causing perf issues across 80+ countdowns).
  const display = (typeof secs === 'number') ? fmtCD(secs) : value;
  return (
    <div className={`cd ${tone}`} title={`Absolute: 2026-05-17 15:00 UTC`}>
      <span className="lbl">{label}</span>
      <span className="val">{display}</span>
    </div>
  );
}

// ─── Banner (failure / info) ─────────────────────────────────────────────────
function Banner({ tone = "err", title, body, action = "Contact support" }) {
  const icon = {
    err: "⚠",
    warn: "⚠",
    info: "ℹ",
    neutral: "—",
  }[tone];
  return (
    <div className={`banner ${tone}`}>
      <span className="ic" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-mono)', fontWeight: 600 }}>{icon}</span>
      <div className="body">
        <strong>{title}</strong>
        {body && <div className="lede">{body}</div>}
      </div>
      {action && <a href="#" style={{ alignSelf: 'flex-start', whiteSpace: 'nowrap', fontWeight: 500, fontSize: 12 }}>{action} →</a>}
    </div>
  );
}

function FailureBanner({ state }) {
  const b = FAILURE_BANNERS[state];
  if (!b) return null;
  return (
    <Banner
      tone={b.tone}
      title={b.head}
      body={`Trade ${SAMPLE.tradeId} · contact desk@pearl.dev with this trade id and the state name above.`}
    />
  );
}

// ─── Timeline row ────────────────────────────────────────────────────────────
function Timeline({ events }) {
  const icon = (chain) => {
    if (chain === 'pearl') return { cls: 'pearl', char: 'P' };
    if (chain === 'base')  return { cls: 'base',  char: 'B' };
    if (chain === 'ok')    return { cls: 'ok',    char: '✓' };
    if (chain === 'err')   return { cls: 'err',   char: '!' };
    return { cls: 'pearl', char: '·' };
  };
  return (
    <div className="timeline">
      {events.map((e, i) => {
        const ic = icon(e.chain);
        return (
          <div className="tl-row" key={i}>
            <div className={`tl-icon ${ic.cls}`}>{ic.char}</div>
            <div className="tl-body">
              <div className="ev">{e.ev}</div>
              {e.meta && <div className="meta">{e.meta}</div>}
            </div>
            <div className="tl-time">{e.time}</div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Sticky header (deadlines + state) ───────────────────────────────────────
function TradeHeader({ state = "pearl_escrow_pending", deadlines = SAMPLE.deadlines, tradeId = SAMPLE.tradeId }) {
  // mark some deadlines as warn/done based on state
  const expired = ["late_prl_funding","quote_expired"].includes(state);
  const allDone = ["released","refunded"].includes(state);
  return (
    <div style={{
      padding: '14px 28px 16px',
      background: 'var(--surface)',
      borderBottom: '1px solid var(--hairline)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 12 }}>
        <TradeId id={tradeId} />
        <StateBadge state={state} />
        <div style={{ flex: 1 }} />
        <span className="muted" style={{ fontSize: 11 }}>accepted <span className="mono">{SAMPLE.acceptedAt}</span></span>
      </div>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        <Countdown label="quote_expires" value="—" tone="done" />
        <Countdown label="pearl_funding"
          value={state === 'late_prl_funding' ? '−00:04:21' : undefined}
          secs={state === 'late_prl_funding' ? undefined : (allDone ? undefined : 23 * 60 + 14)}
          tone={state === 'late_prl_funding' ? 'err' : (allDone ? 'done' : '')} />
        <Countdown label="usdc_deposit"
          secs={['released','refunded','usdc_refunded'].includes(state) ? undefined : 19 * 60 + 47}
          value={['released','refunded'].includes(state) ? deadlines.usdcDeposit : (state === 'usdc_refunded' ? '−12:08' : undefined)}
          tone={['released','refunded'].includes(state) ? 'done' : (state === 'usdc_refunded' ? 'err' : '')} />
        <Countdown label="settlement"
          secs={allDone ? undefined : 60 * 60 + 43 * 60 + 2}
          value={allDone ? deadlines.settlement : undefined}
          tone={allDone ? 'done' : ''} />
        <Countdown label="refund_available" value={state === 'refund_available' ? "now" : "01:13:44"}
          tone={state === 'refund_available' ? 'warn' : ''} />
      </div>
    </div>
  );
}

// ─── Pearl card (chain leg) ──────────────────────────────────────────────────
function PearlCard({ status = 'pending', confirmations = 0, withTx = false }) {
  const statusMap = {
    pending:   { badge: <span className="badge neutral"><span className="dot" />Awaiting funding</span>, conf: '0 / 6' },
    seen:      { badge: <span className="badge accent"><span className="dot" />Funding observed</span>,  conf: `${confirmations} / 6` },
    confirmed: { badge: <span className="badge ok"><span className="dot" />Funding confirmed</span>, conf: '6 / 6' },
    late:      { badge: <span className="badge err"><span className="dot" />Funded after deadline</span>, conf: '6 / 6' },
    released:  { badge: <span className="badge ok"><span className="dot" />Released to buyer</span>, conf: '6 / 6' },
    refunded:  { badge: <span className="badge warn"><span className="dot" />Refunded</span>, conf: '6 / 6' },
    mismatch:  { badge: <span className="badge err"><span className="dot" />Amount mismatch</span>, conf: '6 / 6' },
    reorged:   { badge: <span className="badge warn"><span className="dot" />Reorg detected</span>, conf: '3 / 6' },
    unknown:   { badge: <span className="badge err"><span className="dot" />Unknown spend</span>, conf: '—' },
  };
  const s = statusMap[status] || statusMap.pending;
  const showTx = withTx || ['confirmed','seen','released','refunded','late','mismatch','reorged','unknown'].includes(status);

  return (
    <div className="card">
      <div className="card-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span className="h2">Pearl leg</span>
          <NetChip chain="pearl" env="testnet2" />
        </div>
        {s.badge}
      </div>
      <div className="card-pad">
        <div className="eyebrow" style={{ marginBottom: 6 }}>escrow address</div>
        <Addr value={SAMPLE.pearlAddr} />

        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginTop: 16 }}>
          <div>
            <div className="eyebrow" style={{ marginBottom: 4 }}>expected amount</div>
            <AmountBig whole="12,500" frac=".00000000" unit="PRL" />
          </div>
          <div style={{ textAlign: 'right', fontSize: 11.5, color: 'var(--muted)' }}>
            <div className="mono">{s.conf}</div>
            <div>confirmations</div>
          </div>
        </div>

        {/* Pearl Wallet slot */}
        <div style={{
          marginTop: 16,
          padding: '11px 12px',
          background: 'var(--paper-2)',
          border: '1px dashed var(--neutral-line)',
          borderRadius: 'var(--r-2)',
          display: 'flex', alignItems: 'flex-start', gap: 10,
        }}>
          <div style={{ width: 22, height: 22, borderRadius: 4, background: 'var(--neutral-soft)', border: '1px solid var(--neutral-line)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--neutral)' }}>P</span>
          </div>
          <div style={{ fontSize: 11.5, lineHeight: 1.5, color: 'var(--ink-2)' }}>
            <strong style={{ fontWeight: 600 }}>Pearl Desktop Wallet</strong>
            <span className="muted"> · MVP placeholder</span>
            <div className="muted" style={{ marginTop: 2 }}>
              Open your Pearl Desktop Wallet and send the amount above to this address. <a href="#" style={{ color: 'var(--accent)' }}>Help →</a>
            </div>
          </div>
        </div>

        {showTx && (
          <div style={{ marginTop: 16 }}>
            <div className="eyebrow" style={{ marginBottom: 4 }}>funding transaction</div>
            <div className="mono" style={{ fontSize: 11, color: 'var(--accent)' }}>
              <a href="#" style={{ color: 'inherit' }}>{SAMPLE.fundTxid.slice(0,12)}…{SAMPLE.fundTxid.slice(-8)}</a>
              <span style={{ color: 'var(--muted-2)', marginLeft: 8 }}>↗ block explorer</span>
            </div>
          </div>
        )}

        {status === 'released' && (
          <div style={{ marginTop: 8 }}>
            <div className="eyebrow" style={{ marginBottom: 4 }}>release transaction</div>
            <div className="mono" style={{ fontSize: 11, color: 'var(--accent)' }}>
              <a href="#" style={{ color: 'inherit' }}>{SAMPLE.releaseTxid.slice(0,12)}…{SAMPLE.releaseTxid.slice(-8)}</a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Base card (chain leg) ───────────────────────────────────────────────────
function BaseCard({ status = 'awaiting', wallet = 'connected', network = 'right' }) {
  // status: nowallet | wrongchain | awaiting | submitting | pending | confirming | confirmed | refunded
  let cta, ctaTone = 'accent', ctaDisabled = false;
  let confLine = '0 / 12 confirmations';

  if (status === 'nowallet')      cta = "Connect wallet";
  else if (status === 'wrongchain'){ cta = "Switch to Base Sepolia"; ctaTone = 'primary'; }
  else if (status === 'awaiting') cta = "Deposit USDC";
  else if (status === 'submitting') cta = <><span className="spin" />Submitting — confirm in wallet…</>;
  else if (status === 'pending')  { cta = "Deposit submitted ↗"; ctaDisabled = true; confLine = '0 / 12 confirmations'; }
  else if (status === 'confirming'){ cta = "Deposit confirmed ✓"; ctaDisabled = true; confLine = '4 / 12 confirmations'; }
  else if (status === 'confirmed') { cta = "Deposit confirmed ✓"; ctaDisabled = true; confLine = '12 / 12 confirmations'; }
  else if (status === 'refunded')  { cta = "USDC refunded"; ctaDisabled = true; confLine = 'refund 12 / 12 confirmations'; ctaTone = 'primary'; }
  else if (status === 'closed')    { cta = "Deposit window closed"; ctaDisabled = true; }

  const walletPill = {
    connected:    <span className="pill ok"><span className="dot" />wallet · 0x7a4c…8a4E</span>,
    disconnected: <span className="pill"><span className="dot" />wallet · disconnected</span>,
  }[wallet];
  const netPill = {
    right: <span className="pill ok"><span className="dot" />network · base-sepolia</span>,
    wrong: <span className="pill warn"><span className="dot" />network · wrong chain</span>,
    none:  <span className="pill"><span className="dot" />network · —</span>,
  }[network];
  const allowPill = {
    awaiting:  <span className="pill"><span className="dot" />allowance · pending</span>,
    confirmed: <span className="pill ok"><span className="dot" />allowance · granted</span>,
    refunded:  <span className="pill ok"><span className="dot" />allowance · granted</span>,
  }[status] || <span className="pill"><span className="dot" />allowance · —</span>;

  return (
    <div className="card">
      <div className="card-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span className="h2">Base leg</span>
          <NetChip chain="base" env="sepolia" />
        </div>
        {(status === 'confirmed' || status === 'pending' || status === 'confirming') ? (
          <span className="badge ok"><span className="dot" />Funded</span>
        ) : status === 'refunded' ? (
          <span className="badge warn"><span className="dot" />Refunded</span>
        ) : (
          <span className="badge neutral"><span className="dot" />Awaiting USDC</span>
        )}
      </div>
      <div className="card-pad">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div>
            <div className="eyebrow" style={{ marginBottom: 6 }}>escrow contract</div>
            <Addr value={SAMPLE.baseEscrow} />
          </div>
          <div>
            <div className="eyebrow" style={{ marginBottom: 6 }}>trade key</div>
            <Addr value={SAMPLE.tradeKey} />
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginTop: 16 }}>
          <div>
            <div className="eyebrow" style={{ marginBottom: 4 }}>expected amount</div>
            <AmountBig whole="8,237" frac=".500000" unit="USDC" />
          </div>
          <div style={{ textAlign: 'right', fontSize: 11.5, color: 'var(--muted)' }}>
            <div className="mono">{confLine.split(' ')[0]} / 12</div>
            <div>confirmations</div>
          </div>
        </div>

        <div style={{ marginTop: 16 }}>
          <button className={`btn lg ${ctaTone}`} disabled={ctaDisabled}
            style={{ width: '100%', justifyContent: 'center' }}>
            {cta}
          </button>
          <div className="pillrow" style={{ marginTop: 10 }}>
            {walletPill}{netPill}{allowPill}
          </div>
        </div>

        {(status === 'pending' || status === 'confirming' || status === 'confirmed') && (
          <div style={{ marginTop: 16 }}>
            <div className="eyebrow" style={{ marginBottom: 4 }}>deposit transaction</div>
            <div className="mono" style={{ fontSize: 11, color: 'var(--accent)' }}>
              <a href="#" style={{ color: 'inherit' }}>{SAMPLE.depositHash.slice(0,14)}…{SAMPLE.depositHash.slice(-8)}</a>
              <span style={{ color: 'var(--muted-2)', marginLeft: 8 }}>↗ basescan</span>
            </div>
          </div>
        )}
        {status === 'refunded' && (
          <div style={{ marginTop: 16 }}>
            <div className="eyebrow" style={{ marginBottom: 4 }}>refund transaction</div>
            <div className="mono" style={{ fontSize: 11, color: 'var(--accent)' }}>
              <a href="#" style={{ color: 'inherit' }}>{SAMPLE.refundHash.slice(0,14)}…{SAMPLE.refundHash.slice(-8)}</a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Quote summary card (used in /quote and /accept) ─────────────────────────
function QuoteSummary({ expired = false }) {
  return (
    <div className="card" style={{ background: 'var(--surface-2)' }}>
      <div className="card-header">
        <span className="h2">Quote</span>
        {expired ? (
          <span className="badge neutral"><span className="dot" />expired</span>
        ) : (
          <span className="muted" style={{ fontSize: 11, display: 'flex', alignItems: 'center', gap: 5 }}>
            <ClockIcon /> expires in <span className="mono" style={{ color: 'var(--warn)' }}>00:42</span>
          </span>
        )}
      </div>
      <div className="card-pad" style={{ paddingTop: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, marginBottom: 14 }}>
          <div>
            <div className="eyebrow" style={{ marginBottom: 4 }}>you receive</div>
            <AmountBig whole="12,500" frac=".00000000" unit="PRL" />
          </div>
          <div>
            <div className="eyebrow" style={{ marginBottom: 4 }}>you pay</div>
            <AmountBig whole="8,237" frac=".500000" unit="USDC" />
          </div>
        </div>
        <dl className="kv">
          <dt>price</dt>
          <dd className="mono">0.659000 <span className="muted">USDC / PRL</span></dd>
          <dt>fee (PRL leg)</dt>
          <dd className="mono">12.50000000 PRL</dd>
          <dt>fee (USDC leg)</dt>
          <dd className="mono">8.235000 USDC</dd>
          <dt>settlement</dt>
          <dd><NetChip chain="base" env="sepolia" /> · USDC</dd>
        </dl>
      </div>
    </div>
  );
}

function ClockIcon() {
  return (
    <svg width="11" height="11" viewBox="0 0 11 11" fill="none" stroke="currentColor" strokeWidth="1.2">
      <circle cx="5.5" cy="5.5" r="4.5" />
      <path d="M5.5 3v2.7l1.7 1" strokeLinecap="round" />
    </svg>
  );
}

// ─── Annotation (yellow callout) ─────────────────────────────────────────────
function Annot({ children, top, left, right, bottom, arrow = 'tl-arrow', width }) {
  return (
    <div className={`annot ${arrow}`} style={{ top, left, right, bottom, width }}>
      {children}
    </div>
  );
}

// ─── Page shell ──────────────────────────────────────────────────────────────
function PageShell({ path, role = 'buyer', env = 'testnet', adminChrome = false, children }) {
  return (
    <div className="pearl" style={{ display: 'flex', flexDirection: 'column' }}>
      <Chrome path={path} />
      {adminChrome ? <AdminTopNav /> : <TopNav env={env} role={role} />}
      <div style={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
        {children}
      </div>
    </div>
  );
}

Object.assign(window, {
  Chrome, TopNav, AdminTopNav, PageShell,
  StateBadge, NetChip, CopyIcon, Addr, AmountBig, AmountMed,
  TradeId, Countdown, Banner, FailureBanner,
  Timeline, TradeHeader,
  PearlCard, BaseCard, QuoteSummary, ClockIcon,
  Annot,
});
