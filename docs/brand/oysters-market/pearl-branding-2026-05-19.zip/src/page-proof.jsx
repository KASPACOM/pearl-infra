// /trades/:tradeId/proof — Public verifiable receipt.
// Read-only · dense · prints well to PDF. No auth required.

function ProofHeader({ state = 'released' }) {
  return (
    <div style={{
      background: 'var(--surface)',
      borderBottom: '1px solid var(--hairline)',
      padding: '20px 56px 22px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <span className="topnav-glyph" style={{
            width: 22, height: 22, borderRadius: '50%',
            background: 'radial-gradient(circle at 35% 35%, #fff 0%, #ecebe1 30%, #cfcdb8 60%, #8b8973 100%)',
            boxShadow: 'inset 0 0 0 0.5px rgba(0,0,0,.12)',
          }} />
          <span style={{ fontWeight: 600, fontSize: 14, letterSpacing: -0.2 }}>Pearl OTC</span>
        </div>
        <span className="muted" style={{ fontSize: 11 }}>· public proof page</span>
        <div style={{ flex: 1 }} />
        <span className="muted" style={{ fontSize: 11, display: 'flex', alignItems: 'center', gap: 8 }}>
          generated <span className="mono" style={{ color: 'var(--ink-2)' }}>2026-05-17T15:01:43Z</span>
        </span>
        <button className="btn sm">↓ download PDF</button>
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
        <div>
          <div className="eyebrow" style={{ marginBottom: 6 }}>trade · {SAMPLE.tradeId}</div>
          <h1 className="h1" style={{ fontSize: 20 }}>
            Verifiable receipt &mdash;
            <span className="mono" style={{ color: 'var(--muted)', fontSize: 13, marginLeft: 8, fontWeight: 400 }}>{SAMPLE.tradeId}</span>
          </h1>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <StateBadge state={state} />
        </div>
      </div>
    </div>
  );
}

function ProofSection({ title, num, children, style }) {
  return (
    <section style={{ marginBottom: 32, ...style }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 12,
                    paddingBottom: 8, borderBottom: '1px solid var(--hairline)' }}>
        <span className="mono" style={{ fontSize: 11, color: 'var(--muted-2)' }}>{num}</span>
        <h2 className="h2" style={{ fontSize: 14 }}>{title}</h2>
      </div>
      {children}
    </section>
  );
}

// Reusable kv-row table
function FactTable({ rows }) {
  return (
    <table className="tbl" style={{ tableLayout: 'fixed' }}>
      <colgroup>
        <col style={{ width: 200 }} />
        <col />
      </colgroup>
      <tbody>
        {rows.map(([k, v, link], i) => (
          <tr key={i}>
            <td style={{ color: 'var(--muted)', fontWeight: 500 }}>{k}</td>
            <td className="mono" style={{ wordBreak: 'break-all', fontSize: 11.5, color: link ? 'var(--accent)' : 'var(--ink)' }}>
              {link ? <a href="#" style={{ color: 'inherit' }}>{v}</a> : v}
              {link && <span style={{ color: 'var(--muted-2)', marginLeft: 8 }}>↗</span>}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

// Side-effect ledger — every recorded action
const SIDE_EFFECTS_FULL = [
  { idem: 'sfx_01J5K8B2A1', actor: 'indexer:pearl', effect: 'pearl_deposit_observed',  txid: 'f3c1a9…f1a2', status: 'ok',  at: '2026-05-17T14:24:11Z' },
  { idem: 'sfx_01J5K8B2A2', actor: 'indexer:pearl', effect: 'pearl_deposit_confirmed', txid: 'f3c1a9…f1a2', status: 'ok',  at: '2026-05-17T14:29:33Z' },
  { idem: 'sfx_01J5K8B2A3', actor: 'indexer:base',  effect: 'usdc_deposit_observed',   txid: '0xc4d5…c4d5', status: 'ok',  at: '2026-05-17T14:36:08Z' },
  { idem: 'sfx_01J5K8B2A4', actor: 'indexer:base',  effect: 'usdc_deposit_confirmed',  txid: '0xc4d5…c4d5', status: 'ok',  at: '2026-05-17T14:39:22Z' },
  { idem: 'sfx_01J5K8B2A5', actor: 'desk:authorize',effect: 'release_authorized',      txid: '—',           status: 'ok',  at: '2026-05-17T14:42:01Z' },
  { idem: 'sfx_01J5K8B2A6', actor: 'desk:broadcast',effect: 'pearl_release_submitted', txid: 'a7b8c9…a7b8', status: 'ok',  at: '2026-05-17T14:42:14Z' },
  { idem: 'sfx_01J5K8B2A7', actor: 'desk:broadcast',effect: 'usdc_release_submitted',  txid: '0xa1b2…a1b2', status: 'ok',  at: '2026-05-17T14:42:21Z' },
  { idem: 'sfx_01J5K8B2A8', actor: 'indexer:pearl', effect: 'pearl_release_confirmed', txid: 'a7b8c9…a7b8', status: 'ok',  at: '2026-05-17T14:44:18Z' },
  { idem: 'sfx_01J5K8B2A9', actor: 'indexer:base',  effect: 'usdc_release_confirmed',  txid: '0xa1b2…a1b2', status: 'ok',  at: '2026-05-17T14:45:11Z' },
];

const SIDE_EFFECTS_INPROG = SIDE_EFFECTS_FULL.slice(0, 4);

const SIDE_EFFECTS_REFUNDED = [
  ...SIDE_EFFECTS_FULL.slice(0, 4),
  { idem: 'sfx_01J5K8C5R1', actor: 'desk:refund',   effect: 'refund_requested',       txid: '—',           status: 'ok',  at: '2026-05-17T15:34:08Z' },
  { idem: 'sfx_01J5K8C5R2', actor: 'desk:broadcast',effect: 'usdc_refund_submitted',  txid: '0xe5f6…e5f6', status: 'ok',  at: '2026-05-17T15:34:21Z' },
  { idem: 'sfx_01J5K8C5R3', actor: 'indexer:base',  effect: 'usdc_refund_confirmed',  txid: '0xe5f6…e5f6', status: 'ok',  at: '2026-05-17T15:38:44Z' },
];

const SIDE_EFFECTS_FAIL = [
  ...SIDE_EFFECTS_FULL.slice(0, 4),
  { idem: 'sfx_01J5K8D1F1', actor: 'desk:authorize',effect: 'release_authorized',     txid: '—',           status: 'ok',  at: '2026-05-17T14:42:01Z' },
  { idem: 'sfx_01J5K8D1F2', actor: 'desk:broadcast',effect: 'pearl_release_submitted',txid: '—',           status: 'err', at: '2026-05-17T14:42:14Z' },
  { idem: 'sfx_01J5K8D1F3', actor: 'desk:retry',    effect: 'pearl_release_retry_1',  txid: '—',           status: 'err', at: '2026-05-17T14:43:11Z' },
  { idem: 'sfx_01J5K8D1F4', actor: 'desk:retry',    effect: 'pearl_release_retry_2',  txid: '—',           status: 'err', at: '2026-05-17T14:44:14Z' },
  { idem: 'sfx_01J5K8D1F5', actor: 'desk:retry',    effect: 'pearl_release_retry_3',  txid: '—',           status: 'err', at: '2026-05-17T14:45:14Z' },
  { idem: 'sfx_01J5K8D1F6', actor: 'desk:flag',     effect: 'flagged_for_review',     txid: '—',           status: 'ok',  at: '2026-05-17T14:45:20Z' },
];

function SideEffectsTable({ rows }) {
  return (
    <table className="tbl">
      <thead>
        <tr>
          <th style={{ width: 150 }}>idempotency</th>
          <th style={{ width: 130 }}>actor</th>
          <th>effect</th>
          <th>tx</th>
          <th style={{ width: 70 }}>status</th>
          <th style={{ width: 180 }}>at</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r, i) => (
          <tr key={i}>
            <td className="mono" style={{ fontSize: 11 }}>{r.idem}</td>
            <td className="mono" style={{ fontSize: 11, color: 'var(--muted)' }}>{r.actor}</td>
            <td className="mono" style={{ fontSize: 11 }}>{r.effect}</td>
            <td className="mono" style={{ fontSize: 11, color: r.txid !== '—' ? 'var(--accent)' : 'var(--muted-2)' }}>
              {r.txid !== '—' ? <a href="#" style={{ color: 'inherit' }}>{r.txid}</a> : '—'}
            </td>
            <td>
              {r.status === 'ok'
                ? <span className="badge ok" style={{ fontSize: 9.5 }}><span className="dot" />ok</span>
                : <span className="badge err" style={{ fontSize: 9.5 }}><span className="dot" />err</span>}
            </td>
            <td className="mono" style={{ fontSize: 11, color: 'var(--muted)' }}>{r.at}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function ProofLayout({
  state = 'released',
  banner,
  pearlFundedAt = '2026-05-17T14:24:11Z',
  pearlConfirmedAt = '2026-05-17T14:29:33Z',
  pearlReleaseAt = '2026-05-17T14:42:14Z',
  pearlRefundAt,
  baseDepositAt = '2026-05-17T14:36:08Z',
  baseReleaseAt = '2026-05-17T14:42:21Z',
  baseRefundAt,
  sideEffects = SIDE_EFFECTS_FULL,
  events,
}) {
  return (
    <div className="pearl" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <Chrome path={`/trades/${SAMPLE.tradeId}/proof`} />
      <ProofHeader state={state} />
      <div style={{ flex: 1, overflow: 'auto', padding: '28px 56px 60px', background: 'var(--paper)' }}>
        {banner && <div style={{ marginBottom: 24 }}>{banner}</div>}

        <ProofSection title="Quote terms" num="01">
          <FactTable rows={[
            ['side',           'BUY · buyer receives PRL, pays USDC'],
            ['amount (PRL)',   '12,500.00000000  PRL'],
            ['amount (USDC)',  '8,237.500000     USDC'],
            ['fee (PRL leg)',  '12.50000000      PRL'],
            ['fee (USDC leg)', '8.235000         USDC'],
            ['price',          '0.659000  USDC/PRL'],
            ['quote_id',       'qte_01J5K8AB2'],
            ['accepted_at',    '2026-05-17T14:22:08Z'],
          ]} />
        </ProofSection>

        <ProofSection title="Deadlines" num="02">
          <table className="tbl">
            <thead>
              <tr>
                <th style={{ width: 200 }}>deadline</th>
                <th>absolute (ISO 8601)</th>
                <th style={{ width: 200 }}>relative to acceptance</th>
                <th style={{ width: 100 }}>status</th>
              </tr>
            </thead>
            <tbody>
              {[
                ['quoteExpiresAt',       '2026-05-17T14:22:26Z', 'accept + 0:00:18', 'expired'],
                ['pearlFundingDeadline', '2026-05-17T14:42:08Z', 'accept + 0:20:00', state === 'released' ? 'met' : (state === 'refunded' || state === 'refund_available' ? 'missed' : 'pending')],
                ['usdcDepositDeadline',  '2026-05-17T14:52:08Z', 'accept + 0:30:00', state === 'released' || state === 'refunded' ? 'met' : 'pending'],
                ['settlementDeadline',   '2026-05-17T16:22:08Z', 'accept + 2:00:00', state === 'released' ? 'met' : 'pending'],
                ['refundAvailableAt',    '2026-05-17T15:22:08Z', 'accept + 1:00:00', state === 'refunded' ? 'used' : (state === 'refund_available' ? 'open' : 'closed')],
              ].map(([name, iso, rel, st]) => (
                <tr key={name}>
                  <td className="mono" style={{ fontSize: 11.5 }}>{name}</td>
                  <td className="mono" style={{ fontSize: 11 }}>{iso}</td>
                  <td className="mono" style={{ fontSize: 11, color: 'var(--muted)' }}>{rel}</td>
                  <td>
                    <span className={`badge ${st === 'met' ? 'ok' : st === 'missed' ? 'err' : st === 'expired' || st === 'used' ? 'neutral' : st === 'open' ? 'warn' : 'neutral'}`} style={{ fontSize: 9.5 }}>
                      <span className="dot" />{st}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </ProofSection>

        <ProofSection title="Pearl leg facts" num="03">
          <FactTable rows={[
            ['network',           'pearl · testnet2 · chain id  pearl_testnet2'],
            ['escrow address',    SAMPLE.pearlAddr],
            ['expected amount',   '12,500.00000000 PRL'],
            ['confirmations req', '6'],
            ['funding outpoint',  pearlFundedAt ? `${SAMPLE.fundTxid}:0` : '—', !!pearlFundedAt],
            ['funded at',         pearlFundedAt || '—'],
            ['confirmed at',      pearlConfirmedAt || '—'],
            pearlReleaseAt
              ? ['release tx',      SAMPLE.releaseTxid, true]
              : ['release tx',      '—'],
            pearlRefundAt
              ? ['refund tx',       SAMPLE.refundTxid, true]
              : ['refund tx',       '—'],
          ]} />
        </ProofSection>

        <ProofSection title="Base leg facts" num="04">
          <FactTable rows={[
            ['network',          'base · sepolia · chain id 84532'],
            ['escrow contract',  SAMPLE.baseEscrow, true],
            ['trade key',        SAMPLE.tradeKeyFull],
            ['expected amount',  '8,237.500000 USDC'],
            ['confirmations req','12'],
            baseDepositAt ? ['deposit tx', SAMPLE.depositHash, true] : ['deposit tx', '—'],
            ['deposit confirmed at', baseDepositAt || '—'],
            baseReleaseAt ? ['release tx', SAMPLE.releaseHash, true] : ['release tx', '—'],
            baseRefundAt ? ['refund tx', SAMPLE.refundHash, true]  : ['refund tx',  '—'],
          ]} />
        </ProofSection>

        <ProofSection title="State transition timeline" num="05">
          <Timeline events={events || TL_EVENTS.released} />
        </ProofSection>

        <ProofSection title="Side-effect ledger" num="06"
                      style={{ marginBottom: 36 }}>
          <SideEffectsTable rows={sideEffects} />
        </ProofSection>

        <div style={{
          paddingTop: 18, borderTop: '1px solid var(--hairline)',
          fontSize: 11, color: 'var(--muted)', lineHeight: 1.6,
          display: 'flex', alignItems: 'center', gap: 18,
        }}>
          <span className="mono">otc.pearl.dev/trades/{SAMPLE.tradeId}/proof</span>
          <span>·</span>
          <span>This receipt is reproduced from the desk's append-only event log. Every txid links to a public chain explorer for independent verification.</span>
        </div>
      </div>
    </div>
  );
}

// ── Variants ────────────────────────────────────────────────────────────────

const ProofHappy = () => (
  <ProofLayout
    state="released"
    events={TL_EVENTS.released}
    sideEffects={SIDE_EFFECTS_FULL}
  />
);

const ProofInProgress = () => (
  <ProofLayout
    state="pearl_escrow_confirmed"
    pearlReleaseAt={null}
    pearlConfirmedAt="2026-05-17T14:29:33Z"
    baseDepositAt={null}
    baseReleaseAt={null}
    events={TL_EVENTS.pearl_seen}
    sideEffects={SIDE_EFFECTS_INPROG}
  />
);

const ProofRefunded = () => (
  <ProofLayout
    state="refunded"
    pearlFundedAt={null}
    pearlConfirmedAt={null}
    pearlReleaseAt={null}
    baseRefundAt="2026-05-17T15:38:44Z"
    baseReleaseAt={null}
    sideEffects={SIDE_EFFECTS_REFUNDED}
    events={[
      { chain: 'sys', ev: 'Quote accepted; escrows allocated', meta: '14:22:08 UTC', time: '' },
      { chain: 'base', ev: 'USDC deposit confirmed', meta: '12/12 confirmations', time: '' },
      { chain: 'err', ev: 'pearl_funding deadline crossed', meta: 'no Pearl deposit observed', time: '' },
      { chain: 'sys', ev: 'Refund requested by buyer', meta: '15:34:08 UTC', time: '' },
      { chain: 'base', ev: 'USDC refund confirmed', meta: '0xe5f6…e5f6 · 12/12 confirmations', time: '' },
      { chain: 'ok', ev: 'Trade refunded · terminal', meta: 'ledger closed at 15:38:44 UTC', time: '' },
    ]}
  />
);

const ProofFailure = () => (
  <ProofLayout
    state="prl_release_failed"
    banner={<FailureBanner state="prl_release_failed" />}
    pearlReleaseAt={null}
    sideEffects={SIDE_EFFECTS_FAIL}
    events={[
      { chain: 'sys', ev: 'Quote accepted; escrows allocated', meta: '14:22:08 UTC', time: '' },
      { chain: 'pearl', ev: 'Pearl deposit confirmed', meta: '6/6 confirmations', time: '' },
      { chain: 'base', ev: 'USDC deposit confirmed', meta: '12/12 confirmations', time: '' },
      { chain: 'sys', ev: 'Release authorized', meta: 'idempotency 0x7e…2a', time: '' },
      { chain: 'err', ev: 'PRL release broadcast failed (3 retries)', meta: 'utxo_already_spent', time: '' },
      { chain: 'err', ev: 'State entered: prl_release_failed', meta: 'manual review queued', time: '' },
    ]}
  />
);

window.PageProof = {
  variants: [
    { id: 'happy',       label: 'happy · completed trade',          Page: ProofHappy,      height: 1820 },
    { id: 'in-progress', label: 'in progress · partial facts',      Page: ProofInProgress, height: 1500 },
    { id: 'refunded',    label: 'refunded · terminal',              Page: ProofRefunded,   height: 1700 },
    { id: 'failure',     label: 'failure · prl_release_failed',     Page: ProofFailure,    height: 1820 },
  ],
};
