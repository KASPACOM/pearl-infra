// ═══ src/design-canvas.jsx ═══

// DesignCanvas.jsx — Figma-ish design canvas wrapper
// Warm gray grid bg + Sections + Artboards + PostIt notes.
// Artboards are reorderable (grip-drag), deletable, labels/titles are
// inline-editable, and any artboard can be opened in a fullscreen focus
// overlay (←/→/Esc). State persists to a .design-canvas.state.json sidecar
// via the host bridge. No assets, no deps.
//
// Usage:
//   <DesignCanvas>
//     <DCSection id="onboarding" title="Onboarding" subtitle="First-run variants">
//       <DCArtboard id="a" label="A · Dusk" width={260} height={480}>…</DCArtboard>
//       <DCArtboard id="b" label="B · Minimal" width={260} height={480}>…</DCArtboard>
//     </DCSection>
//   </DesignCanvas>

const DC = {
  bg: '#f0eee9',
  grid: 'rgba(0,0,0,0.06)',
  label: 'rgba(60,50,40,0.7)',
  title: 'rgba(40,30,20,0.85)',
  subtitle: 'rgba(60,50,40,0.6)',
  postitBg: '#fef4a8',
  postitText: '#5a4a2a',
  font: '-apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif'
};

// One-time CSS injection (classes are dc-prefixed so they don't collide with
// the hosted design's own styles).
if (typeof document !== 'undefined' && !document.getElementById('dc-styles')) {
  const s = document.createElement('style');
  s.id = 'dc-styles';
  s.textContent = ['.dc-editable{cursor:text;outline:none;white-space:nowrap;border-radius:3px;padding:0 2px;margin:0 -2px}', '.dc-editable:focus{background:#fff;box-shadow:0 0 0 1.5px #c96442}', '[data-dc-slot]{transition:transform .18s cubic-bezier(.2,.7,.3,1)}', '[data-dc-slot].dc-dragging{transition:none;z-index:10;pointer-events:none}', '[data-dc-slot].dc-dragging .dc-card{box-shadow:0 12px 40px rgba(0,0,0,.25),0 0 0 2px #c96442;transform:scale(1.02)}',
  // isolation:isolate contains artboard content's z-indexes so a
  // z-indexed child (sticky navbar etc.) can't paint over .dc-header or
  // the .dc-menu popover that drops into the top of the card.
  '.dc-card{isolation:isolate;transition:box-shadow .15s,transform .15s}', '.dc-card *{scrollbar-width:none}', '.dc-card *::-webkit-scrollbar{display:none}',
  // Per-artboard header: grip + label on the left, delete/expand on the
  // right. Single flex row; when the artboard's on-screen width is too
  // narrow for both the label yields (ellipsis, then hidden entirely below
  // ~4ch via the container query) and the buttons stay on the row.
  '.dc-header{position:absolute;bottom:100%;left:-4px;margin-bottom:calc(4px * var(--dc-inv-zoom,1));z-index:2;', '  display:flex;align-items:center;container-type:inline-size}', '.dc-labelrow{display:flex;align-items:center;gap:4px;height:24px;flex:1 1 auto;min-width:0}', '.dc-grip{flex:0 0 auto;cursor:grab;display:flex;align-items:center;padding:5px 4px;border-radius:4px;transition:background .12s,opacity .12s}', '.dc-grip:hover{background:rgba(0,0,0,.08)}', '.dc-grip:active{cursor:grabbing}', '.dc-labeltext{flex:1 1 auto;min-width:0;cursor:pointer;border-radius:4px;padding:3px 6px;', '  display:flex;align-items:center;transition:background .12s;overflow:hidden}',
  // Below ~4ch of label room: hide the label entirely, and drop the grip to
  // hover-only (same reveal rule as .dc-btns) so a narrow header is clean
  // until the card is moused.
  '@container (max-width: 110px){', '  .dc-labeltext{display:none}', '  .dc-grip{opacity:0}', '  [data-dc-slot]:hover .dc-grip{opacity:1}', '}', '.dc-labeltext:hover{background:rgba(0,0,0,.05)}', '.dc-labeltext .dc-editable{overflow:hidden;text-overflow:ellipsis;max-width:100%}', '.dc-labeltext .dc-editable:focus{overflow:visible;text-overflow:clip}', '.dc-btns{flex:0 0 auto;margin-left:auto;display:flex;gap:2px;opacity:0;transition:opacity .12s}', '[data-dc-slot]:hover .dc-btns,.dc-btns:has(.dc-menu){opacity:1}', '.dc-expand,.dc-kebab{width:22px;height:22px;border-radius:5px;border:none;cursor:pointer;padding:0;', '  background:transparent;color:rgba(60,50,40,.7);display:flex;align-items:center;justify-content:center;', '  font:inherit;transition:background .12s,color .12s}', '.dc-expand:hover,.dc-kebab:hover{background:rgba(0,0,0,.06);color:#2a251f}',
  // Slot hosting an open menu floats above later siblings (which otherwise
  // paint on top — same z-index:auto, later DOM order) so the popup isn't
  // clipped by the next card.
  '[data-dc-slot]:has(.dc-menu){z-index:10}', '.dc-menu{position:absolute;top:100%;right:0;margin-top:4px;background:#fff;border-radius:8px;', '  box-shadow:0 8px 28px rgba(0,0,0,.18),0 0 0 1px rgba(0,0,0,.05);padding:4px;min-width:160px;z-index:10}', '.dc-menu button{display:block;width:100%;padding:7px 10px;border:0;background:transparent;', '  border-radius:5px;font-family:inherit;font-size:13px;font-weight:500;line-height:1.2;', '  color:#29261b;cursor:pointer;text-align:left;transition:background .12s;white-space:nowrap}', '.dc-menu button:hover{background:rgba(0,0,0,.05)}', '.dc-menu hr{border:0;border-top:1px solid rgba(0,0,0,.08);margin:4px 2px}', '.dc-menu .dc-danger{color:#c96442}', '.dc-menu .dc-danger:hover{background:rgba(201,100,66,.1)}',
  // Chrome (titles / labels / buttons) counter-scales against the viewport
  // zoom so it stays a constant on-screen size. --dc-inv-zoom is set by
  // DCViewport on every transform update and inherits to all descendants —
  // any overlay inside the world (e.g. a TweaksPanel on an artboard) can use
  // it the same way.
  //
  // The header uses transform:scale (out-of-flow, so layout impact doesn't
  // matter) with its world-space width set to card-width / inv-zoom so that
  // after counter-scaling its on-screen width exactly matches the card's —
  // that's what lets the container query + text-overflow behave against the
  // card's visible edge at every zoom level.
  //
  // The section head uses CSS zoom instead of transform so its layout box
  // grows with the counter-scale, pushing the card row down — otherwise the
  // constant-screen-size title would overflow into the (shrinking) world-
  // space gap and overlap the artboard headers at low zoom.
  '.dc-header{width:calc((100% + 4px) / var(--dc-inv-zoom,1));', '  transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom left}', '.dc-sectionhead{zoom:var(--dc-inv-zoom,1)}'].join('\n');
  document.head.appendChild(s);
}
const DCCtx = React.createContext(null);

// Recursively unwrap React.Fragment so <>…</> grouping doesn't hide
// DCSection/DCArtboard children from the type-based walks below.
function dcFlatten(children) {
  const out = [];
  React.Children.forEach(children, c => {
    if (c && c.type === React.Fragment) out.push(...dcFlatten(c.props.children));else out.push(c);
  });
  return out;
}

// ─────────────────────────────────────────────────────────────
// DesignCanvas — stateful wrapper around the pan/zoom viewport.
// Owns runtime state (per-section order, renamed titles/labels, hidden
// artboards, focused artboard). Order/titles/labels/hidden persist to a
// .design-canvas.state.json
// sidecar next to the HTML. Reads go via plain fetch() so the saved
// arrangement is visible anywhere the HTML + sidecar are served together
// (omelette preview, direct link, downloaded zip). Writes go through the
// host's window.omelette bridge — editing requires the omelette runtime.
// Focus is ephemeral.
// ─────────────────────────────────────────────────────────────
const DC_STATE_FILE = '.design-canvas.state.json';
function DesignCanvas({
  children,
  minScale,
  maxScale,
  style
}) {
  const [state, setState] = React.useState({
    sections: {},
    focus: null
  });
  // Hold rendering until the sidecar read settles so the saved order/titles
  // appear on first paint (no source-order flash). didRead gates writes until
  // the read settles so the empty initial state can't clobber a slow read;
  // skipNextWrite suppresses the one echo-write that would otherwise follow
  // hydration.
  const [ready, setReady] = React.useState(false);
  const didRead = React.useRef(false);
  const skipNextWrite = React.useRef(false);
  React.useEffect(() => {
    let off = false;
    fetch('./' + DC_STATE_FILE).then(r => r.ok ? r.json() : null).then(saved => {
      if (off || !saved || !saved.sections) return;
      skipNextWrite.current = true;
      setState(s => ({
        ...s,
        sections: saved.sections
      }));
    }).catch(() => {}).finally(() => {
      didRead.current = true;
      if (!off) setReady(true);
    });
    const t = setTimeout(() => {
      if (!off) setReady(true);
    }, 150);
    return () => {
      off = true;
      clearTimeout(t);
    };
  }, []);
  React.useEffect(() => {
    if (!didRead.current) return;
    if (skipNextWrite.current) {
      skipNextWrite.current = false;
      return;
    }
    const t = setTimeout(() => {
      window.omelette?.writeFile(DC_STATE_FILE, JSON.stringify({
        sections: state.sections
      })).catch(() => {});
    }, 250);
    return () => clearTimeout(t);
  }, [state.sections]);

  // Build registries synchronously from children so FocusOverlay can read
  // them in the same render. Fragments are flattened; wrapping in other
  // elements still opts out of focus/reorder.
  const registry = {}; // slotId -> { sectionId, artboard }
  const sectionMeta = {}; // sectionId -> { title, subtitle, slotIds[] }
  const sectionOrder = [];
  dcFlatten(children).forEach(sec => {
    if (!sec || sec.type !== DCSection) return;
    const sid = sec.props.id ?? sec.props.title;
    if (!sid) return;
    sectionOrder.push(sid);
    const persisted = state.sections[sid] || {};
    const abs = [];
    dcFlatten(sec.props.children).forEach(ab => {
      if (!ab || ab.type !== DCArtboard) return;
      const aid = ab.props.id ?? ab.props.label;
      if (aid) abs.push([aid, ab]);
    });
    // hidden is scoped to one source revision — when the agent regenerates
    // (artboard-ID set changes), prior deletes don't apply to new content.
    const srcKey = abs.map(([k]) => k).join('\x1f');
    const hidden = persisted.srcKey === srcKey ? persisted.hidden || [] : [];
    const srcIds = [];
    abs.forEach(([aid, ab]) => {
      if (hidden.includes(aid)) return;
      registry[`${sid}/${aid}`] = {
        sectionId: sid,
        artboard: ab
      };
      srcIds.push(aid);
    });
    const kept = (persisted.order || []).filter(k => srcIds.includes(k));
    sectionMeta[sid] = {
      title: persisted.title ?? sec.props.title,
      subtitle: sec.props.subtitle,
      slotIds: [...kept, ...srcIds.filter(k => !kept.includes(k))]
    };
  });
  const api = React.useMemo(() => ({
    state,
    section: id => state.sections[id] || {},
    patchSection: (id, p) => setState(s => ({
      ...s,
      sections: {
        ...s.sections,
        [id]: {
          ...s.sections[id],
          ...(typeof p === 'function' ? p(s.sections[id] || {}) : p)
        }
      }
    })),
    setFocus: slotId => setState(s => ({
      ...s,
      focus: slotId
    }))
  }), [state]);

  // Esc exits focus; any outside pointerdown commits an in-progress rename.
  React.useEffect(() => {
    const onKey = e => {
      if (e.key === 'Escape') api.setFocus(null);
    };
    const onPd = e => {
      const ae = document.activeElement;
      if (ae && ae.isContentEditable && !ae.contains(e.target)) ae.blur();
    };
    document.addEventListener('keydown', onKey);
    document.addEventListener('pointerdown', onPd, true);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('pointerdown', onPd, true);
    };
  }, [api]);
  return /*#__PURE__*/React.createElement(DCCtx.Provider, {
    value: api
  }, /*#__PURE__*/React.createElement(DCViewport, {
    minScale: minScale,
    maxScale: maxScale,
    style: style
  }, ready && children), state.focus && registry[state.focus] && /*#__PURE__*/React.createElement(DCFocusOverlay, {
    entry: registry[state.focus],
    sectionMeta: sectionMeta,
    sectionOrder: sectionOrder
  }));
}

// ─────────────────────────────────────────────────────────────
// DCViewport — transform-based pan/zoom (internal)
//
// Input mapping (Figma-style):
//   • trackpad pinch  → zoom   (ctrlKey wheel; Safari gesture* events)
//   • trackpad scroll → pan    (two-finger)
//   • mouse wheel     → zoom   (notched; distinguished from trackpad scroll)
//   • middle-drag / primary-drag-on-bg → pan
//
// Transform state lives in a ref and is written straight to the DOM
// (translate3d + will-change) so wheel ticks don't go through React —
// keeps pans at 60fps on dense canvases.
// ─────────────────────────────────────────────────────────────
function DCViewport({
  children,
  minScale = 0.1,
  maxScale = 8,
  style = {}
}) {
  const vpRef = React.useRef(null);
  const worldRef = React.useRef(null);
  const tf = React.useRef({
    x: 0,
    y: 0,
    scale: 1
  });
  // Persist viewport across reloads so the user lands back where they were
  // after an agent edit or browser refresh. The sandbox origin is already
  // per-project; pathname keeps multiple canvas files in one project apart.
  const tfKey = 'dc-viewport:' + location.pathname;
  const saveT = React.useRef(0);
  const lastPostedScale = React.useRef();
  const apply = React.useCallback(() => {
    const {
      x,
      y,
      scale
    } = tf.current;
    const el = worldRef.current;
    if (!el) return;
    el.style.transform = `translate3d(${x}px, ${y}px, 0) scale(${scale})`;
    // Exposed for zoom-invariant chrome (labels, buttons, TweaksPanel).
    el.style.setProperty('--dc-inv-zoom', String(1 / scale));
    // Keep the host toolbar's % readout in sync with the canvas scale. Pan
    // ticks leave scale unchanged — skip the cross-frame post for those.
    if (lastPostedScale.current !== scale) {
      lastPostedScale.current = scale;
      window.parent.postMessage({
        type: '__dc_zoom',
        scale
      }, '*');
    }
    clearTimeout(saveT.current);
    saveT.current = setTimeout(() => {
      try {
        localStorage.setItem(tfKey, JSON.stringify(tf.current));
      } catch {}
    }, 200);
  }, [tfKey]);
  React.useLayoutEffect(() => {
    const flush = () => {
      clearTimeout(saveT.current);
      try {
        localStorage.setItem(tfKey, JSON.stringify(tf.current));
      } catch {}
    };
    try {
      const s = JSON.parse(localStorage.getItem(tfKey) || 'null');
      if (s && Number.isFinite(s.x) && Number.isFinite(s.y) && Number.isFinite(s.scale)) {
        // Safety: if saved position would strand content off-screen
        // (e.g. stale state from old canvas content), reset to defaults.
        const offScreen = Math.abs(s.x) > 20000 || Math.abs(s.y) > 20000;
        if (!offScreen) {
          tf.current = {
            x: s.x,
            y: s.y,
            scale: Math.min(maxScale, Math.max(minScale, s.scale))
          };
          apply();
        } else {
          try {
            localStorage.removeItem(tfKey);
          } catch {}
        }
      }
    } catch {}
    // Flush on pagehide and unmount so a reload within the 200ms debounce
    // window doesn't drop the last pan/zoom.
    window.addEventListener('pagehide', flush);
    return () => {
      window.removeEventListener('pagehide', flush);
      flush();
    };
  }, []);
  React.useEffect(() => {
    const vp = vpRef.current;
    if (!vp) return;
    const zoomAt = (cx, cy, factor) => {
      const r = vp.getBoundingClientRect();
      const px = cx - r.left,
        py = cy - r.top;
      const t = tf.current;
      const next = Math.min(maxScale, Math.max(minScale, t.scale * factor));
      const k = next / t.scale;
      // --dc-inv-zoom consumers (.dc-sectionhead's CSS zoom, each section's
      // marginBottom) reflow on every scale change, vertically shifting the
      // world layout — so a world point mathematically pinned under the cursor
      // drifts as you zoom (content creeps up on zoom-in, down on zoom-out).
      // Anchor the DOM element under the cursor instead: record its screen Y,
      // apply the transform + --dc-inv-zoom, then cancel whatever vertical
      // drift the reflow introduced so it stays put on screen.
      let marker = null,
        markerY0 = 0;
      if (k !== 1) {
        const hit = document.elementFromPoint(cx, cy);
        marker = hit && hit.closest ? hit.closest('[data-dc-slot],[data-dc-section]') : null;
        if (marker) markerY0 = marker.getBoundingClientRect().top;
      }
      // keep the world point under the cursor fixed
      t.x = px - (px - t.x) * k;
      t.y = py - (py - t.y) * k;
      t.scale = next;
      apply();
      if (marker) {
        // A pure zoom around (cx, cy) maps screen Y → cy + (Y - cy) * k. Any
        // departure after the --dc-inv-zoom reflow is the layout drift.
        const drift = marker.getBoundingClientRect().top - (cy + (markerY0 - cy) * k);
        if (Math.abs(drift) > 0.1) {
          t.y -= drift;
          apply();
        }
      }
    };

    // Mouse-wheel vs trackpad-scroll heuristic. A physical wheel sends
    // line-mode deltas (Firefox) or large integer pixel deltas with no X
    // component (Chrome/Safari, typically multiples of 100/120). Trackpad
    // two-finger scroll sends small/fractional pixel deltas, often with
    // non-zero deltaX. ctrlKey is set by the browser for trackpad pinch.
    const isMouseWheel = e => e.deltaMode !== 0 || e.deltaX === 0 && Number.isInteger(e.deltaY) && Math.abs(e.deltaY) >= 40;
    const onWheel = e => {
      e.preventDefault();
      if (isGesturing) return; // Safari: gesture* owns the pinch — discard concurrent wheels
      if ((e.ctrlKey || e.metaKey) && !isMouseWheel(e)) {
        // trackpad pinch, or ctrl/cmd + smooth-scroll mouse. Notched
        // wheels fall through to the fixed-step branch below.
        zoomAt(e.clientX, e.clientY, Math.exp(-e.deltaY * 0.01));
      } else if (isMouseWheel(e)) {
        // notched mouse wheel — fixed-ratio step per click
        zoomAt(e.clientX, e.clientY, Math.exp(-Math.sign(e.deltaY) * 0.18));
      } else {
        // trackpad two-finger scroll — pan
        tf.current.x -= e.deltaX;
        tf.current.y -= e.deltaY;
        apply();
      }
    };

    // Safari sends native gesture* events for trackpad pinch with a smooth
    // e.scale; preferring these over the ctrl+wheel fallback gives a much
    // better feel there. No-ops on other browsers. Safari also fires
    // ctrlKey wheel events during the same pinch — isGesturing makes
    // onWheel drop those entirely so they neither zoom nor pan.
    let gsBase = 1;
    let isGesturing = false;
    const onGestureStart = e => {
      e.preventDefault();
      isGesturing = true;
      gsBase = tf.current.scale;
    };
    const onGestureChange = e => {
      e.preventDefault();
      zoomAt(e.clientX, e.clientY, gsBase * e.scale / tf.current.scale);
    };
    const onGestureEnd = e => {
      e.preventDefault();
      isGesturing = false;
    };

    // Drag-pan: middle button anywhere, or primary button on canvas
    // background (anything that isn't an artboard or an inline editor).
    let drag = null;
    const onPointerDown = e => {
      const onBg = !e.target.closest('[data-dc-slot], .dc-editable');
      if (!(e.button === 1 || e.button === 0 && onBg)) return;
      e.preventDefault();
      vp.setPointerCapture(e.pointerId);
      drag = {
        id: e.pointerId,
        lx: e.clientX,
        ly: e.clientY
      };
      vp.style.cursor = 'grabbing';
    };
    const onPointerMove = e => {
      if (!drag || e.pointerId !== drag.id) return;
      tf.current.x += e.clientX - drag.lx;
      tf.current.y += e.clientY - drag.ly;
      drag.lx = e.clientX;
      drag.ly = e.clientY;
      apply();
    };
    const onPointerUp = e => {
      if (!drag || e.pointerId !== drag.id) return;
      vp.releasePointerCapture(e.pointerId);
      drag = null;
      vp.style.cursor = '';
    };

    // Host-driven zoom (toolbar % menu). Zooms around viewport centre so the
    // visible midpoint stays fixed — matching the host's iframe-zoom feel.
    const onHostMsg = e => {
      const d = e.data;
      if (d && d.type === '__dc_set_zoom' && typeof d.scale === 'number') {
        const r = vp.getBoundingClientRect();
        zoomAt(r.left + r.width / 2, r.top + r.height / 2, d.scale / tf.current.scale);
      } else if (d && d.type === '__dc_probe') {
        // Host's [readyGen] reset asks whether a canvas is present; it
        // fires on the iframe's native 'load', which for canvases with
        // images/fonts is after our mount-time announce, so re-announce.
        // Clear the pan-tick guard so apply() re-posts the current scale
        // even if it's unchanged — the host just reset dcScale to 1.
        window.parent.postMessage({
          type: '__dc_present'
        }, '*');
        lastPostedScale.current = undefined;
        apply();
      }
    };
    window.addEventListener('message', onHostMsg);
    // Announce canvas mode so the host toolbar proxies its % control here
    // instead of scaling the iframe element (which would just shrink the
    // viewport window of an infinite canvas). The apply() that follows emits
    // the initial __dc_zoom so the toolbar % is correct before first pinch.
    // lastPostedScale reset mirrors the __dc_probe handler: the layout
    // effect's restore-path apply() may already have posted the restored
    // scale (before __dc_present), so clear the guard to re-post it in order.
    window.parent.postMessage({
      type: '__dc_present'
    }, '*');
    lastPostedScale.current = undefined;
    apply();
    vp.addEventListener('wheel', onWheel, {
      passive: false
    });
    vp.addEventListener('gesturestart', onGestureStart, {
      passive: false
    });
    vp.addEventListener('gesturechange', onGestureChange, {
      passive: false
    });
    vp.addEventListener('gestureend', onGestureEnd, {
      passive: false
    });
    vp.addEventListener('pointerdown', onPointerDown);
    vp.addEventListener('pointermove', onPointerMove);
    vp.addEventListener('pointerup', onPointerUp);
    vp.addEventListener('pointercancel', onPointerUp);
    return () => {
      window.removeEventListener('message', onHostMsg);
      vp.removeEventListener('wheel', onWheel);
      vp.removeEventListener('gesturestart', onGestureStart);
      vp.removeEventListener('gesturechange', onGestureChange);
      vp.removeEventListener('gestureend', onGestureEnd);
      vp.removeEventListener('pointerdown', onPointerDown);
      vp.removeEventListener('pointermove', onPointerMove);
      vp.removeEventListener('pointerup', onPointerUp);
      vp.removeEventListener('pointercancel', onPointerUp);
    };
  }, [apply, minScale, maxScale]);
  const gridSvg = `url("data:image/svg+xml,%3Csvg width='120' height='120' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M120 0H0v120' fill='none' stroke='${encodeURIComponent(DC.grid)}' stroke-width='1'/%3E%3C/svg%3E")`;
  return /*#__PURE__*/React.createElement("div", {
    ref: vpRef,
    className: "design-canvas",
    style: {
      height: '100vh',
      width: '100vw',
      background: DC.bg,
      overflow: 'hidden',
      overscrollBehavior: 'none',
      touchAction: 'none',
      position: 'relative',
      fontFamily: DC.font,
      boxSizing: 'border-box',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    ref: worldRef,
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      transformOrigin: '0 0',
      willChange: 'transform',
      width: 'max-content',
      minWidth: '100%',
      minHeight: '100%',
      padding: '60px 0 80px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: -6000,
      backgroundImage: gridSvg,
      backgroundSize: '120px 120px',
      pointerEvents: 'none',
      zIndex: -1
    }
  }), children));
}

// ─────────────────────────────────────────────────────────────
// DCSection — editable title + h-row of artboards in persisted order
// ─────────────────────────────────────────────────────────────
function DCSection({
  id,
  title,
  subtitle,
  children,
  gap = 48
}) {
  const ctx = React.useContext(DCCtx);
  const sid = id ?? title;
  const all = React.Children.toArray(dcFlatten(children));
  const artboards = all.filter(c => c && c.type === DCArtboard);
  const rest = all.filter(c => !(c && c.type === DCArtboard));
  const sec = ctx && sid && ctx.section(sid) || {};
  // Must match DesignCanvas's srcKey computation exactly (it filters falsy
  // IDs), or onDelete persists a srcKey that DesignCanvas never recognizes.
  const allIds = artboards.map(a => a.props.id ?? a.props.label).filter(Boolean);
  const srcKey = allIds.join('\x1f');
  const hidden = sec.srcKey === srcKey ? sec.hidden || [] : [];
  const srcOrder = allIds.filter(k => !hidden.includes(k));
  const order = React.useMemo(() => {
    const kept = (sec.order || []).filter(k => srcOrder.includes(k));
    return [...kept, ...srcOrder.filter(k => !kept.includes(k))];
  }, [sec.order, srcOrder.join('|')]);
  const byId = Object.fromEntries(artboards.map(a => [a.props.id ?? a.props.label, a]));

  // marginBottom counter-scales so the on-screen gap between sections stays
  // constant — otherwise at low zoom the (world-space) gap collapses while
  // the screen-constant sectionhead below it doesn't, and the title reads as
  // belonging to the section above. paddingBottom below is just enough for
  // the 24px artboard-header (abs-positioned above each card) plus ~8px, so
  // the title sits tight against its own row at every zoom.
  return /*#__PURE__*/React.createElement("div", {
    "data-dc-section": sid,
    style: {
      marginBottom: 'calc(80px * var(--dc-inv-zoom, 1))',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 60px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-sectionhead",
    style: {
      paddingBottom: 36
    }
  }, /*#__PURE__*/React.createElement(DCEditable, {
    tag: "div",
    value: sec.title ?? title,
    onChange: v => ctx && sid && ctx.patchSection(sid, {
      title: v
    }),
    style: {
      fontSize: 28,
      fontWeight: 600,
      color: DC.title,
      letterSpacing: -0.4,
      marginBottom: 6,
      display: 'inline-block'
    }
  }), subtitle && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      color: DC.subtitle
    }
  }, subtitle))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap,
      padding: '0 60px',
      alignItems: 'flex-start',
      width: 'max-content'
    }
  }, order.map(k => /*#__PURE__*/React.createElement(DCArtboardFrame, {
    key: k,
    sectionId: sid,
    artboard: byId[k],
    order: order,
    label: (sec.labels || {})[k] ?? byId[k].props.label,
    onRename: v => ctx && ctx.patchSection(sid, x => ({
      labels: {
        ...x.labels,
        [k]: v
      }
    })),
    onReorder: next => ctx && ctx.patchSection(sid, {
      order: next
    }),
    onDelete: () => ctx && ctx.patchSection(sid, x => ({
      hidden: [...(x.srcKey === srcKey ? x.hidden || [] : []), k],
      srcKey
    })),
    onFocus: () => ctx && ctx.setFocus(`${sid}/${k}`)
  }))), rest);
}

// DCArtboard — marker; rendered by DCArtboardFrame via DCSection.
function DCArtboard() {
  return null;
}

// Per-artboard export (kind: 'png' | 'html'). Both paths share the same
// self-contained clone: computed styles baked in, @font-face / <img> /
// inline-style background-image urls inlined as data URIs. PNG wraps the
// clone in foreignObject→canvas at 3× the artboard's natural width×height
// (same pipeline the host uses for page captures); HTML wraps it in a
// minimal standalone document. Both are independent of viewport zoom.
async function dcExport(node, w, h, name, kind) {
  try {
    await document.fonts.ready;
  } catch {}
  const toDataURL = url => fetch(url).then(r => r.blob()).then(b => new Promise(res => {
    const fr = new FileReader();
    fr.onload = () => res(fr.result);
    fr.onerror = () => res(url);
    fr.readAsDataURL(b);
  })).catch(() => url);

  // Collect @font-face rules. ss.cssRules throws SecurityError on
  // cross-origin sheets (e.g. fonts.googleapis.com) — in that case fetch
  // the CSS text directly (those endpoints send ACAO:*) and regex-extract
  // the blocks. @import and @media/@supports are walked so nested
  // @font-face rules aren't missed.
  const fontRules = [],
    pending = [],
    seen = new Set();
  const scrapeCss = href => {
    if (seen.has(href)) return;
    seen.add(href);
    pending.push(fetch(href).then(r => r.text()).then(css => {
      for (const m of css.match(/@font-face\s*{[^}]*}/g) || []) fontRules.push({
        css: m,
        base: href
      });
      for (const m of css.matchAll(/@import\s+(?:url\()?['"]?([^'")\s;]+)/g)) scrapeCss(new URL(m[1], href).href);
    }).catch(() => {}));
  };
  const walk = (rules, base) => {
    for (const r of rules) {
      if (r.type === CSSRule.FONT_FACE_RULE) fontRules.push({
        css: r.cssText,
        base
      });else if (r.type === CSSRule.IMPORT_RULE && r.styleSheet) {
        const ibase = r.styleSheet.href || base;
        try {
          walk(r.styleSheet.cssRules, ibase);
        } catch {
          scrapeCss(ibase);
        }
      } else if (r.cssRules) walk(r.cssRules, base);
    }
  };
  for (const ss of document.styleSheets) {
    const base = ss.href || location.href;
    try {
      walk(ss.cssRules, base);
    } catch {
      if (ss.href) scrapeCss(ss.href);
    }
  }
  while (pending.length) await pending.shift();
  const fontCss = (await Promise.all(fontRules.map(async rule => {
    let out = rule.css,
      m;
    const re = /url\((['"]?)([^'")]+)\1\)/g;
    while (m = re.exec(rule.css)) {
      if (m[2].indexOf('data:') === 0) continue;
      let abs;
      try {
        abs = new URL(m[2], rule.base).href;
      } catch {
        continue;
      }
      out = out.split(m[0]).join('url("' + (await toDataURL(abs)) + '")');
    }
    return out;
  }))).join('\n');
  const cloneStyled = src => {
    if (src.nodeType === 8 || src.nodeType === 1 && src.tagName === 'SCRIPT') return document.createTextNode('');
    const dst = src.cloneNode(false);
    if (src.nodeType === 1) {
      const cs = getComputedStyle(src);
      let txt = '';
      for (let i = 0; i < cs.length; i++) txt += cs[i] + ':' + cs.getPropertyValue(cs[i]) + ';';
      dst.setAttribute('style', txt + 'animation:none;transition:none;');
      if (src.tagName === 'CANVAS') try {
        const im = document.createElement('img');
        im.src = src.toDataURL();
        im.setAttribute('style', txt);
        return im;
      } catch {}
    }
    for (let c = src.firstChild; c; c = c.nextSibling) dst.appendChild(cloneStyled(c));
    return dst;
  };
  const clone = cloneStyled(node);
  clone.setAttribute('xmlns', 'http://www.w3.org/1999/xhtml');
  // Drop the card's own shadow/radius so the export is a flush w×h rect;
  // the artboard's own background (if any) is already in the computed style.
  clone.style.boxShadow = 'none';
  clone.style.borderRadius = '0';
  const jobs = [];
  clone.querySelectorAll('img').forEach(el => {
    const s = el.getAttribute('src');
    if (s && s.indexOf('data:') !== 0) jobs.push(toDataURL(el.src).then(d => el.setAttribute('src', d)));
  });
  [clone, ...clone.querySelectorAll('*')].forEach(el => {
    const bg = el.style.backgroundImage;
    if (!bg) return;
    let m;
    const re = /url\(["']?([^"')]+)["']?\)/g;
    while (m = re.exec(bg)) {
      const tok = m[0],
        url = m[1];
      if (url.indexOf('data:') === 0) continue;
      jobs.push(toDataURL(url).then(d => {
        el.style.backgroundImage = el.style.backgroundImage.split(tok).join('url("' + d + '")');
      }));
    }
  });
  await Promise.all(jobs);
  const xml = new XMLSerializer().serializeToString(clone);
  const save = (blob, ext) => {
    if (!blob) return;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name + '.' + ext;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };
  if (kind === 'html') {
    const html = '<!doctype html><html><head><meta charset="utf-8"><title>' + name + '</title>' + (fontCss ? '<style>' + fontCss + '</style>' : '') + '</head><body style="margin:0">' + xml + '</body></html>';
    return save(new Blob([html], {
      type: 'text/html'
    }), 'html');
  }

  // PNG: the SVG's own width/height must be the output resolution — an
  // <img>-loaded SVG rasterizes at its intrinsic size, so sizing it at 1×
  // and ctx.scale()-ing up would just upscale a 1× bitmap. viewBox maps the
  // w×h foreignObject onto the px·w × px·h SVG canvas so the browser renders
  // the HTML at full resolution.
  const px = 3;
  const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + w * px + '" height="' + h * px + '" viewBox="0 0 ' + w + ' ' + h + '"><foreignObject width="' + w + '" height="' + h + '">' + (fontCss ? '<style><![CDATA[' + fontCss + ']]></style>' : '') + xml + '</foreignObject></svg>';
  const img = new Image();
  await new Promise((res, rej) => {
    img.onload = res;
    img.onerror = () => rej(new Error('svg load failed'));
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  });
  const cv = document.createElement('canvas');
  cv.width = w * px;
  cv.height = h * px;
  cv.getContext('2d').drawImage(img, 0, 0);
  cv.toBlob(blob => save(blob, 'png'), 'image/png');
}
function DCArtboardFrame({
  sectionId,
  artboard,
  label,
  order,
  onRename,
  onReorder,
  onFocus,
  onDelete
}) {
  const {
    id: rawId,
    label: rawLabel,
    width = 260,
    height = 480,
    children,
    style = {}
  } = artboard.props;
  const id = rawId ?? rawLabel;
  const ref = React.useRef(null);
  const cardRef = React.useRef(null);
  const menuRef = React.useRef(null);
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [confirming, setConfirming] = React.useState(false);

  // ⋯ menu: close on any outside pointerdown. Two-click delete lives inside
  // the menu — first click arms the row, second commits; closing disarms.
  React.useEffect(() => {
    if (!menuOpen) {
      setConfirming(false);
      return;
    }
    const off = e => {
      if (!menuRef.current || !menuRef.current.contains(e.target)) setMenuOpen(false);
    };
    document.addEventListener('pointerdown', off, true);
    return () => document.removeEventListener('pointerdown', off, true);
  }, [menuOpen]);
  const doExport = kind => {
    setMenuOpen(false);
    if (!cardRef.current) return;
    const name = String(label || id || 'artboard').replace(/[^\w\s.-]+/g, '_');
    dcExport(cardRef.current, width, height, name, kind).catch(e => console.error('[design-canvas] export failed:', e));
  };

  // Live drag-reorder: dragged card sticks to cursor; siblings slide into
  // their would-be slots in real time via transforms. DOM order only
  // changes on drop.
  const onGripDown = e => {
    e.preventDefault();
    e.stopPropagation();
    const me = ref.current;
    // translateX is applied in local (pre-scale) space but pointer deltas and
    // getBoundingClientRect().left are screen-space — divide by the viewport's
    // current scale so the dragged card tracks the cursor at any zoom level.
    const scale = me.getBoundingClientRect().width / me.offsetWidth || 1;
    const peers = Array.from(document.querySelectorAll(`[data-dc-section="${sectionId}"] [data-dc-slot]`));
    const homes = peers.map(el => ({
      el,
      id: el.dataset.dcSlot,
      x: el.getBoundingClientRect().left
    }));
    const slotXs = homes.map(h => h.x);
    const startIdx = order.indexOf(id);
    const startX = e.clientX;
    let liveOrder = order.slice();
    me.classList.add('dc-dragging');
    const layout = () => {
      for (const h of homes) {
        if (h.id === id) continue;
        const slot = liveOrder.indexOf(h.id);
        h.el.style.transform = `translateX(${(slotXs[slot] - h.x) / scale}px)`;
      }
    };
    const move = ev => {
      const dx = ev.clientX - startX;
      me.style.transform = `translateX(${dx / scale}px)`;
      const cur = homes[startIdx].x + dx;
      let nearest = 0,
        best = Infinity;
      for (let i = 0; i < slotXs.length; i++) {
        const d = Math.abs(slotXs[i] - cur);
        if (d < best) {
          best = d;
          nearest = i;
        }
      }
      if (liveOrder.indexOf(id) !== nearest) {
        liveOrder = order.filter(k => k !== id);
        liveOrder.splice(nearest, 0, id);
        layout();
      }
    };
    const up = () => {
      document.removeEventListener('pointermove', move);
      document.removeEventListener('pointerup', up);
      const finalSlot = liveOrder.indexOf(id);
      me.classList.remove('dc-dragging');
      me.style.transform = `translateX(${(slotXs[finalSlot] - homes[startIdx].x) / scale}px)`;
      // After the settle transition, kill transitions + clear transforms +
      // commit the reorder in the same frame so there's no visual snap-back.
      setTimeout(() => {
        for (const h of homes) {
          h.el.style.transition = 'none';
          h.el.style.transform = '';
        }
        if (liveOrder.join('|') !== order.join('|')) onReorder(liveOrder);
        requestAnimationFrame(() => requestAnimationFrame(() => {
          for (const h of homes) h.el.style.transition = '';
        }));
      }, 180);
    };
    document.addEventListener('pointermove', move);
    document.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    "data-dc-slot": id,
    style: {
      position: 'relative',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-header",
    "data-noncommentable": "",
    style: {
      color: DC.label
    },
    onPointerDown: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-labelrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-grip",
    onPointerDown: onGripDown,
    title: "Drag to reorder"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "9",
    height: "13",
    viewBox: "0 0 9 13",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "2",
    cy: "2",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "7",
    cy: "2",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "2",
    cy: "6.5",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "7",
    cy: "6.5",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "2",
    cy: "11",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "7",
    cy: "11",
    r: "1.1"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "dc-labeltext",
    onClick: onFocus,
    title: "Click to focus"
  }, /*#__PURE__*/React.createElement(DCEditable, {
    value: label,
    onChange: onRename,
    onClick: e => e.stopPropagation(),
    style: {
      fontSize: 15,
      fontWeight: 500,
      color: DC.label,
      lineHeight: 1
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "dc-btns"
  }, /*#__PURE__*/React.createElement("div", {
    ref: menuRef,
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "dc-kebab",
    title: "More",
    onClick: () => setMenuOpen(o => !o)
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "2.5",
    cy: "6",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "6",
    cy: "6",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "9.5",
    cy: "6",
    r: "1.1"
  }))), menuOpen && /*#__PURE__*/React.createElement("div", {
    className: "dc-menu",
    onPointerDown: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => doExport('png')
  }, "Download PNG"), /*#__PURE__*/React.createElement("button", {
    onClick: () => doExport('html')
  }, "Download HTML"), /*#__PURE__*/React.createElement("hr", null), /*#__PURE__*/React.createElement("button", {
    className: "dc-danger",
    onClick: () => {
      if (confirming) {
        setMenuOpen(false);
        onDelete();
      } else setConfirming(true);
    }
  }, confirming ? 'Click again to delete' : 'Delete'))), /*#__PURE__*/React.createElement("button", {
    className: "dc-expand",
    onClick: onFocus,
    title: "Focus"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.6",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M7 1h4v4M5 11H1V7M11 1L7.5 4.5M1 11l3.5-3.5"
  }))))), /*#__PURE__*/React.createElement("div", {
    ref: cardRef,
    className: "dc-card",
    style: {
      borderRadius: 2,
      boxShadow: '0 1px 3px rgba(0,0,0,.08),0 4px 16px rgba(0,0,0,.06)',
      overflow: 'hidden',
      width,
      height,
      background: '#fff',
      ...style
    }
  }, children || /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#bbb',
      fontSize: 13,
      fontFamily: DC.font
    }
  }, id)));
}

// Inline rename — commits on blur or Enter.
function DCEditable({
  value,
  onChange,
  style,
  tag = 'span',
  onClick
}) {
  const T = tag;
  return /*#__PURE__*/React.createElement(T, {
    className: "dc-editable",
    contentEditable: true,
    suppressContentEditableWarning: true,
    onClick: onClick,
    onPointerDown: e => e.stopPropagation(),
    onBlur: e => onChange && onChange(e.currentTarget.textContent),
    onKeyDown: e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        e.currentTarget.blur();
      }
    },
    style: style
  }, value);
}

// ─────────────────────────────────────────────────────────────
// Focus mode — overlay one artboard; ←/→ within section, ↑/↓ across
// sections, Esc or backdrop click to exit.
// ─────────────────────────────────────────────────────────────
function DCFocusOverlay({
  entry,
  sectionMeta,
  sectionOrder
}) {
  const ctx = React.useContext(DCCtx);
  const {
    sectionId,
    artboard
  } = entry;
  const sec = ctx.section(sectionId);
  const meta = sectionMeta[sectionId];
  const peers = meta.slotIds;
  const aid = artboard.props.id ?? artboard.props.label;
  const idx = peers.indexOf(aid);
  const secIdx = sectionOrder.indexOf(sectionId);
  const go = d => {
    const n = peers[(idx + d + peers.length) % peers.length];
    if (n) ctx.setFocus(`${sectionId}/${n}`);
  };
  const goSection = d => {
    // Sections whose artboards are all deleted have slotIds:[] — step past
    // them to the next non-empty section so ↑/↓ doesn't dead-end.
    const n = sectionOrder.length;
    for (let i = 1; i < n; i++) {
      const ns = sectionOrder[((secIdx + d * i) % n + n) % n];
      const first = sectionMeta[ns] && sectionMeta[ns].slotIds[0];
      if (first) {
        ctx.setFocus(`${ns}/${first}`);
        return;
      }
    }
  };
  React.useEffect(() => {
    const k = e => {
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        go(-1);
      }
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        go(1);
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        goSection(-1);
      }
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        goSection(1);
      }
    };
    document.addEventListener('keydown', k);
    return () => document.removeEventListener('keydown', k);
  });
  const {
    width = 260,
    height = 480,
    children
  } = artboard.props;
  const [vp, setVp] = React.useState({
    w: window.innerWidth,
    h: window.innerHeight
  });
  React.useEffect(() => {
    const r = () => setVp({
      w: window.innerWidth,
      h: window.innerHeight
    });
    window.addEventListener('resize', r);
    return () => window.removeEventListener('resize', r);
  }, []);
  const scale = Math.max(0.1, Math.min((vp.w - 200) / width, (vp.h - 260) / height, 2));
  const [ddOpen, setDd] = React.useState(false);
  const Arrow = ({
    dir,
    onClick
  }) => /*#__PURE__*/React.createElement("button", {
    onClick: e => {
      e.stopPropagation();
      onClick();
    },
    style: {
      position: 'absolute',
      top: '50%',
      [dir]: 28,
      transform: 'translateY(-50%)',
      border: 'none',
      background: 'rgba(255,255,255,.08)',
      color: 'rgba(255,255,255,.9)',
      width: 44,
      height: 44,
      borderRadius: 22,
      fontSize: 18,
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'background .15s'
    },
    onMouseEnter: e => e.currentTarget.style.background = 'rgba(255,255,255,.18)',
    onMouseLeave: e => e.currentTarget.style.background = 'rgba(255,255,255,.08)'
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 18 18",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: dir === 'left' ? 'M11 3L5 9l6 6' : 'M7 3l6 6-6 6'
  })));

  // Portal to body so position:fixed is the real viewport regardless of any
  // transform on DesignCanvas's ancestors (including the canvas zoom itself).
  return ReactDOM.createPortal(/*#__PURE__*/React.createElement("div", {
    onClick: () => ctx.setFocus(null),
    onWheel: e => e.preventDefault(),
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 100,
      background: 'rgba(24,20,16,.6)',
      backdropFilter: 'blur(14px)',
      fontFamily: DC.font,
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      height: 72,
      display: 'flex',
      alignItems: 'flex-start',
      padding: '16px 20px 0',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setDd(o => !o),
    style: {
      border: 'none',
      background: 'transparent',
      color: '#fff',
      cursor: 'pointer',
      padding: '6px 8px',
      borderRadius: 6,
      textAlign: 'left',
      fontFamily: 'inherit'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18,
      fontWeight: 600,
      letterSpacing: -0.3
    }
  }, meta.title), /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "11",
    viewBox: "0 0 11 11",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.8",
    strokeLinecap: "round",
    style: {
      opacity: .7
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2 4l3.5 3.5L9 4"
  }))), meta.subtitle && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: 13,
      opacity: .6,
      fontWeight: 400,
      marginTop: 2
    }
  }, meta.subtitle)), ddOpen && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '100%',
      left: 0,
      marginTop: 4,
      background: '#2a251f',
      borderRadius: 8,
      boxShadow: '0 8px 32px rgba(0,0,0,.4)',
      padding: 4,
      minWidth: 200,
      zIndex: 10
    }
  }, sectionOrder.filter(sid => sectionMeta[sid].slotIds.length).map(sid => /*#__PURE__*/React.createElement("button", {
    key: sid,
    onClick: () => {
      setDd(false);
      const f = sectionMeta[sid].slotIds[0];
      if (f) ctx.setFocus(`${sid}/${f}`);
    },
    style: {
      display: 'block',
      width: '100%',
      textAlign: 'left',
      border: 'none',
      cursor: 'pointer',
      background: sid === sectionId ? 'rgba(255,255,255,.1)' : 'transparent',
      color: '#fff',
      padding: '8px 12px',
      borderRadius: 5,
      fontSize: 14,
      fontWeight: sid === sectionId ? 600 : 400,
      fontFamily: 'inherit'
    }
  }, sectionMeta[sid].title)))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => ctx.setFocus(null),
    onMouseEnter: e => e.currentTarget.style.background = 'rgba(255,255,255,.12)',
    onMouseLeave: e => e.currentTarget.style.background = 'transparent',
    style: {
      border: 'none',
      background: 'transparent',
      color: 'rgba(255,255,255,.7)',
      width: 32,
      height: 32,
      borderRadius: 16,
      fontSize: 20,
      cursor: 'pointer',
      lineHeight: 1,
      transition: 'background .12s'
    }
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 64,
      bottom: 56,
      left: 100,
      right: 100,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      width: width * scale,
      height: height * scale,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width,
      height,
      transform: `scale(${scale})`,
      transformOrigin: 'top left',
      background: '#fff',
      borderRadius: 2,
      overflow: 'hidden',
      boxShadow: '0 20px 80px rgba(0,0,0,.4)'
    }
  }, children || /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#bbb'
    }
  }, aid))), /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      fontSize: 14,
      fontWeight: 500,
      opacity: .85,
      textAlign: 'center'
    }
  }, (sec.labels || {})[aid] ?? artboard.props.label, /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: .5,
      marginLeft: 10,
      fontVariantNumeric: 'tabular-nums'
    }
  }, idx + 1, " / ", peers.length))), /*#__PURE__*/React.createElement(Arrow, {
    dir: "left",
    onClick: () => go(-1)
  }), /*#__PURE__*/React.createElement(Arrow, {
    dir: "right",
    onClick: () => go(1)
  }), /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      position: 'absolute',
      bottom: 20,
      left: '50%',
      transform: 'translateX(-50%)',
      display: 'flex',
      gap: 8
    }
  }, peers.map((p, i) => /*#__PURE__*/React.createElement("button", {
    key: p,
    onClick: () => ctx.setFocus(`${sectionId}/${p}`),
    style: {
      border: 'none',
      padding: 0,
      cursor: 'pointer',
      width: 6,
      height: 6,
      borderRadius: 3,
      background: i === idx ? '#fff' : 'rgba(255,255,255,.3)'
    }
  })))), document.body);
}

// ─────────────────────────────────────────────────────────────
// Post-it — absolute-positioned sticky note
// ─────────────────────────────────────────────────────────────
function DCPostIt({
  children,
  top,
  left,
  right,
  bottom,
  rotate = -2,
  width = 180
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top,
      left,
      right,
      bottom,
      width,
      background: DC.postitBg,
      padding: '14px 16px',
      fontFamily: '"Comic Sans MS", "Marker Felt", "Segoe Print", cursive',
      fontSize: 14,
      lineHeight: 1.4,
      color: DC.postitText,
      boxShadow: '0 2px 8px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.08)',
      transform: `rotate(${rotate}deg)`,
      zIndex: 5
    }
  }, children);
}
Object.assign(window, {
  DesignCanvas,
  DCSection,
  DCArtboard,
  DCPostIt
});

// ═══ src/data.jsx ═══

// Pearl OTC — sample trade data for mockups.
// Realistic-looking PRL bech32m addresses, Base 0x addresses, txids.

const PRL_BUYER_ADDR = "prl1pzlfqvr3rg5pny5pk3w7v2g3q3p7d6t6mklqe9zr4t76uwmas20s8fkg7v";
const PRL_ESCROW_ADDR = "prl1pn4gxqzx4t4q2dye7yawd0kc7ynvtqj0wj9c4v5l7m0kfgs8lyq8mzkdr2";
const PRL_REFUND_ADDR = "prl1pl3w7v2g3q3p7d6t6mklqe9zr4t76uwmas20s8fkg7vzlfqvr3rg5pny5pk";
const BASE_BUYER_ADDR = "0x7a4c8E2bAa5f1D9C3E04F7B6c9A2dB3e5fF6C8a4E";
const BASE_ESCROW_ADDR = "0x9F2B4D5fA3eC1c6dD8B2F9c7AaE5b1D7f6A0c3B8";
const BASE_RECEIVE_ADDR = "0x4eC2D8a3fB7d9C0e2A1F5b6c8D9E0F1A2B3C4D5E";
const PRL_FUND_TXID = "f3c1a9b2d4e5f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2";
const PRL_RELEASE_TXID = "a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8";
const PRL_REFUND_TXID = "b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3";
const BASE_DEPOSIT_HASH = "0xc4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5";
const BASE_RELEASE_HASH = "0xa1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2";
const BASE_REFUND_HASH = "0xe5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6";
const TRADE_KEY = "0x3b91...c7f4"; // short
const TRADE_KEY_FULL = "0x3b9142f6a8c0e7b5d2f1a9e4c8b3d6f0a5e7c2b9d4f1a8e3c6b0d5f2a7e9c7f4";
const TRADE_ID = "trd_01J5K8B2QHXV9P3Y";
const SAMPLE = {
  tradeId: TRADE_ID,
  side: "buy",
  amountPrl: {
    whole: "12,500",
    frac: ".000_000_00"
  },
  amountPrlPlain: "12,500.00000000",
  amountUsdc: {
    whole: "8,237",
    frac: ".500_000"
  },
  amountUsdcPlain: "8,237.500000",
  feePrl: "12.50000000",
  feeUsdc: "8.235000",
  price: "0.659000",
  pearlAddr: PRL_ESCROW_ADDR,
  baseEscrow: BASE_ESCROW_ADDR,
  tradeKey: TRADE_KEY,
  tradeKeyFull: TRADE_KEY_FULL,
  buyerPearl: PRL_BUYER_ADDR,
  buyerBase: BASE_BUYER_ADDR,
  baseReceive: BASE_RECEIVE_ADDR,
  fundTxid: PRL_FUND_TXID,
  releaseTxid: PRL_RELEASE_TXID,
  refundTxid: PRL_REFUND_TXID,
  depositHash: BASE_DEPOSIT_HASH,
  releaseHash: BASE_RELEASE_HASH,
  refundHash: BASE_REFUND_HASH,
  // Lifecycle markers (display strings)
  deadlines: {
    quote: "00:42",
    pearlFund: "00:23:14",
    usdcDeposit: "00:19:47",
    settlement: "01:43:02",
    refundAvail: "—"
  },
  acceptedAt: "2026-05-17 14:22:08 UTC"
};

// State family → badge config
const STATE_BADGES = {
  quoted: {
    tone: "accent",
    label: "quoted"
  },
  pearl_escrow_pending: {
    tone: "neutral",
    label: "pearl_escrow_pending"
  },
  pearl_escrow_seen: {
    tone: "accent",
    label: "pearl_escrow_seen"
  },
  pearl_escrow_confirmed: {
    tone: "ok",
    label: "pearl_escrow_confirmed"
  },
  usdc_escrow_pending: {
    tone: "neutral",
    label: "usdc_escrow_pending"
  },
  usdc_escrow_confirmed: {
    tone: "ok",
    label: "usdc_escrow_confirmed"
  },
  release_pending: {
    tone: "accent",
    label: "release_pending"
  },
  released: {
    tone: "ok",
    label: "released"
  },
  refund_available: {
    tone: "warn",
    label: "refund_available"
  },
  refund_pending: {
    tone: "warn",
    label: "refund_pending"
  },
  refunded: {
    tone: "warn",
    label: "refunded"
  },
  quote_expired: {
    tone: "neutral",
    label: "quote_expired"
  },
  cancelled: {
    tone: "neutral",
    label: "cancelled"
  },
  disputed: {
    tone: "err",
    label: "disputed"
  },
  failed_manual_review: {
    tone: "err",
    label: "failed_manual_review"
  },
  late_prl_funding: {
    tone: "err",
    label: "late_prl_funding"
  },
  usdc_refunded: {
    tone: "warn",
    label: "usdc_refunded"
  },
  prl_release_failed: {
    tone: "err",
    label: "prl_release_failed"
  },
  amount_mismatch: {
    tone: "err",
    label: "amount_mismatch"
  },
  reorged: {
    tone: "warn",
    label: "reorged"
  },
  stale_indexer: {
    tone: "warn",
    label: "stale_indexer"
  },
  unknown_spend: {
    tone: "err",
    label: "unknown_spend"
  }
};

// Failure banner copy (per brief §8)
const FAILURE_BANNERS = {
  late_prl_funding: {
    tone: "err",
    head: "PRL was funded after the deadline. This trade will not auto-release."
  },
  usdc_refunded: {
    tone: "warn",
    head: "USDC was refunded. PRL release is blocked."
  },
  prl_release_failed: {
    tone: "err",
    head: "PRL release transaction failed to broadcast. Manual review required."
  },
  amount_mismatch: {
    tone: "err",
    head: "Funded amount does not match the expected escrow amount."
  },
  reorged: {
    tone: "warn",
    head: "A funding block was orphaned by a chain reorg. Awaiting re-confirmation."
  },
  stale_indexer: {
    tone: "warn",
    head: "Indexer lag exceeds threshold. Status may be stale."
  },
  unknown_spend: {
    tone: "err",
    head: "Escrow output was spent by an unrecognized transaction. Audit pending."
  },
  failed_manual_review: {
    tone: "err",
    head: "Trade flagged for manual review."
  },
  disputed: {
    tone: "err",
    head: "Trade is under dispute."
  }
};

// Timeline events for various states
const TL_EVENTS = {
  quoted: [{
    chain: "sys",
    ev: "Quote issued",
    meta: "qte_01J5K8AB2 · 14:21:26 UTC",
    time: "2 min ago"
  }],
  pearl_escrow_pending: [{
    chain: "sys",
    ev: "Quote issued",
    meta: "qte_01J5K8AB2 · 14:21:26 UTC",
    time: "4 min ago"
  }, {
    chain: "sys",
    ev: "Quote accepted; escrows allocated",
    meta: "by buyer · 14:22:08 UTC",
    time: "3 min ago"
  }],
  pearl_seen: [{
    chain: "sys",
    ev: "Quote accepted; escrows allocated",
    meta: "14:22:08 UTC",
    time: "9 min ago"
  }, {
    chain: "pearl",
    ev: "Pearl deposit observed",
    meta: "f3c1a9…f1a2 · 12,500.00000000 PRL",
    time: "6 min ago"
  }, {
    chain: "pearl",
    ev: "Confirmation 1 of 6",
    meta: "block 18,432,901",
    time: "4 min ago"
  }, {
    chain: "pearl",
    ev: "Confirmation 2 of 6",
    meta: "block 18,432,902",
    time: "3 min ago"
  }, {
    chain: "pearl",
    ev: "Confirmation 3 of 6",
    meta: "block 18,432,903",
    time: "1 min ago"
  }],
  both_confirming: [{
    chain: "sys",
    ev: "Quote accepted; escrows allocated",
    meta: "14:22:08 UTC",
    time: "11 min ago"
  }, {
    chain: "pearl",
    ev: "Pearl deposit observed",
    meta: "f3c1a9…f1a2",
    time: "8 min ago"
  }, {
    chain: "pearl",
    ev: "Pearl deposit confirmed",
    meta: "6/6 confirmations",
    time: "3 min ago"
  }, {
    chain: "base",
    ev: "USDC deposit observed",
    meta: "0xc4d5…c4d5",
    time: "2 min ago"
  }, {
    chain: "base",
    ev: "Confirmation 4 of 12",
    meta: "block 21,007,442",
    time: "47s ago"
  }],
  released: [{
    chain: "sys",
    ev: "Quote accepted; escrows allocated",
    meta: "14:22:08 UTC",
    time: "23 min ago"
  }, {
    chain: "pearl",
    ev: "Pearl deposit confirmed",
    meta: "6/6 confirmations",
    time: "16 min ago"
  }, {
    chain: "base",
    ev: "USDC deposit confirmed",
    meta: "12/12 confirmations",
    time: "8 min ago"
  }, {
    chain: "sys",
    ev: "Release authorized",
    meta: "server-driven · idempotency 0x7e…2a",
    time: "3 min ago"
  }, {
    chain: "pearl",
    ev: "PRL release broadcast",
    meta: "a7b8c9…a7b8",
    time: "2 min ago"
  }, {
    chain: "base",
    ev: "USDC release broadcast",
    meta: "0xa1b2…a1b2",
    time: "1 min ago"
  }, {
    chain: "ok",
    ev: "Trade released",
    meta: "14:45:11 UTC",
    time: "just now"
  }],
  failure_generic: [{
    chain: "sys",
    ev: "Quote accepted; escrows allocated",
    meta: "14:22:08 UTC",
    time: "47 min ago"
  }, {
    chain: "pearl",
    ev: "Pearl deposit observed",
    meta: "f3c1a9…f1a2",
    time: "38 min ago"
  }, {
    chain: "pearl",
    ev: "Pearl deposit confirmed",
    meta: "6/6 confirmations",
    time: "31 min ago"
  }, {
    chain: "err",
    ev: "State entered: manual_review",
    meta: "system · 14:53:44 UTC",
    time: "12 min ago"
  }]
};

// Admin list rows
const ADMIN_ROWS = [{
  id: "trd_01J5K8B2QHXV9P3Y",
  state: "pearl_escrow_pending",
  age: "2m",
  prl: "12,500.00000000",
  usdc: "8,237.500000",
  side: "buy",
  flag: null
}, {
  id: "trd_01J5K7Z1M4NTBHGX",
  state: "released",
  age: "14m",
  prl: "3,000.00000000",
  usdc: "1,977.000000",
  side: "buy",
  flag: null
}, {
  id: "trd_01J5K7Y8VFJCQ2WP",
  state: "late_prl_funding",
  age: "23m",
  prl: "8,000.00000000",
  usdc: "5,272.000000",
  side: "buy",
  flag: "Funding 4m past deadline"
}, {
  id: "trd_01J5K7XKE3RMS4DA",
  state: "usdc_escrow_pending",
  age: "31m",
  prl: "45,200.00000000",
  usdc: "29,786.800000",
  side: "sell",
  flag: null
}, {
  id: "trd_01J5K7W9QH8FLPCN",
  state: "released",
  age: "47m",
  prl: "1,250.00000000",
  usdc: "823.750000",
  side: "buy",
  flag: null
}, {
  id: "trd_01J5K7VC2A9BHE6T",
  state: "amount_mismatch",
  age: "1h",
  prl: "10,000.00000000",
  usdc: "6,590.000000",
  side: "sell",
  flag: "Funded 9,998.4 PRL (-1.6)"
}, {
  id: "trd_01J5K7U6PXMK1DRQ",
  state: "released",
  age: "1h",
  prl: "500.00000000",
  usdc: "329.500000",
  side: "buy",
  flag: null
}, {
  id: "trd_01J5K7T0NWCG4PFE",
  state: "reorged",
  age: "2h",
  prl: "22,000.00000000",
  usdc: "14,498.000000",
  side: "buy",
  flag: "Block 18432901 orphaned"
}, {
  id: "trd_01J5K7S5HJDB3MUL",
  state: "refund_pending",
  age: "2h",
  prl: "6,750.00000000",
  usdc: "4,448.250000",
  side: "sell",
  flag: null
}, {
  id: "trd_01J5K7R9F8AT2CXK",
  state: "stale_indexer",
  age: "3h",
  prl: "1,800.00000000",
  usdc: "1,186.200000",
  side: "buy",
  flag: "Lag 42s"
}, {
  id: "trd_01J5K7Q3B4MV0KFP",
  state: "released",
  age: "3h",
  prl: "9,200.00000000",
  usdc: "6,062.800000",
  side: "buy",
  flag: null
}, {
  id: "trd_01J5K7P7DC5HX1YN",
  state: "refunded",
  age: "4h",
  prl: "3,500.00000000",
  usdc: "2,306.500000",
  side: "buy",
  flag: null
}];
window.PearlData = {
  SAMPLE,
  STATE_BADGES,
  FAILURE_BANNERS,
  TL_EVENTS,
  ADMIN_ROWS
};

// ═══ src/components.jsx ═══

// Pearl OTC — shared UI primitives.
// Use plain function components. Names start with Pearl* to avoid collisions.

// (destructure stripped)
// ─── Browser chrome (subtle URL bar) ─────────────────────────────────────────
function Chrome({
  path = "/quote"
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "chrome"
  }, /*#__PURE__*/React.createElement("div", {
    className: "chrome-dots"
  }, /*#__PURE__*/React.createElement("span", {
    className: "chrome-dot"
  }), /*#__PURE__*/React.createElement("span", {
    className: "chrome-dot"
  }), /*#__PURE__*/React.createElement("span", {
    className: "chrome-dot"
  })), /*#__PURE__*/React.createElement("div", {
    className: "chrome-url"
  }, /*#__PURE__*/React.createElement("span", {
    className: "scheme"
  }, "https://"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ink-2)'
    }
  }, "otc.pearl.dev"), /*#__PURE__*/React.createElement("span", {
    className: "path"
  }, path)));
}

// ─── Top nav (app chrome) ────────────────────────────────────────────────────
function TopNav({
  active = "trade",
  env = "testnet",
  role = "buyer"
}) {
  const items = [{
    id: "offers",
    label: "Offers",
    href: "/offers"
  }, {
    id: "quote",
    label: "Quote",
    href: "/quote"
  }, {
    id: "trade",
    label: "Trades",
    href: "/trades"
  }, {
    id: "my",
    label: "My quotes",
    href: "/my-quotes"
  }, {
    id: "docs",
    label: "Docs",
    href: "/docs"
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "topnav"
  }, /*#__PURE__*/React.createElement("div", {
    className: "logo",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "glyph"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      lineHeight: 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: 14,
      letterSpacing: '-0.2px'
    }
  }, "PRL Settlement Desk"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      color: 'var(--muted-2)',
      letterSpacing: 0.5,
      textTransform: 'uppercase',
      marginTop: 2
    }
  }, "by Oysters"))), /*#__PURE__*/React.createElement("span", {
    className: "env-pill"
  }, env), /*#__PURE__*/React.createElement("nav", null, items.map(i => /*#__PURE__*/React.createElement("a", {
    key: i.id,
    className: i.id === active ? "active" : "",
    href: "#"
  }, i.label))), /*#__PURE__*/React.createElement("div", {
    className: "spacer"
  }), /*#__PURE__*/React.createElement("div", {
    className: "user"
  }, /*#__PURE__*/React.createElement("span", null, "desk@kaspacom"), /*#__PURE__*/React.createElement("span", {
    className: "avatar"
  }, "D")));
}
function AdminTopNav({
  active = "trades"
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "topnav",
    style: {
      background: '#1a1a17',
      borderBottom: '1px solid #2a2a25'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "logo",
    style: {
      color: '#fff',
      display: 'flex',
      alignItems: 'center',
      gap: 9
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "glyph"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      lineHeight: 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: 14,
      letterSpacing: '-0.2px'
    }
  }, "PRL Settlement Desk ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#9a988f',
      fontWeight: 400
    }
  }, "\xB7 admin")), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      color: '#9a988f',
      letterSpacing: 0.5,
      textTransform: 'uppercase',
      marginTop: 2
    }
  }, "by Oysters"))), /*#__PURE__*/React.createElement("span", {
    className: "env-pill",
    style: {
      background: 'transparent',
      color: '#e6d4a8',
      borderColor: '#5a4e2a'
    }
  }, "testnet"), /*#__PURE__*/React.createElement("nav", null, [{
    id: "trades",
    label: "Trades"
  }, {
    id: "manual",
    label: "Manual review"
  }, {
    id: "audit",
    label: "Audit log"
  }, {
    id: "ops",
    label: "Operators"
  }].map(i => /*#__PURE__*/React.createElement("a", {
    key: i.id,
    href: "#",
    className: i.id === active ? "active" : "",
    style: {
      color: i.id === active ? '#fff' : '#9a988f'
    }
  }, i.label))), /*#__PURE__*/React.createElement("div", {
    className: "spacer"
  }), /*#__PURE__*/React.createElement("div", {
    className: "user",
    style: {
      color: '#9a988f'
    }
  }, /*#__PURE__*/React.createElement("span", null, "op_07 \xB7 marcus.q"), /*#__PURE__*/React.createElement("span", {
    className: "avatar",
    style: {
      background: '#c4a87a',
      color: '#1a1a17'
    }
  }, "MQ")));
}

// ─── State badge ─────────────────────────────────────────────────────────────
function StateBadge({
  state
}) {
  const cfg = STATE_BADGES[state] || {
    tone: "neutral",
    label: state
  };
  return /*#__PURE__*/React.createElement("span", {
    className: `badge ${cfg.tone}`
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), cfg.label);
}

// ─── Network chip ────────────────────────────────────────────────────────────
function NetChip({
  chain = "pearl",
  env = "testnet2"
}) {
  const labels = {
    "pearl-main": {
      name: "PRL · mainnet",
      sq: "#2a2a25"
    },
    "pearl-test": {
      name: "PRL · testnet2",
      sq: "#8a6418"
    },
    "base-main": {
      name: "BASE · mainnet",
      sq: "#2c4a78"
    },
    "base-test": {
      name: "BASE · sepolia",
      sq: "#2c4a78"
    }
  };
  const key = `${chain}-${env.startsWith("test") || env === "sepolia" ? "test" : "main"}`;
  const c = labels[key] || labels["pearl-test"];
  return /*#__PURE__*/React.createElement("span", {
    className: "chip"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sq",
    style: {
      background: c.sq
    }
  }), c.name);
}

// ─── Copy icon (visual only) ─────────────────────────────────────────────────
function CopyIcon() {
  return /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.2"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "3",
    width: "6.5",
    height: "6.5",
    rx: "1"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M2 7V2.5A.5.5 0 0 1 2.5 2H7"
  }));
}

// ─── Address pill ────────────────────────────────────────────────────────────
function Addr({
  value,
  mono = true
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "addr"
  }, /*#__PURE__*/React.createElement("span", null, value), /*#__PURE__*/React.createElement("span", {
    className: "copy",
    title: "Copy"
  }, /*#__PURE__*/React.createElement(CopyIcon, null)));
}

// ─── Amount (big, with int/frac split) ───────────────────────────────────────
function AmountBig({
  whole,
  frac,
  unit,
  plain
}) {
  if (plain) {
    const m = plain.match(/^([\d,]+)(\.[\d_]+)?$/);
    if (m) {
      whole = m[1];
      frac = m[2] || '';
    }
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "amount-big"
  }, /*#__PURE__*/React.createElement("span", null, whole), /*#__PURE__*/React.createElement("span", {
    className: "frac"
  }, frac), unit && /*#__PURE__*/React.createElement("span", {
    className: "unit"
  }, unit));
}
function AmountMed({
  whole,
  frac,
  unit
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "amount-med"
  }, /*#__PURE__*/React.createElement("span", null, whole), /*#__PURE__*/React.createElement("span", {
    className: "frac"
  }, frac), unit && /*#__PURE__*/React.createElement("span", {
    className: "unit"
  }, unit));
}

// ─── Trade ID (sticky header) ────────────────────────────────────────────────
function TradeId({
  id = SAMPLE.tradeId
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      fontSize: 12,
      color: 'var(--ink)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted-2)'
    }
  }, "trade"), id, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted-2)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(CopyIcon, null)));
}

// ─── Countdown deadline pill ─────────────────────────────────────────────────
function fmtCD(secs) {
  if (secs <= 0) return "expired";
  const h = Math.floor(secs / 3600);
  const m = Math.floor(secs % 3600 / 60);
  const s = secs % 60;
  if (h > 0) return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}
function Countdown({
  label,
  value,
  secs,
  tone = ""
}) {
  // Static display only — no live ticking (was causing perf issues across 80+ countdowns).
  const display = typeof secs === 'number' ? fmtCD(secs) : value;
  return /*#__PURE__*/React.createElement("div", {
    className: `cd ${tone}`,
    title: `Absolute: 2026-05-17 15:00 UTC`
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, label), /*#__PURE__*/React.createElement("span", {
    className: "val"
  }, display));
}

// ─── Banner (failure / info) ─────────────────────────────────────────────────
function Banner({
  tone = "err",
  title,
  body,
  action = "Contact support"
}) {
  const icon = {
    err: "⚠",
    warn: "⚠",
    info: "ℹ",
    neutral: "—"
  }[tone];
  return /*#__PURE__*/React.createElement("div", {
    className: `banner ${tone}`
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic",
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-mono)',
      fontWeight: 600
    }
  }, icon), /*#__PURE__*/React.createElement("div", {
    className: "body"
  }, /*#__PURE__*/React.createElement("strong", null, title), body && /*#__PURE__*/React.createElement("div", {
    className: "lede"
  }, body)), action && /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      alignSelf: 'flex-start',
      whiteSpace: 'nowrap',
      fontWeight: 500,
      fontSize: 12
    }
  }, action, " \u2192"));
}
function FailureBanner({
  state
}) {
  const b = FAILURE_BANNERS[state];
  if (!b) return null;
  return /*#__PURE__*/React.createElement(Banner, {
    tone: b.tone,
    title: b.head,
    body: `Trade ${SAMPLE.tradeId} · contact desk@pearl.dev with this trade id and the state name above.`
  });
}

// ─── Timeline row ────────────────────────────────────────────────────────────
function Timeline({
  events
}) {
  const icon = chain => {
    if (chain === 'pearl') return {
      cls: 'pearl',
      char: 'P'
    };
    if (chain === 'base') return {
      cls: 'base',
      char: 'B'
    };
    if (chain === 'ok') return {
      cls: 'ok',
      char: '✓'
    };
    if (chain === 'err') return {
      cls: 'err',
      char: '!'
    };
    return {
      cls: 'pearl',
      char: '·'
    };
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "timeline"
  }, events.map((e, i) => {
    const ic = icon(e.chain);
    return /*#__PURE__*/React.createElement("div", {
      className: "tl-row",
      key: i
    }, /*#__PURE__*/React.createElement("div", {
      className: `tl-icon ${ic.cls}`
    }, ic.char), /*#__PURE__*/React.createElement("div", {
      className: "tl-body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ev"
    }, e.ev), e.meta && /*#__PURE__*/React.createElement("div", {
      className: "meta"
    }, e.meta)), /*#__PURE__*/React.createElement("div", {
      className: "tl-time"
    }, e.time));
  }));
}

// ─── Sticky header (deadlines + state) ───────────────────────────────────────
function TradeHeader({
  state = "pearl_escrow_pending",
  deadlines = SAMPLE.deadlines,
  tradeId = SAMPLE.tradeId
}) {
  // mark some deadlines as warn/done based on state
  const expired = ["late_prl_funding", "quote_expired"].includes(state);
  const allDone = ["released", "refunded"].includes(state);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 28px 16px',
      background: 'var(--surface)',
      borderBottom: '1px solid var(--hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(TradeId, {
    id: tradeId
  }), /*#__PURE__*/React.createElement(StateBadge, {
    state: state
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontSize: 11
    }
  }, "accepted ", /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, SAMPLE.acceptedAt))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Countdown, {
    label: "quote_expires",
    value: "\u2014",
    tone: "done"
  }), /*#__PURE__*/React.createElement(Countdown, {
    label: "pearl_funding",
    value: state === 'late_prl_funding' ? '−00:04:21' : undefined,
    secs: state === 'late_prl_funding' ? undefined : allDone ? undefined : 23 * 60 + 14,
    tone: state === 'late_prl_funding' ? 'err' : allDone ? 'done' : ''
  }), /*#__PURE__*/React.createElement(Countdown, {
    label: "usdc_deposit",
    secs: ['released', 'refunded', 'usdc_refunded'].includes(state) ? undefined : 19 * 60 + 47,
    value: ['released', 'refunded'].includes(state) ? deadlines.usdcDeposit : state === 'usdc_refunded' ? '−12:08' : undefined,
    tone: ['released', 'refunded'].includes(state) ? 'done' : state === 'usdc_refunded' ? 'err' : ''
  }), /*#__PURE__*/React.createElement(Countdown, {
    label: "settlement",
    secs: allDone ? undefined : 60 * 60 + 43 * 60 + 2,
    value: allDone ? deadlines.settlement : undefined,
    tone: allDone ? 'done' : ''
  }), /*#__PURE__*/React.createElement(Countdown, {
    label: "refund_available",
    value: state === 'refund_available' ? "now" : "01:13:44",
    tone: state === 'refund_available' ? 'warn' : ''
  })));
}

// ─── Pearl card (chain leg) ──────────────────────────────────────────────────
function PearlCard({
  status = 'pending',
  confirmations = 0,
  withTx = false
}) {
  const statusMap = {
    pending: {
      badge: /*#__PURE__*/React.createElement("span", {
        className: "badge neutral"
      }, /*#__PURE__*/React.createElement("span", {
        className: "dot"
      }), "Awaiting funding"),
      conf: '0 / 6'
    },
    seen: {
      badge: /*#__PURE__*/React.createElement("span", {
        className: "badge accent"
      }, /*#__PURE__*/React.createElement("span", {
        className: "dot"
      }), "Funding observed"),
      conf: `${confirmations} / 6`
    },
    confirmed: {
      badge: /*#__PURE__*/React.createElement("span", {
        className: "badge ok"
      }, /*#__PURE__*/React.createElement("span", {
        className: "dot"
      }), "Funding confirmed"),
      conf: '6 / 6'
    },
    late: {
      badge: /*#__PURE__*/React.createElement("span", {
        className: "badge err"
      }, /*#__PURE__*/React.createElement("span", {
        className: "dot"
      }), "Funded after deadline"),
      conf: '6 / 6'
    },
    released: {
      badge: /*#__PURE__*/React.createElement("span", {
        className: "badge ok"
      }, /*#__PURE__*/React.createElement("span", {
        className: "dot"
      }), "Released to buyer"),
      conf: '6 / 6'
    },
    refunded: {
      badge: /*#__PURE__*/React.createElement("span", {
        className: "badge warn"
      }, /*#__PURE__*/React.createElement("span", {
        className: "dot"
      }), "Refunded"),
      conf: '6 / 6'
    },
    mismatch: {
      badge: /*#__PURE__*/React.createElement("span", {
        className: "badge err"
      }, /*#__PURE__*/React.createElement("span", {
        className: "dot"
      }), "Amount mismatch"),
      conf: '6 / 6'
    },
    reorged: {
      badge: /*#__PURE__*/React.createElement("span", {
        className: "badge warn"
      }, /*#__PURE__*/React.createElement("span", {
        className: "dot"
      }), "Reorg detected"),
      conf: '3 / 6'
    },
    unknown: {
      badge: /*#__PURE__*/React.createElement("span", {
        className: "badge err"
      }, /*#__PURE__*/React.createElement("span", {
        className: "dot"
      }), "Unknown spend"),
      conf: '—'
    }
  };
  const s = statusMap[status] || statusMap.pending;
  const showTx = withTx || ['confirmed', 'seen', 'released', 'refunded', 'late', 'mismatch', 'reorged', 'unknown'].includes(status);
  return /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "h2"
  }, "Pearl leg"), /*#__PURE__*/React.createElement(NetChip, {
    chain: "pearl",
    env: "testnet2"
  })), s.badge), /*#__PURE__*/React.createElement("div", {
    className: "card-pad"
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 6
    }
  }, "escrow address"), /*#__PURE__*/React.createElement(Addr, {
    value: SAMPLE.pearlAddr
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 4
    }
  }, "expected amount"), /*#__PURE__*/React.createElement(AmountBig, {
    whole: "12,500",
    frac: ".00000000",
    unit: "PRL"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right',
      fontSize: 11.5,
      color: 'var(--muted)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mono"
  }, s.conf), /*#__PURE__*/React.createElement("div", null, "confirmations"))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      padding: '11px 12px',
      background: 'var(--paper-2)',
      border: '1px dashed var(--neutral-line)',
      borderRadius: 'var(--r-2)',
      display: 'flex',
      alignItems: 'flex-start',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 22,
      height: 22,
      borderRadius: 4,
      background: 'var(--neutral-soft)',
      border: '1px solid var(--neutral-line)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--neutral)'
    }
  }, "P")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11.5,
      lineHeight: 1.5,
      color: 'var(--ink-2)'
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      fontWeight: 600
    }
  }, "Pearl Desktop Wallet"), /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, " \xB7 MVP placeholder"), /*#__PURE__*/React.createElement("div", {
    className: "muted",
    style: {
      marginTop: 2
    }
  }, "Open your Pearl Desktop Wallet and send the amount above to this address. ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'var(--accent)'
    }
  }, "Help \u2192")))), showTx && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 4
    }
  }, "funding transaction"), /*#__PURE__*/React.createElement("div", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--accent)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'inherit'
    }
  }, SAMPLE.fundTxid.slice(0, 12), "\u2026", SAMPLE.fundTxid.slice(-8)), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted-2)',
      marginLeft: 8
    }
  }, "\u2197 block explorer"))), status === 'released' && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 4
    }
  }, "release transaction"), /*#__PURE__*/React.createElement("div", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--accent)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'inherit'
    }
  }, SAMPLE.releaseTxid.slice(0, 12), "\u2026", SAMPLE.releaseTxid.slice(-8))))));
}

// ─── Base card (chain leg) ───────────────────────────────────────────────────
function BaseCard({
  status = 'awaiting',
  wallet = 'connected',
  network = 'right'
}) {
  // status: nowallet | wrongchain | awaiting | submitting | pending | confirming | confirmed | refunded
  let cta,
    ctaTone = 'accent',
    ctaDisabled = false;
  let confLine = '0 / 12 confirmations';
  if (status === 'nowallet') cta = "Connect wallet";else if (status === 'wrongchain') {
    cta = "Switch to Base Sepolia";
    ctaTone = 'primary';
  } else if (status === 'awaiting') cta = "Deposit USDC";else if (status === 'submitting') cta = /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "spin"
  }), "Submitting \u2014 confirm in wallet\u2026");else if (status === 'pending') {
    cta = "Deposit submitted ↗";
    ctaDisabled = true;
    confLine = '0 / 12 confirmations';
  } else if (status === 'confirming') {
    cta = "Deposit confirmed ✓";
    ctaDisabled = true;
    confLine = '4 / 12 confirmations';
  } else if (status === 'confirmed') {
    cta = "Deposit confirmed ✓";
    ctaDisabled = true;
    confLine = '12 / 12 confirmations';
  } else if (status === 'refunded') {
    cta = "USDC refunded";
    ctaDisabled = true;
    confLine = 'refund 12 / 12 confirmations';
    ctaTone = 'primary';
  } else if (status === 'closed') {
    cta = "Deposit window closed";
    ctaDisabled = true;
  }
  const walletPill = {
    connected: /*#__PURE__*/React.createElement("span", {
      className: "pill ok"
    }, /*#__PURE__*/React.createElement("span", {
      className: "dot"
    }), "wallet \xB7 0x7a4c\u20268a4E"),
    disconnected: /*#__PURE__*/React.createElement("span", {
      className: "pill"
    }, /*#__PURE__*/React.createElement("span", {
      className: "dot"
    }), "wallet \xB7 disconnected")
  }[wallet];
  const netPill = {
    right: /*#__PURE__*/React.createElement("span", {
      className: "pill ok"
    }, /*#__PURE__*/React.createElement("span", {
      className: "dot"
    }), "network \xB7 base-sepolia"),
    wrong: /*#__PURE__*/React.createElement("span", {
      className: "pill warn"
    }, /*#__PURE__*/React.createElement("span", {
      className: "dot"
    }), "network \xB7 wrong chain"),
    none: /*#__PURE__*/React.createElement("span", {
      className: "pill"
    }, /*#__PURE__*/React.createElement("span", {
      className: "dot"
    }), "network \xB7 \u2014")
  }[network];
  const allowPill = {
    awaiting: /*#__PURE__*/React.createElement("span", {
      className: "pill"
    }, /*#__PURE__*/React.createElement("span", {
      className: "dot"
    }), "allowance \xB7 pending"),
    confirmed: /*#__PURE__*/React.createElement("span", {
      className: "pill ok"
    }, /*#__PURE__*/React.createElement("span", {
      className: "dot"
    }), "allowance \xB7 granted"),
    refunded: /*#__PURE__*/React.createElement("span", {
      className: "pill ok"
    }, /*#__PURE__*/React.createElement("span", {
      className: "dot"
    }), "allowance \xB7 granted")
  }[status] || /*#__PURE__*/React.createElement("span", {
    className: "pill"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "allowance \xB7 \u2014");
  return /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "h2"
  }, "Base leg"), /*#__PURE__*/React.createElement(NetChip, {
    chain: "base",
    env: "sepolia"
  })), status === 'confirmed' || status === 'pending' || status === 'confirming' ? /*#__PURE__*/React.createElement("span", {
    className: "badge ok"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "Funded") : status === 'refunded' ? /*#__PURE__*/React.createElement("span", {
    className: "badge warn"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "Refunded") : /*#__PURE__*/React.createElement("span", {
    className: "badge neutral"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "Awaiting USDC")), /*#__PURE__*/React.createElement("div", {
    className: "card-pad"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 6
    }
  }, "escrow contract"), /*#__PURE__*/React.createElement(Addr, {
    value: SAMPLE.baseEscrow
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 6
    }
  }, "trade key"), /*#__PURE__*/React.createElement(Addr, {
    value: SAMPLE.tradeKey
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 4
    }
  }, "expected amount"), /*#__PURE__*/React.createElement(AmountBig, {
    whole: "8,237",
    frac: ".500000",
    unit: "USDC"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right',
      fontSize: 11.5,
      color: 'var(--muted)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "mono"
  }, confLine.split(' ')[0], " / 12"), /*#__PURE__*/React.createElement("div", null, "confirmations"))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: `btn lg ${ctaTone}`,
    disabled: ctaDisabled,
    style: {
      width: '100%',
      justifyContent: 'center'
    }
  }, cta), /*#__PURE__*/React.createElement("div", {
    className: "pillrow",
    style: {
      marginTop: 10
    }
  }, walletPill, netPill, allowPill)), (status === 'pending' || status === 'confirming' || status === 'confirmed') && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 4
    }
  }, "deposit transaction"), /*#__PURE__*/React.createElement("div", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--accent)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'inherit'
    }
  }, SAMPLE.depositHash.slice(0, 14), "\u2026", SAMPLE.depositHash.slice(-8)), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted-2)',
      marginLeft: 8
    }
  }, "\u2197 basescan"))), status === 'refunded' && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 4
    }
  }, "refund transaction"), /*#__PURE__*/React.createElement("div", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--accent)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'inherit'
    }
  }, SAMPLE.refundHash.slice(0, 14), "\u2026", SAMPLE.refundHash.slice(-8))))));
}

// ─── Quote summary card (used in /quote and /accept) ─────────────────────────
function QuoteSummary({
  expired = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      background: 'var(--surface-2)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/React.createElement("span", {
    className: "h2"
  }, "Quote"), expired ? /*#__PURE__*/React.createElement("span", {
    className: "badge neutral"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "expired") : /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontSize: 11,
      display: 'flex',
      alignItems: 'center',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement(ClockIcon, null), " expires in ", /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--warn)'
    }
  }, "00:42"))), /*#__PURE__*/React.createElement("div", {
    className: "card-pad",
    style: {
      paddingTop: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 18,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 4
    }
  }, "you receive"), /*#__PURE__*/React.createElement(AmountBig, {
    whole: "12,500",
    frac: ".00000000",
    unit: "PRL"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 4
    }
  }, "you pay"), /*#__PURE__*/React.createElement(AmountBig, {
    whole: "8,237",
    frac: ".500000",
    unit: "USDC"
  }))), /*#__PURE__*/React.createElement("dl", {
    className: "kv"
  }, /*#__PURE__*/React.createElement("dt", null, "price"), /*#__PURE__*/React.createElement("dd", {
    className: "mono"
  }, "0.659000 ", /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, "USDC / PRL")), /*#__PURE__*/React.createElement("dt", null, "fee (PRL leg)"), /*#__PURE__*/React.createElement("dd", {
    className: "mono"
  }, "12.50000000 PRL"), /*#__PURE__*/React.createElement("dt", null, "fee (USDC leg)"), /*#__PURE__*/React.createElement("dd", {
    className: "mono"
  }, "8.235000 USDC"), /*#__PURE__*/React.createElement("dt", null, "settlement"), /*#__PURE__*/React.createElement("dd", null, /*#__PURE__*/React.createElement(NetChip, {
    chain: "base",
    env: "sepolia"
  }), " \xB7 USDC"))));
}
function ClockIcon() {
  return /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "11",
    viewBox: "0 0 11 11",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.2"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "5.5",
    cy: "5.5",
    r: "4.5"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M5.5 3v2.7l1.7 1",
    strokeLinecap: "round"
  }));
}

// ─── Annotation (yellow callout) ─────────────────────────────────────────────
function Annot({
  children,
  top,
  left,
  right,
  bottom,
  arrow = 'tl-arrow',
  width
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: `annot ${arrow}`,
    style: {
      top,
      left,
      right,
      bottom,
      width
    }
  }, children);
}

// ─── Page shell ──────────────────────────────────────────────────────────────
function PageShell({
  path,
  role = 'buyer',
  env = 'testnet',
  adminChrome = false,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "pearl",
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(Chrome, {
    path: path
  }), adminChrome ? /*#__PURE__*/React.createElement(AdminTopNav, null) : /*#__PURE__*/React.createElement(TopNav, {
    env: env,
    role: role
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'hidden',
      position: 'relative'
    }
  }, children));
}
Object.assign(window, {
  Chrome,
  TopNav,
  AdminTopNav,
  PageShell,
  StateBadge,
  NetChip,
  CopyIcon,
  Addr,
  AmountBig,
  AmountMed,
  TradeId,
  Countdown,
  Banner,
  FailureBanner,
  Timeline,
  TradeHeader,
  PearlCard,
  BaseCard,
  QuoteSummary,
  ClockIcon,
  Annot
});

// ═══ src/page-quote.jsx ═══

// /quote — Request For Quote
// Variants: empty · validated · invalid · loading · returned · expired-before-accept

function QuoteForm({
  values = {},
  errors = {},
  loading = false,
  submitted = false
}) {
  const v = {
    side: 'buy',
    amount: '',
    pearlAddr: '',
    refundAddr: '',
    ...values
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface)',
      border: '1px solid var(--hairline)',
      borderRadius: 'var(--r-3)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "tabs",
    style: {
      padding: '0 18px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: `tab ${v.side === 'buy' ? 'active' : ''}`
  }, "Buy PRL"), /*#__PURE__*/React.createElement("div", {
    className: `tab ${v.side === 'sell' ? 'active' : ''}`
  }, "Sell PRL")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '22px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "label"
  }, "Amount in PRL ", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("input", {
    className: `input mono ${errors.amount ? 'error' : ''}`,
    value: v.amount,
    placeholder: "0.00000000",
    readOnly: true,
    style: {
      paddingRight: 50
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      position: 'absolute',
      right: 12,
      top: '50%',
      transform: 'translateY(-50%)',
      fontSize: 11,
      color: 'var(--muted)',
      pointerEvents: 'none'
    }
  }, "PRL")), errors.amount ? /*#__PURE__*/React.createElement("div", {
    className: "help err"
  }, errors.amount) : /*#__PURE__*/React.createElement("div", {
    className: "help"
  }, "8-decimal precision \xB7 minimum 100.00000000 PRL \xB7 maximum 2,000,000.00000000 PRL")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "label"
  }, "Buyer Pearl address ", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    className: `input mono ${errors.pearlAddr ? 'error' : ''}`,
    value: v.pearlAddr,
    placeholder: "tprl1p\u2026",
    readOnly: true
  }), errors.pearlAddr ? /*#__PURE__*/React.createElement("div", {
    className: "help err"
  }, errors.pearlAddr) : /*#__PURE__*/React.createElement("div", {
    className: "help"
  }, "bech32m, network ", /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "testnet2"), " (HRP ", /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "tprl"), ")")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "label"
  }, "Refund Base address ", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    className: `input mono ${errors.refundAddr ? 'error' : ''}`,
    value: v.refundAddr,
    placeholder: "0x\u2026",
    readOnly: true
  }), errors.refundAddr ? /*#__PURE__*/React.createElement("div", {
    className: "help err"
  }, errors.refundAddr) : /*#__PURE__*/React.createElement("div", {
    className: "help"
  }, "EVM hex \xB7 used only if the trade is refunded")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 12,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    className: "label"
  }, "Settlement asset"), /*#__PURE__*/React.createElement("div", {
    className: "input locked mono",
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", null, "USDC"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: 'var(--muted-2)'
    }
  }, "LOCKED"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    className: "label"
  }, "Settlement network"), /*#__PURE__*/React.createElement("div", {
    className: "input locked mono",
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", null, "Base \xB7 sepolia"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: 'var(--muted-2)'
    }
  }, "LOCKED")))), /*#__PURE__*/React.createElement("button", {
    className: `btn lg ${submitted || loading ? 'primary' : 'accent'}`,
    disabled: loading,
    style: {
      width: '100%',
      justifyContent: 'center'
    }
  }, loading ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "spin"
  }), "Requesting quote\u2026") : 'Request quote'), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14,
      padding: '10px 12px',
      background: 'var(--surface-2)',
      border: '1px solid var(--hairline)',
      borderRadius: 'var(--r-2)',
      display: 'flex',
      gap: 10,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted-2)',
      fontSize: 12
    }
  }, "\u24D8"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11.5,
      color: 'var(--muted)',
      lineHeight: 1.5
    }
  }, "Quotes are valid for 60 seconds after issue. The desk fills ", /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "sellerPearlRefund"), " and ", /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "sellerUsdcReceive"), " automatically; you'll only ever see them on the proof page."))));
}
function QuoteResultCard({
  expired = false
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(QuoteSummary, {
    expired: expired
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 14
    }
  }, expired ? /*#__PURE__*/React.createElement("button", {
    className: "btn primary",
    style: {
      flex: 1,
      justifyContent: 'center'
    }
  }, "Quote expired \u2014 request a new one") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("button", {
    className: "btn accent lg",
    style: {
      flex: 1,
      justifyContent: 'center'
    }
  }, "Accept quote \u2192"), /*#__PURE__*/React.createElement("button", {
    className: "btn ghost lg",
    style: {
      justifyContent: 'center'
    }
  }, "Cancel"))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18,
      fontSize: 11,
      color: 'var(--muted)',
      lineHeight: 1.55
    }
  }, "Accepting allocates an escrow address on each chain. You commit to funding the Base leg within the deposit window shown on the next screen. Releases are server-driven and irreversible."));
}
function PageBase({
  children,
  leftAnnot,
  rightAnnot,
  path = "/quote",
  env = "testnet"
}) {
  return /*#__PURE__*/React.createElement(PageShell, {
    path: path,
    env: env
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      overflow: 'auto',
      padding: '32px 56px 60px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 6
    }
  }, "Request for quote"), /*#__PURE__*/React.createElement("h1", {
    className: "h1"
  }, "Get a PRL \u2194 USDC quote")), /*#__PURE__*/React.createElement("div", {
    className: "muted",
    style: {
      fontSize: 12
    }
  }, "indicative pricing \xB7 valid 60s after issue")), children), leftAnnot, rightAnnot);
}

// ── Variants ────────────────────────────────────────────────────────────────

function QuoteEmpty() {
  return /*#__PURE__*/React.createElement(PageBase, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '520px 1fr',
      gap: 28,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(QuoteForm, null), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--paper-2)',
      border: '1px dashed var(--hairline)',
      borderRadius: 'var(--r-3)',
      padding: '40px 28px',
      color: 'var(--muted)',
      fontSize: 12.5,
      lineHeight: 1.55,
      minHeight: 360
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 10
    }
  }, "Quote"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--muted-2)',
      fontSize: 12
    }
  }, "Fill out the form on the left and request a quote. The desk will return an indicative price along with a 60-second window to accept."))));
}
function QuoteValidated() {
  return /*#__PURE__*/React.createElement(PageBase, {
    rightAnnot: /*#__PURE__*/React.createElement(Annot, {
      top: 210,
      left: 530,
      arrow: "tl-arrow"
    }, "Form is valid, but the Quote panel only populates after submit \u2014 the user still has to click ", /*#__PURE__*/React.createElement("strong", null, "Request quote"), ".")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '520px 1fr',
      gap: 28,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(QuoteForm, {
    values: {
      amount: '12,500.00000000',
      pearlAddr: SAMPLE.buyerPearl,
      refundAddr: SAMPLE.buyerBase
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--paper-2)',
      border: '1px dashed var(--hairline)',
      borderRadius: 'var(--r-3)',
      padding: '40px 28px',
      color: 'var(--muted)',
      fontSize: 12.5,
      minHeight: 360
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 10
    }
  }, "Quote"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--muted-2)'
    }
  }, "Awaiting quote \u2014 click ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ink)',
      fontWeight: 500
    }
  }, "Request quote"), "."))));
}
function QuoteInvalid() {
  return /*#__PURE__*/React.createElement(PageBase, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '520px 1fr',
      gap: 28,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(QuoteForm, {
    values: {
      amount: '12.5',
      pearlAddr: 'prl1pBADHRPxxx',
      refundAddr: '0x7a4'
    },
    errors: {
      amount: 'Amount must be at least 100.00000000 PRL.',
      pearlAddr: 'Address HRP "prl1" is mainnet, but this environment is testnet2. Expected "tprl1…".',
      refundAddr: 'Address is not a valid 42-char hex.'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--err-soft)',
      border: '1px solid var(--err-line)',
      borderRadius: 'var(--r-3)',
      padding: '18px 20px',
      minHeight: 360
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      color: 'var(--err)',
      marginBottom: 10
    }
  }, "3 issues to resolve"), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      paddingLeft: 0,
      listStyle: 'none',
      fontSize: 12.5,
      color: 'var(--err)',
      lineHeight: 1.7
    }
  }, /*#__PURE__*/React.createElement("li", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--err)'
    }
  }, "\xB7"), " Amount below minimum (100 PRL)"), /*#__PURE__*/React.createElement("li", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--err)'
    }
  }, "\xB7"), " Pearl address HRP doesn't match environment"), /*#__PURE__*/React.createElement("li", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--err)'
    }
  }, "\xB7"), " Refund Base address malformed")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14,
      paddingTop: 14,
      borderTop: '1px solid var(--err-line)',
      fontSize: 11.5,
      color: 'var(--err)',
      opacity: 0.85
    }
  }, "Validation runs client-side as you type. The desk re-validates on submit; address checks include checksums for both chains."))));
}
function QuoteLoading() {
  return /*#__PURE__*/React.createElement(PageBase, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '520px 1fr',
      gap: 28,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(QuoteForm, {
    values: {
      amount: '12,500.00000000',
      pearlAddr: SAMPLE.buyerPearl,
      refundAddr: SAMPLE.buyerBase
    },
    loading: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-2)',
      border: '1px solid var(--hairline)',
      borderRadius: 'var(--r-3)',
      padding: '18px 20px',
      minHeight: 360
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "h2"
  }, "Quote"), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontSize: 11,
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "spin"
  }), " requesting\u2026")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 18,
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 6
    }
  }, "you receive"), /*#__PURE__*/React.createElement("div", {
    className: "skel",
    style: {
      height: 30,
      width: '85%'
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 6
    }
  }, "you pay"), /*#__PURE__*/React.createElement("div", {
    className: "skel",
    style: {
      height: 30,
      width: '85%'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '120px 1fr',
      gap: '10px 18px'
    }
  }, ['price', 'fee (PRL)', 'fee (USDC)', 'settlement'].map(l => /*#__PURE__*/React.createElement(React.Fragment, {
    key: l
  }, /*#__PURE__*/React.createElement("div", {
    className: "muted",
    style: {
      fontSize: 12
    }
  }, l), /*#__PURE__*/React.createElement("div", {
    className: "skel",
    style: {
      height: 14,
      width: '60%'
    }
  })))))));
}
function QuoteReturned() {
  return /*#__PURE__*/React.createElement(PageBase, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '520px 1fr',
      gap: 28,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(QuoteForm, {
    values: {
      amount: '12,500.00000000',
      pearlAddr: SAMPLE.buyerPearl,
      refundAddr: SAMPLE.buyerBase
    },
    submitted: true
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(QuoteResultCard, null))));
}
function QuoteExpired() {
  return /*#__PURE__*/React.createElement(PageBase, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '520px 1fr',
      gap: 28,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(QuoteForm, {
    values: {
      amount: '12,500.00000000',
      pearlAddr: SAMPLE.buyerPearl,
      refundAddr: SAMPLE.buyerBase
    },
    submitted: true
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Banner, {
    tone: "neutral",
    title: "Quote expired before accept.",
    body: "Quote qte_01J5K8AB2 was issued at 14:21:26 UTC; window closed at 14:22:26 UTC.",
    action: null
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 14
    }
  }), /*#__PURE__*/React.createElement(QuoteResultCard, {
    expired: true
  }))));
}
window.PageQuote = {
  variants: [{
    id: 'empty',
    label: 'empty',
    Page: QuoteEmpty
  }, {
    id: 'validated',
    label: 'validated · pre-submit',
    Page: QuoteValidated
  }, {
    id: 'invalid',
    label: 'invalid · 3 form errors',
    Page: QuoteInvalid
  }, {
    id: 'loading',
    label: 'requesting quote',
    Page: QuoteLoading
  }, {
    id: 'returned',
    label: 'quote returned',
    Page: QuoteReturned
  }, {
    id: 'expired',
    label: 'quote expired',
    Page: QuoteExpired
  }]
};

// ═══ src/page-accept.jsx ═══

// /quote/:id/accept — confirm and accept
// Variants: buyer (seller fields hidden) · seller (?role=seller) · admin · expired · in-flight

function AcceptForm({
  role = 'buyer',
  expired = false,
  submitting = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface)',
      border: '1px solid var(--hairline)',
      borderRadius: 'var(--r-3)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/React.createElement("span", {
    className: "h2"
  }, "Confirm details"), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontSize: 11
    }
  }, "quote ", /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "qte_01J5K8AB2"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 22px'
    }
  }, role === 'admin' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '8px 12px',
      marginBottom: 18,
      background: 'var(--accent-soft)',
      border: '1px solid var(--accent-line)',
      borderRadius: 'var(--r-2)',
      fontSize: 11.5,
      color: 'var(--accent-ink)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11
    }
  }, "admin override"), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, "All four addresses are editable. Use ", /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "Fill from defaults \u2192"), " to seed seller fields from the desk preset.")), /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 10
    }
  }, "Buyer \xB7 counterparty receiving PRL"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "label"
  }, "Buyer Pearl address ", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    className: "input mono",
    value: SAMPLE.buyerPearl,
    readOnly: true
  }), /*#__PURE__*/React.createElement("div", {
    className: "help"
  }, "Pre-filled from quote \xB7 editable")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "label"
  }, "Buyer USDC address ", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("input", {
    className: "input mono",
    value: SAMPLE.buyerBase,
    readOnly: true,
    style: {
      paddingRight: 130
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "pill ok",
    style: {
      position: 'absolute',
      right: 8,
      top: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), " auto-filled \xB7 MetaMask")), /*#__PURE__*/React.createElement("div", {
    className: "help"
  }, "Auto-filled from connected EVM wallet \xB7 editable")), (role === 'seller' || role === 'admin') && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginTop: 22,
      marginBottom: 10,
      color: role === 'admin' ? 'var(--accent)' : 'var(--muted-2)'
    }
  }, "Seller \xB7 counterparty receiving USDC ", role === 'seller' && /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      textTransform: 'none',
      letterSpacing: 0,
      marginLeft: 6
    }
  }, "visible because ", /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "?role=seller"))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "label"
  }, "Seller Pearl refund address ", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    className: "input mono",
    value: role === 'admin' ? SAMPLE.pearlAddr : '',
    placeholder: "tprl1p\u2026",
    readOnly: true
  }), /*#__PURE__*/React.createElement("div", {
    className: "help"
  }, "PRL is returned here if the trade refunds.")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "label"
  }, "Seller USDC receive address ", /*#__PURE__*/React.createElement("span", {
    className: "req"
  }, "*")), /*#__PURE__*/React.createElement("input", {
    className: "input mono",
    value: role === 'admin' ? SAMPLE.baseReceive : '',
    placeholder: "0x\u2026",
    readOnly: true
  }), /*#__PURE__*/React.createElement("div", {
    className: "help"
  }, "Where the buyer's USDC is sent on release."))), role === 'buyer' && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18,
      padding: '10px 12px',
      background: 'var(--paper-2)',
      border: '1px solid var(--hairline)',
      borderRadius: 'var(--r-2)',
      fontSize: 11.5,
      color: 'var(--muted)',
      lineHeight: 1.55
    }
  }, "Seller addresses are filled by the desk; you will see them on the trade's public proof page after settlement."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 22,
      display: 'flex',
      gap: 10
    }
  }, expired ? /*#__PURE__*/React.createElement("button", {
    className: "btn lg primary",
    disabled: true,
    style: {
      flex: 1,
      justifyContent: 'center'
    }
  }, "Quote expired \u2014 request a new one") : submitting ? /*#__PURE__*/React.createElement("button", {
    className: "btn lg primary",
    disabled: true,
    style: {
      flex: 1,
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "spin"
  }), " Allocating escrows\u2026") : /*#__PURE__*/React.createElement("button", {
    className: "btn lg accent",
    style: {
      flex: 1,
      justifyContent: 'center'
    }
  }, "Accept and continue \u2192"), /*#__PURE__*/React.createElement("button", {
    className: "btn lg ghost",
    disabled: submitting
  }, "Back")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12,
      fontSize: 11,
      color: 'var(--muted)',
      lineHeight: 1.5
    }
  }, "By accepting you authorize the desk to allocate escrow addresses on both chains. Funding is your responsibility; releases are server-driven.")));
}
function PageAcceptBase({
  role = 'buyer',
  expired = false,
  submitting = false
}) {
  return /*#__PURE__*/React.createElement(PageShell, {
    path: `/quote/qte_01J5K8AB2/accept${role !== 'buyer' ? `?role=${role}` : ''}`
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      overflow: 'auto',
      padding: '32px 56px 60px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 6
    }
  }, "accept quote \xB7 ", role === 'admin' ? 'admin view' : role === 'seller' ? 'seller view' : 'buyer view'), /*#__PURE__*/React.createElement("h1", {
    className: "h1"
  }, "Confirm and accept this quote")), /*#__PURE__*/React.createElement("div", {
    className: "muted",
    style: {
      fontSize: 12,
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(ClockIcon, null), expired ? /*#__PURE__*/React.createElement(React.Fragment, null, "quote expired at ", /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--neutral)'
    }
  }, "14:22:26 UTC")) : /*#__PURE__*/React.createElement(React.Fragment, null, "expires in ", /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--warn)'
    }
  }, "00:38")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 440px',
      gap: 28,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(AcceptForm, {
    role: role,
    expired: expired,
    submitting: submitting
  }), /*#__PURE__*/React.createElement(QuoteSummary, {
    expired: expired
  }))));
}
const AcceptBuyer = () => /*#__PURE__*/React.createElement(PageAcceptBase, {
  role: "buyer"
});
const AcceptSeller = () => /*#__PURE__*/React.createElement(PageAcceptBase, {
  role: "seller"
});
const AcceptAdmin = () => /*#__PURE__*/React.createElement(PageAcceptBase, {
  role: "admin"
});
const AcceptExpired = () => /*#__PURE__*/React.createElement(PageAcceptBase, {
  role: "buyer",
  expired: true
});
const AcceptInFlight = () => /*#__PURE__*/React.createElement(PageAcceptBase, {
  role: "buyer",
  submitting: true
});
window.PageAccept = {
  variants: [{
    id: 'buyer',
    label: 'buyer view (seller fields hidden)',
    Page: AcceptBuyer
  }, {
    id: 'seller',
    label: 'seller view · ?role=seller',
    Page: AcceptSeller
  }, {
    id: 'admin',
    label: 'admin view · all fields editable',
    Page: AcceptAdmin
  }, {
    id: 'expired',
    label: 'quote expired during fill',
    Page: AcceptExpired
  }, {
    id: 'inflight',
    label: 'submit in flight',
    Page: AcceptInFlight
  }]
};

// ═══ src/page-trade.jsx ═══

// /trades/:tradeId — Customer checkout (hero screen).
// 17 variants — one shared layout, different state inputs.

// (destructure stripped)
// ── Layout ──────────────────────────────────────────────────────────────────

function TradeLayout({
  state = 'pearl_escrow_pending',
  pearlStatus = 'pending',
  pearlConf = 0,
  baseStatus = 'awaiting',
  baseWallet = 'connected',
  baseNetwork = 'right',
  failureState,
  timeline = TL_EVENTS.pearl_escrow_pending,
  banner,
  extraBelow,
  showRefundAction = false,
  showRefundedBanner = false
}) {
  return /*#__PURE__*/React.createElement(PageShell, {
    path: `/trades/${SAMPLE.tradeId}`
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      overflow: 'auto'
    }
  }, /*#__PURE__*/React.createElement(TradeHeader, {
    state: state
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px 28px 60px'
    }
  }, failureState && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(FailureBanner, {
    state: failureState
  })), banner && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 18
    }
  }, banner), showRefundedBanner && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(Banner, {
    tone: "warn",
    title: "This trade has been refunded.",
    body: "USDC was returned to the buyer's refund address. PRL was returned to the seller. No further action required."
  })), showRefundAction && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(Banner, {
    tone: "warn",
    title: "Refund is now available.",
    body: "The buyer leg is past its refund window without confirmation. You may request a refund of any deposited USDC.",
    action: "Request refund \u2192"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 20,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(PearlCard, {
    status: pearlStatus,
    confirmations: pearlConf
  }), /*#__PURE__*/React.createElement(BaseCard, {
    status: baseStatus,
    wallet: baseWallet,
    network: baseNetwork
  })), extraBelow, /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/React.createElement("span", {
    className: "h2"
  }, "Activity"), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontSize: 11
    }
  }, "events stream \xB7 server-authoritative")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '6px 18px 12px'
    }
  }, /*#__PURE__*/React.createElement(Timeline, {
    events: timeline
  })))))));
}

// ── Variant constructors ────────────────────────────────────────────────────

// 1 — pearl_escrow_pending: both legs empty (the hero/canonical state)
const TradePending = () => /*#__PURE__*/React.createElement(TradeLayout, {
  state: "pearl_escrow_pending",
  pearlStatus: "pending",
  baseStatus: "awaiting",
  timeline: TL_EVENTS.pearl_escrow_pending
});

// 2 — Pearl funded only (observed + 3/6 confirmations)
const TradePearlOnly = () => /*#__PURE__*/React.createElement(TradeLayout, {
  state: "pearl_escrow_seen",
  pearlStatus: "seen",
  pearlConf: 3,
  baseStatus: "awaiting",
  timeline: TL_EVENTS.pearl_seen
});

// 3 — Base funded only — Pearl still pending
const TradeBaseOnly = () => /*#__PURE__*/React.createElement(TradeLayout, {
  state: "usdc_escrow_pending",
  pearlStatus: "pending",
  baseStatus: "confirming",
  timeline: [{
    chain: "sys",
    ev: "Quote accepted; escrows allocated",
    meta: "14:22:08 UTC",
    time: "9 min ago"
  }, {
    chain: "base",
    ev: "USDC deposit observed",
    meta: "0xc4d5…c4d5",
    time: "5 min ago"
  }, {
    chain: "base",
    ev: "Confirmation 4 of 12",
    meta: "block 21,007,442",
    time: "1 min ago"
  }]
});

// 4 — Both confirming
const TradeBothConfirming = () => /*#__PURE__*/React.createElement(TradeLayout, {
  state: "usdc_escrow_confirmed",
  pearlStatus: "confirmed",
  baseStatus: "confirming",
  timeline: TL_EVENTS.both_confirming
});

// 5 — Release pending (both confirmed, releases broadcasting)
const TradeReleasePending = () => /*#__PURE__*/React.createElement(TradeLayout, {
  state: "release_pending",
  pearlStatus: "confirmed",
  baseStatus: "confirmed",
  banner: /*#__PURE__*/React.createElement(Banner, {
    tone: "info",
    title: "Releases broadcasting on both chains.",
    body: "No action required. Both legs are funded and confirmed; the desk is broadcasting release transactions now.",
    action: null
  }),
  timeline: [...TL_EVENTS.both_confirming.slice(0, -1), {
    chain: "base",
    ev: "USDC deposit confirmed",
    meta: "12/12 confirmations",
    time: "3 min ago"
  }, {
    chain: "sys",
    ev: "Release authorized",
    meta: "server-driven · idempotency 0x7e…2a",
    time: "1 min ago"
  }, {
    chain: "pearl",
    ev: "PRL release submitted",
    meta: "broadcasting…",
    time: "30s ago"
  }, {
    chain: "base",
    ev: "USDC release submitted",
    meta: "broadcasting…",
    time: "20s ago"
  }]
});

// 6 — Released (terminal happy)
const TradeReleased = () => /*#__PURE__*/React.createElement(TradeLayout, {
  state: "released",
  pearlStatus: "released",
  baseStatus: "confirmed",
  banner: /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: '14px 18px',
      background: 'var(--ok-soft)',
      border: '1px solid var(--ok-line)',
      borderRadius: 'var(--r-3)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 28,
      height: 28,
      borderRadius: '50%',
      background: 'var(--ok)',
      color: '#fff',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 14,
      fontWeight: 600
    }
  }, "\u2713"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      color: 'var(--ok)',
      fontSize: 14
    }
  }, "Trade released."), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--ok)',
      opacity: 0.85,
      marginTop: 2
    }
  }, "12,500.00000000 PRL delivered to buyer \xB7 8,237.500000 USDC delivered to seller \xB7 settled in 23m 03s.")), /*#__PURE__*/React.createElement("a", {
    href: "#",
    className: "btn sm",
    style: {
      background: 'var(--surface)',
      borderColor: 'var(--ok-line)',
      color: 'var(--ok)'
    }
  }, "View public proof \u2192")),
  timeline: TL_EVENTS.released
});

// 7–15: Nine failure states. Each shares the standardized banner + the cards
// stay visible behind it so the audit context isn't hidden.

const TradeFailure = ({
  failure,
  pearlStatus,
  baseStatus,
  timeline,
  pearlConf
}) => /*#__PURE__*/React.createElement(TradeLayout, {
  state: failure,
  failureState: failure,
  pearlStatus: pearlStatus,
  baseStatus: baseStatus,
  pearlConf: pearlConf,
  timeline: timeline || TL_EVENTS.failure_generic
});
const TradeLatePrl = () => /*#__PURE__*/React.createElement(TradeFailure, {
  failure: "late_prl_funding",
  pearlStatus: "late",
  baseStatus: "awaiting",
  timeline: [{
    chain: "sys",
    ev: "Quote accepted; escrows allocated",
    meta: "14:22:08 UTC",
    time: "47 min ago"
  }, {
    chain: "err",
    ev: "pearl_funding deadline crossed",
    meta: "no Pearl deposit observed · 14:42:08 UTC",
    time: "27 min ago"
  }, {
    chain: "pearl",
    ev: "Pearl deposit observed (LATE)",
    meta: "f3c1a9…f1a2 · 4m 21s after deadline",
    time: "23 min ago"
  }, {
    chain: "pearl",
    ev: "Pearl deposit confirmed",
    meta: "6/6 confirmations · funding will not authorize release",
    time: "16 min ago"
  }, {
    chain: "err",
    ev: "State entered: late_prl_funding",
    meta: "manual review queued",
    time: "16 min ago"
  }]
});
const TradeUsdcRefunded = () => /*#__PURE__*/React.createElement(TradeFailure, {
  failure: "usdc_refunded",
  pearlStatus: "confirmed",
  baseStatus: "refunded",
  timeline: [{
    chain: "sys",
    ev: "Quote accepted; escrows allocated",
    meta: "14:22:08 UTC",
    time: "1h 4m ago"
  }, {
    chain: "pearl",
    ev: "Pearl deposit confirmed",
    meta: "6/6 confirmations",
    time: "52 min ago"
  }, {
    chain: "base",
    ev: "USDC deposit observed",
    meta: "0xc4d5…c4d5",
    time: "44 min ago"
  }, {
    chain: "err",
    ev: "settlement deadline crossed",
    meta: "auto-refund initiated",
    time: "21 min ago"
  }, {
    chain: "base",
    ev: "USDC refund broadcast",
    meta: "0xe5f6…e5f6",
    time: "20 min ago"
  }, {
    chain: "base",
    ev: "USDC refund confirmed",
    meta: "12/12 confirmations",
    time: "8 min ago"
  }, {
    chain: "err",
    ev: "State entered: usdc_refunded",
    meta: "PRL release blocked pending review",
    time: "8 min ago"
  }]
});
const TradeReleaseFailed = () => /*#__PURE__*/React.createElement(TradeFailure, {
  failure: "prl_release_failed",
  pearlStatus: "confirmed",
  baseStatus: "confirmed",
  timeline: [{
    chain: "pearl",
    ev: "Pearl deposit confirmed",
    meta: "6/6 confirmations",
    time: "38 min ago"
  }, {
    chain: "base",
    ev: "USDC deposit confirmed",
    meta: "12/12 confirmations",
    time: "29 min ago"
  }, {
    chain: "sys",
    ev: "Release authorized",
    meta: "idempotency 0x7e…2a",
    time: "22 min ago"
  }, {
    chain: "err",
    ev: "PRL release broadcast failed",
    meta: "rpc: rejected · reason: utxo_already_spent",
    time: "22 min ago"
  }, {
    chain: "err",
    ev: "Retry 1 of 3 failed",
    meta: "rpc: rejected · 21 min ago",
    time: "21 min ago"
  }, {
    chain: "err",
    ev: "Retry 2 of 3 failed",
    meta: "rpc: rejected · 20 min ago",
    time: "20 min ago"
  }, {
    chain: "err",
    ev: "Retry 3 of 3 failed → manual review",
    meta: "operator notified · 17 min ago",
    time: "17 min ago"
  }]
});
const TradeMismatch = () => /*#__PURE__*/React.createElement(TradeFailure, {
  failure: "amount_mismatch",
  pearlStatus: "mismatch",
  baseStatus: "awaiting",
  timeline: [{
    chain: "pearl",
    ev: "Pearl deposit observed",
    meta: "f3c1a9…f1a2",
    time: "31 min ago"
  }, {
    chain: "err",
    ev: "Amount mismatch detected",
    meta: "expected 12,500.00000000 PRL · observed 12,498.40000000 PRL · −1.60000000",
    time: "31 min ago"
  }, {
    chain: "err",
    ev: "State entered: amount_mismatch",
    meta: "settlement halted pending review",
    time: "31 min ago"
  }]
});
const TradeReorged = () => /*#__PURE__*/React.createElement(TradeFailure, {
  failure: "reorged",
  pearlStatus: "reorged",
  baseStatus: "awaiting",
  timeline: [{
    chain: "pearl",
    ev: "Pearl deposit observed",
    meta: "f3c1a9…f1a2 · block 18,432,901",
    time: "47 min ago"
  }, {
    chain: "pearl",
    ev: "Confirmations 1–3",
    meta: "block 18,432,901 → 18,432,903",
    time: "42 min ago"
  }, {
    chain: "err",
    ev: "Reorg detected",
    meta: "block 18,432,901 orphaned · depth 4",
    time: "12 min ago"
  }, {
    chain: "err",
    ev: "State entered: reorged",
    meta: "awaiting re-confirmation on canonical chain",
    time: "12 min ago"
  }]
});
const TradeStaleIdx = () => /*#__PURE__*/React.createElement(TradeFailure, {
  failure: "stale_indexer",
  pearlStatus: "confirmed",
  baseStatus: "awaiting",
  timeline: [{
    chain: "pearl",
    ev: "Pearl deposit confirmed",
    meta: "6/6 confirmations · 23 min ago",
    time: "23 min ago"
  }, {
    chain: "sys",
    ev: "Indexer lag warning",
    meta: "lag 42s · threshold 30s",
    time: "4 min ago"
  }, {
    chain: "err",
    ev: "State entered: stale_indexer",
    meta: "status may not reflect chain truth",
    time: "4 min ago"
  }]
});
const TradeUnknownSpend = () => /*#__PURE__*/React.createElement(TradeFailure, {
  failure: "unknown_spend",
  pearlStatus: "unknown",
  baseStatus: "awaiting",
  timeline: [{
    chain: "pearl",
    ev: "Pearl deposit confirmed",
    meta: "6/6 confirmations",
    time: "1h 12m ago"
  }, {
    chain: "err",
    ev: "Escrow output spent by unknown tx",
    meta: "spent in tx 9e2a3b…0c1d · not desk-authored",
    time: "8 min ago"
  }, {
    chain: "err",
    ev: "State entered: unknown_spend",
    meta: "audit triggered · operator paged",
    time: "8 min ago"
  }]
});
const TradeManualReview = () => /*#__PURE__*/React.createElement(TradeFailure, {
  failure: "failed_manual_review",
  pearlStatus: "confirmed",
  baseStatus: "confirmed",
  timeline: [{
    chain: "pearl",
    ev: "Pearl deposit confirmed",
    meta: "6/6 confirmations",
    time: "55 min ago"
  }, {
    chain: "base",
    ev: "USDC deposit confirmed",
    meta: "12/12 confirmations",
    time: "47 min ago"
  }, {
    chain: "err",
    ev: "Flagged for manual review",
    meta: "by op_07 · reason: counterparty KYC re-check",
    time: "12 min ago"
  }, {
    chain: "err",
    ev: "State entered: failed_manual_review",
    meta: "settlement halted",
    time: "12 min ago"
  }]
});
const TradeDisputed = () => /*#__PURE__*/React.createElement(TradeFailure, {
  failure: "disputed",
  pearlStatus: "confirmed",
  baseStatus: "confirmed",
  timeline: [{
    chain: "pearl",
    ev: "Pearl deposit confirmed",
    meta: "6/6 confirmations",
    time: "2h 13m ago"
  }, {
    chain: "base",
    ev: "USDC deposit confirmed",
    meta: "12/12 confirmations",
    time: "2h 7m ago"
  }, {
    chain: "err",
    ev: "Dispute opened",
    meta: "by counterparty · ticket DPT-0044 · reason: counterparty_unreachable",
    time: "1h 8m ago"
  }, {
    chain: "err",
    ev: "State entered: disputed",
    meta: "release blocked until dispute resolves",
    time: "1h 8m ago"
  }]
});

// 16 — refund_available
const TradeRefundAvail = () => /*#__PURE__*/React.createElement(TradeLayout, {
  state: "refund_available",
  pearlStatus: "pending",
  baseStatus: "confirmed",
  showRefundAction: true,
  timeline: [{
    chain: "sys",
    ev: "Quote accepted; escrows allocated",
    meta: "14:22:08 UTC",
    time: "1h 12m ago"
  }, {
    chain: "base",
    ev: "USDC deposit confirmed",
    meta: "12/12 confirmations",
    time: "57 min ago"
  }, {
    chain: "err",
    ev: "pearl_funding deadline crossed",
    meta: "no Pearl deposit observed",
    time: "32 min ago"
  }, {
    chain: "sys",
    ev: "Refund window opened",
    meta: "buyer may request refund",
    time: "just now"
  }]
});

// 17 — refunded (terminal refund)
const TradeRefunded = () => /*#__PURE__*/React.createElement(TradeLayout, {
  state: "refunded",
  pearlStatus: "pending",
  baseStatus: "refunded",
  showRefundedBanner: true,
  timeline: [{
    chain: "sys",
    ev: "Quote accepted; escrows allocated",
    meta: "14:22:08 UTC",
    time: "2h 4m ago"
  }, {
    chain: "base",
    ev: "USDC deposit confirmed",
    meta: "12/12 confirmations",
    time: "1h 49m ago"
  }, {
    chain: "err",
    ev: "pearl_funding deadline crossed",
    meta: "no Pearl deposit observed",
    time: "1h 24m ago"
  }, {
    chain: "sys",
    ev: "Refund requested",
    meta: "by buyer",
    time: "52 min ago"
  }, {
    chain: "base",
    ev: "USDC refund broadcast",
    meta: "0xe5f6…e5f6",
    time: "51 min ago"
  }, {
    chain: "base",
    ev: "USDC refund confirmed",
    meta: "12/12 confirmations",
    time: "40 min ago"
  }, {
    chain: "ok",
    ev: "Trade refunded",
    meta: "terminal · ledger closed",
    time: "40 min ago"
  }]
});
window.PageTrade = {
  variants: [{
    id: 'pending',
    label: 'pearl_escrow_pending · canonical',
    Page: TradePending,
    height: 1080
  }, {
    id: 'pearl-only',
    label: 'Pearl funded only · 3/6 confirmations',
    Page: TradePearlOnly,
    height: 1080
  }, {
    id: 'base-only',
    label: 'Base funded only · Pearl still pending',
    Page: TradeBaseOnly,
    height: 1080
  }, {
    id: 'both-confirming',
    label: 'both confirming',
    Page: TradeBothConfirming,
    height: 1080
  }, {
    id: 'release-pending',
    label: 'release_pending',
    Page: TradeReleasePending,
    height: 1080
  }, {
    id: 'released',
    label: 'released · terminal happy',
    Page: TradeReleased,
    height: 1080
  }, {
    id: 'late-prl',
    label: 'late_prl_funding',
    Page: TradeLatePrl,
    height: 1160
  }, {
    id: 'usdc-refunded',
    label: 'usdc_refunded',
    Page: TradeUsdcRefunded,
    height: 1160
  }, {
    id: 'release-failed',
    label: 'prl_release_failed',
    Page: TradeReleaseFailed,
    height: 1160
  }, {
    id: 'mismatch',
    label: 'amount_mismatch',
    Page: TradeMismatch,
    height: 1100
  }, {
    id: 'reorged',
    label: 'reorged',
    Page: TradeReorged,
    height: 1100
  }, {
    id: 'stale-indexer',
    label: 'stale_indexer',
    Page: TradeStaleIdx,
    height: 1100
  }, {
    id: 'unknown-spend',
    label: 'unknown_spend',
    Page: TradeUnknownSpend,
    height: 1100
  }, {
    id: 'manual-review',
    label: 'failed_manual_review',
    Page: TradeManualReview,
    height: 1100
  }, {
    id: 'disputed',
    label: 'disputed',
    Page: TradeDisputed,
    height: 1100
  }, {
    id: 'refund-avail',
    label: 'refund_available',
    Page: TradeRefundAvail,
    height: 1100
  }, {
    id: 'refunded',
    label: 'refunded · terminal',
    Page: TradeRefunded,
    height: 1100
  }]
};

// ═══ src/page-proof.jsx ═══

// /trades/:tradeId/proof — Public verifiable receipt.
// Read-only · dense · prints well to PDF. No auth required.

function ProofHeader({
  state = 'released'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface)',
      borderBottom: '1px solid var(--hairline)',
      padding: '20px 56px 22px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "topnav-glyph",
    style: {
      width: 22,
      height: 22,
      borderRadius: '50%',
      background: 'radial-gradient(circle at 35% 35%, #fff 0%, #ecebe1 30%, #cfcdb8 60%, #8b8973 100%)',
      boxShadow: 'inset 0 0 0 0.5px rgba(0,0,0,.12)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: 14,
      letterSpacing: -0.2
    }
  }, "Pearl OTC")), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontSize: 11
    }
  }, "\xB7 public proof page"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontSize: 11,
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, "generated ", /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--ink-2)'
    }
  }, "2026-05-17T15:01:43Z")), /*#__PURE__*/React.createElement("button", {
    className: "btn sm"
  }, "\u2193 download PDF")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 6
    }
  }, "trade \xB7 ", SAMPLE.tradeId), /*#__PURE__*/React.createElement("h1", {
    className: "h1",
    style: {
      fontSize: 20
    }
  }, "Verifiable receipt \u2014", /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--muted)',
      fontSize: 13,
      marginLeft: 8,
      fontWeight: 400
    }
  }, SAMPLE.tradeId))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(StateBadge, {
    state: state
  }))));
}
function ProofSection({
  title,
  num,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      marginBottom: 32,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 10,
      marginBottom: 12,
      paddingBottom: 8,
      borderBottom: '1px solid var(--hairline)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--muted-2)'
    }
  }, num), /*#__PURE__*/React.createElement("h2", {
    className: "h2",
    style: {
      fontSize: 14
    }
  }, title)), children);
}

// Reusable kv-row table
function FactTable({
  rows
}) {
  return /*#__PURE__*/React.createElement("table", {
    className: "tbl",
    style: {
      tableLayout: 'fixed'
    }
  }, /*#__PURE__*/React.createElement("colgroup", null, /*#__PURE__*/React.createElement("col", {
    style: {
      width: 200
    }
  }), /*#__PURE__*/React.createElement("col", null)), /*#__PURE__*/React.createElement("tbody", null, rows.map(([k, v, link], i) => /*#__PURE__*/React.createElement("tr", {
    key: i
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      color: 'var(--muted)',
      fontWeight: 500
    }
  }, k), /*#__PURE__*/React.createElement("td", {
    className: "mono",
    style: {
      wordBreak: 'break-all',
      fontSize: 11.5,
      color: link ? 'var(--accent)' : 'var(--ink)'
    }
  }, link ? /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'inherit'
    }
  }, v) : v, link && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted-2)',
      marginLeft: 8
    }
  }, "\u2197"))))));
}

// Side-effect ledger — every recorded action
const SIDE_EFFECTS_FULL = [{
  idem: 'sfx_01J5K8B2A1',
  actor: 'indexer:pearl',
  effect: 'pearl_deposit_observed',
  txid: 'f3c1a9…f1a2',
  status: 'ok',
  at: '2026-05-17T14:24:11Z'
}, {
  idem: 'sfx_01J5K8B2A2',
  actor: 'indexer:pearl',
  effect: 'pearl_deposit_confirmed',
  txid: 'f3c1a9…f1a2',
  status: 'ok',
  at: '2026-05-17T14:29:33Z'
}, {
  idem: 'sfx_01J5K8B2A3',
  actor: 'indexer:base',
  effect: 'usdc_deposit_observed',
  txid: '0xc4d5…c4d5',
  status: 'ok',
  at: '2026-05-17T14:36:08Z'
}, {
  idem: 'sfx_01J5K8B2A4',
  actor: 'indexer:base',
  effect: 'usdc_deposit_confirmed',
  txid: '0xc4d5…c4d5',
  status: 'ok',
  at: '2026-05-17T14:39:22Z'
}, {
  idem: 'sfx_01J5K8B2A5',
  actor: 'desk:authorize',
  effect: 'release_authorized',
  txid: '—',
  status: 'ok',
  at: '2026-05-17T14:42:01Z'
}, {
  idem: 'sfx_01J5K8B2A6',
  actor: 'desk:broadcast',
  effect: 'pearl_release_submitted',
  txid: 'a7b8c9…a7b8',
  status: 'ok',
  at: '2026-05-17T14:42:14Z'
}, {
  idem: 'sfx_01J5K8B2A7',
  actor: 'desk:broadcast',
  effect: 'usdc_release_submitted',
  txid: '0xa1b2…a1b2',
  status: 'ok',
  at: '2026-05-17T14:42:21Z'
}, {
  idem: 'sfx_01J5K8B2A8',
  actor: 'indexer:pearl',
  effect: 'pearl_release_confirmed',
  txid: 'a7b8c9…a7b8',
  status: 'ok',
  at: '2026-05-17T14:44:18Z'
}, {
  idem: 'sfx_01J5K8B2A9',
  actor: 'indexer:base',
  effect: 'usdc_release_confirmed',
  txid: '0xa1b2…a1b2',
  status: 'ok',
  at: '2026-05-17T14:45:11Z'
}];
const SIDE_EFFECTS_INPROG = SIDE_EFFECTS_FULL.slice(0, 4);
const SIDE_EFFECTS_REFUNDED = [...SIDE_EFFECTS_FULL.slice(0, 4), {
  idem: 'sfx_01J5K8C5R1',
  actor: 'desk:refund',
  effect: 'refund_requested',
  txid: '—',
  status: 'ok',
  at: '2026-05-17T15:34:08Z'
}, {
  idem: 'sfx_01J5K8C5R2',
  actor: 'desk:broadcast',
  effect: 'usdc_refund_submitted',
  txid: '0xe5f6…e5f6',
  status: 'ok',
  at: '2026-05-17T15:34:21Z'
}, {
  idem: 'sfx_01J5K8C5R3',
  actor: 'indexer:base',
  effect: 'usdc_refund_confirmed',
  txid: '0xe5f6…e5f6',
  status: 'ok',
  at: '2026-05-17T15:38:44Z'
}];
const SIDE_EFFECTS_FAIL = [...SIDE_EFFECTS_FULL.slice(0, 4), {
  idem: 'sfx_01J5K8D1F1',
  actor: 'desk:authorize',
  effect: 'release_authorized',
  txid: '—',
  status: 'ok',
  at: '2026-05-17T14:42:01Z'
}, {
  idem: 'sfx_01J5K8D1F2',
  actor: 'desk:broadcast',
  effect: 'pearl_release_submitted',
  txid: '—',
  status: 'err',
  at: '2026-05-17T14:42:14Z'
}, {
  idem: 'sfx_01J5K8D1F3',
  actor: 'desk:retry',
  effect: 'pearl_release_retry_1',
  txid: '—',
  status: 'err',
  at: '2026-05-17T14:43:11Z'
}, {
  idem: 'sfx_01J5K8D1F4',
  actor: 'desk:retry',
  effect: 'pearl_release_retry_2',
  txid: '—',
  status: 'err',
  at: '2026-05-17T14:44:14Z'
}, {
  idem: 'sfx_01J5K8D1F5',
  actor: 'desk:retry',
  effect: 'pearl_release_retry_3',
  txid: '—',
  status: 'err',
  at: '2026-05-17T14:45:14Z'
}, {
  idem: 'sfx_01J5K8D1F6',
  actor: 'desk:flag',
  effect: 'flagged_for_review',
  txid: '—',
  status: 'ok',
  at: '2026-05-17T14:45:20Z'
}];
function SideEffectsTable({
  rows
}) {
  return /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      width: 150
    }
  }, "idempotency"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 130
    }
  }, "actor"), /*#__PURE__*/React.createElement("th", null, "effect"), /*#__PURE__*/React.createElement("th", null, "tx"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 70
    }
  }, "status"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 180
    }
  }, "at"))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i
  }, /*#__PURE__*/React.createElement("td", {
    className: "mono",
    style: {
      fontSize: 11
    }
  }, r.idem), /*#__PURE__*/React.createElement("td", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--muted)'
    }
  }, r.actor), /*#__PURE__*/React.createElement("td", {
    className: "mono",
    style: {
      fontSize: 11
    }
  }, r.effect), /*#__PURE__*/React.createElement("td", {
    className: "mono",
    style: {
      fontSize: 11,
      color: r.txid !== '—' ? 'var(--accent)' : 'var(--muted-2)'
    }
  }, r.txid !== '—' ? /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'inherit'
    }
  }, r.txid) : '—'), /*#__PURE__*/React.createElement("td", null, r.status === 'ok' ? /*#__PURE__*/React.createElement("span", {
    className: "badge ok",
    style: {
      fontSize: 9.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "ok") : /*#__PURE__*/React.createElement("span", {
    className: "badge err",
    style: {
      fontSize: 9.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "err")), /*#__PURE__*/React.createElement("td", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--muted)'
    }
  }, r.at)))));
}
function ProofLayout({
  state = 'released',
  banner,
  pearlFundedAt = '2026-05-17T14:24:11Z',
  pearlConfirmedAt = '2026-05-17T14:29:33Z',
  pearlReleaseAt = '2026-05-17T14:42:14Z',
  pearlRefundAt,
  baseDepositAt = '2026-05-17T14:36:08Z',
  baseReleaseAt = '2026-05-17T14:42:21Z',
  baseRefundAt,
  sideEffects = SIDE_EFFECTS_FULL,
  events
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "pearl",
    style: {
      display: 'flex',
      flexDirection: 'column',
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement(Chrome, {
    path: `/trades/${SAMPLE.tradeId}/proof`
  }), /*#__PURE__*/React.createElement(ProofHeader, {
    state: state
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto',
      padding: '28px 56px 60px',
      background: 'var(--paper)'
    }
  }, banner && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 24
    }
  }, banner), /*#__PURE__*/React.createElement(ProofSection, {
    title: "Quote terms",
    num: "01"
  }, /*#__PURE__*/React.createElement(FactTable, {
    rows: [['side', 'BUY · buyer receives PRL, pays USDC'], ['amount (PRL)', '12,500.00000000  PRL'], ['amount (USDC)', '8,237.500000     USDC'], ['fee (PRL leg)', '12.50000000      PRL'], ['fee (USDC leg)', '8.235000         USDC'], ['price', '0.659000  USDC/PRL'], ['quote_id', 'qte_01J5K8AB2'], ['accepted_at', '2026-05-17T14:22:08Z']]
  })), /*#__PURE__*/React.createElement(ProofSection, {
    title: "Deadlines",
    num: "02"
  }, /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      width: 200
    }
  }, "deadline"), /*#__PURE__*/React.createElement("th", null, "absolute (ISO 8601)"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 200
    }
  }, "relative to acceptance"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 100
    }
  }, "status"))), /*#__PURE__*/React.createElement("tbody", null, [['quoteExpiresAt', '2026-05-17T14:22:26Z', 'accept + 0:00:18', 'expired'], ['pearlFundingDeadline', '2026-05-17T14:42:08Z', 'accept + 0:20:00', state === 'released' ? 'met' : state === 'refunded' || state === 'refund_available' ? 'missed' : 'pending'], ['usdcDepositDeadline', '2026-05-17T14:52:08Z', 'accept + 0:30:00', state === 'released' || state === 'refunded' ? 'met' : 'pending'], ['settlementDeadline', '2026-05-17T16:22:08Z', 'accept + 2:00:00', state === 'released' ? 'met' : 'pending'], ['refundAvailableAt', '2026-05-17T15:22:08Z', 'accept + 1:00:00', state === 'refunded' ? 'used' : state === 'refund_available' ? 'open' : 'closed']].map(([name, iso, rel, st]) => /*#__PURE__*/React.createElement("tr", {
    key: name
  }, /*#__PURE__*/React.createElement("td", {
    className: "mono",
    style: {
      fontSize: 11.5
    }
  }, name), /*#__PURE__*/React.createElement("td", {
    className: "mono",
    style: {
      fontSize: 11
    }
  }, iso), /*#__PURE__*/React.createElement("td", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--muted)'
    }
  }, rel), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: `badge ${st === 'met' ? 'ok' : st === 'missed' ? 'err' : st === 'expired' || st === 'used' ? 'neutral' : st === 'open' ? 'warn' : 'neutral'}`,
    style: {
      fontSize: 9.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), st))))))), /*#__PURE__*/React.createElement(ProofSection, {
    title: "Pearl leg facts",
    num: "03"
  }, /*#__PURE__*/React.createElement(FactTable, {
    rows: [['network', 'pearl · testnet2 · chain id  pearl_testnet2'], ['escrow address', SAMPLE.pearlAddr], ['expected amount', '12,500.00000000 PRL'], ['confirmations req', '6'], ['funding outpoint', pearlFundedAt ? `${SAMPLE.fundTxid}:0` : '—', !!pearlFundedAt], ['funded at', pearlFundedAt || '—'], ['confirmed at', pearlConfirmedAt || '—'], pearlReleaseAt ? ['release tx', SAMPLE.releaseTxid, true] : ['release tx', '—'], pearlRefundAt ? ['refund tx', SAMPLE.refundTxid, true] : ['refund tx', '—']]
  })), /*#__PURE__*/React.createElement(ProofSection, {
    title: "Base leg facts",
    num: "04"
  }, /*#__PURE__*/React.createElement(FactTable, {
    rows: [['network', 'base · sepolia · chain id 84532'], ['escrow contract', SAMPLE.baseEscrow, true], ['trade key', SAMPLE.tradeKeyFull], ['expected amount', '8,237.500000 USDC'], ['confirmations req', '12'], baseDepositAt ? ['deposit tx', SAMPLE.depositHash, true] : ['deposit tx', '—'], ['deposit confirmed at', baseDepositAt || '—'], baseReleaseAt ? ['release tx', SAMPLE.releaseHash, true] : ['release tx', '—'], baseRefundAt ? ['refund tx', SAMPLE.refundHash, true] : ['refund tx', '—']]
  })), /*#__PURE__*/React.createElement(ProofSection, {
    title: "State transition timeline",
    num: "05"
  }, /*#__PURE__*/React.createElement(Timeline, {
    events: events || TL_EVENTS.released
  })), /*#__PURE__*/React.createElement(ProofSection, {
    title: "Side-effect ledger",
    num: "06",
    style: {
      marginBottom: 36
    }
  }, /*#__PURE__*/React.createElement(SideEffectsTable, {
    rows: sideEffects
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 18,
      borderTop: '1px solid var(--hairline)',
      fontSize: 11,
      color: 'var(--muted)',
      lineHeight: 1.6,
      display: 'flex',
      alignItems: 'center',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "otc.pearl.dev/trades/", SAMPLE.tradeId, "/proof"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "This receipt is reproduced from the desk's append-only event log. Every txid links to a public chain explorer for independent verification."))));
}

// ── Variants ────────────────────────────────────────────────────────────────

const ProofHappy = () => /*#__PURE__*/React.createElement(ProofLayout, {
  state: "released",
  events: TL_EVENTS.released,
  sideEffects: SIDE_EFFECTS_FULL
});
const ProofInProgress = () => /*#__PURE__*/React.createElement(ProofLayout, {
  state: "pearl_escrow_confirmed",
  pearlReleaseAt: null,
  pearlConfirmedAt: "2026-05-17T14:29:33Z",
  baseDepositAt: null,
  baseReleaseAt: null,
  events: TL_EVENTS.pearl_seen,
  sideEffects: SIDE_EFFECTS_INPROG
});
const ProofRefunded = () => /*#__PURE__*/React.createElement(ProofLayout, {
  state: "refunded",
  pearlFundedAt: null,
  pearlConfirmedAt: null,
  pearlReleaseAt: null,
  baseRefundAt: "2026-05-17T15:38:44Z",
  baseReleaseAt: null,
  sideEffects: SIDE_EFFECTS_REFUNDED,
  events: [{
    chain: 'sys',
    ev: 'Quote accepted; escrows allocated',
    meta: '14:22:08 UTC',
    time: ''
  }, {
    chain: 'base',
    ev: 'USDC deposit confirmed',
    meta: '12/12 confirmations',
    time: ''
  }, {
    chain: 'err',
    ev: 'pearl_funding deadline crossed',
    meta: 'no Pearl deposit observed',
    time: ''
  }, {
    chain: 'sys',
    ev: 'Refund requested by buyer',
    meta: '15:34:08 UTC',
    time: ''
  }, {
    chain: 'base',
    ev: 'USDC refund confirmed',
    meta: '0xe5f6…e5f6 · 12/12 confirmations',
    time: ''
  }, {
    chain: 'ok',
    ev: 'Trade refunded · terminal',
    meta: 'ledger closed at 15:38:44 UTC',
    time: ''
  }]
});
const ProofFailure = () => /*#__PURE__*/React.createElement(ProofLayout, {
  state: "prl_release_failed",
  banner: /*#__PURE__*/React.createElement(FailureBanner, {
    state: "prl_release_failed"
  }),
  pearlReleaseAt: null,
  sideEffects: SIDE_EFFECTS_FAIL,
  events: [{
    chain: 'sys',
    ev: 'Quote accepted; escrows allocated',
    meta: '14:22:08 UTC',
    time: ''
  }, {
    chain: 'pearl',
    ev: 'Pearl deposit confirmed',
    meta: '6/6 confirmations',
    time: ''
  }, {
    chain: 'base',
    ev: 'USDC deposit confirmed',
    meta: '12/12 confirmations',
    time: ''
  }, {
    chain: 'sys',
    ev: 'Release authorized',
    meta: 'idempotency 0x7e…2a',
    time: ''
  }, {
    chain: 'err',
    ev: 'PRL release broadcast failed (3 retries)',
    meta: 'utxo_already_spent',
    time: ''
  }, {
    chain: 'err',
    ev: 'State entered: prl_release_failed',
    meta: 'manual review queued',
    time: ''
  }]
});
window.PageProof = {
  variants: [{
    id: 'happy',
    label: 'happy · completed trade',
    Page: ProofHappy,
    height: 1820
  }, {
    id: 'in-progress',
    label: 'in progress · partial facts',
    Page: ProofInProgress,
    height: 1500
  }, {
    id: 'refunded',
    label: 'refunded · terminal',
    Page: ProofRefunded,
    height: 1700
  }, {
    id: 'failure',
    label: 'failure · prl_release_failed',
    Page: ProofFailure,
    height: 1820
  }]
};

// ═══ src/page-admin.jsx ═══

// /admin/trades — operator shell · list + detail
// Darker chrome; pgAdmin/Linear-board feel; operators annotate, never release.

// (destructure stripped)
// ── List page ───────────────────────────────────────────────────────────────

function AdminFilters({
  manualOnly = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'center',
      padding: '14px 28px',
      background: 'var(--surface)',
      borderBottom: '1px solid var(--hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flex: '0 0 280px'
    }
  }, /*#__PURE__*/React.createElement("input", {
    className: "input mono",
    placeholder: "search by trade id\u2026",
    readOnly: true,
    style: {
      paddingLeft: 30,
      fontSize: 11.5
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 10,
      top: 8,
      color: 'var(--muted-2)',
      fontFamily: 'var(--font-mono)',
      fontSize: 13
    }
  }, "\u2315")), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 1,
      height: 22,
      background: 'var(--hairline)'
    }
  }), /*#__PURE__*/React.createElement("button", {
    className: "btn sm"
  }, "state ", /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 4
    },
    className: "muted"
  }, "\u25BE")), /*#__PURE__*/React.createElement("button", {
    className: "btn sm"
  }, "side ", /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 4
    },
    className: "muted"
  }, "\u25BE")), /*#__PURE__*/React.createElement("button", {
    className: "btn sm"
  }, "last 24h ", /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 4
    },
    className: "muted"
  }, "\u25BE")), /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      fontSize: 12,
      color: manualOnly ? 'var(--err)' : 'var(--muted)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 28,
      height: 16,
      borderRadius: 8,
      background: manualOnly ? 'var(--err)' : 'var(--neutral-soft)',
      border: '1px solid ' + (manualOnly ? 'var(--err)' : 'var(--hairline)'),
      position: 'relative',
      transition: 'background .15s'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 1,
      left: manualOnly ? 13 : 1,
      width: 12,
      height: 12,
      background: '#fff',
      borderRadius: '50%',
      transition: 'left .15s'
    }
  })), "manual review only"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontSize: 11,
      fontFamily: 'var(--font-mono)'
    }
  }, "showing ", manualOnly ? '4' : '12', " of 247"), /*#__PURE__*/React.createElement("button", {
    className: "btn sm"
  }, "\u2193 export"));
}
function AdminListTable({
  rows
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 28px'
    }
  }, /*#__PURE__*/React.createElement("table", {
    className: "tbl",
    style: {
      background: 'var(--surface)',
      border: '1px solid var(--hairline)',
      borderRadius: 'var(--r-3)',
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      width: 220
    }
  }, "trade id"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 200
    }
  }, "state"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 50
    }
  }, "side"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 60
    }
  }, "age"), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "amount PRL"), /*#__PURE__*/React.createElement("th", {
    className: "num"
  }, "amount USDC"), /*#__PURE__*/React.createElement("th", null, "manual review reason"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 40
    }
  }))), /*#__PURE__*/React.createElement("tbody", null, rows.map(r => /*#__PURE__*/React.createElement("tr", {
    key: r.id
  }, /*#__PURE__*/React.createElement("td", {
    className: "mono",
    style: {
      fontSize: 11.5
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'var(--accent)',
      textDecoration: 'none'
    }
  }, r.id)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(StateBadge, {
    state: r.state
  })), /*#__PURE__*/React.createElement("td", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--muted)'
    }
  }, r.side), /*#__PURE__*/React.createElement("td", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--muted)'
    }
  }, r.age), /*#__PURE__*/React.createElement("td", {
    className: "num",
    style: {
      fontSize: 11.5
    }
  }, r.prl), /*#__PURE__*/React.createElement("td", {
    className: "num",
    style: {
      fontSize: 11.5
    }
  }, r.usdc), /*#__PURE__*/React.createElement("td", {
    style: {
      fontSize: 11.5,
      color: r.flag ? 'var(--err)' : 'var(--muted-2)'
    }
  }, r.flag || '—'), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("button", {
    className: "btn ghost sm",
    style: {
      padding: '0 6px',
      height: 22
    }
  }, "\xB7\xB7\xB7")))))));
}
function AdminListShell({
  rows,
  manualOnly = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "pearl",
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(Chrome, {
    path: "/admin/trades"
  }), /*#__PURE__*/React.createElement(AdminTopNav, {
    active: "trades"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '22px 28px 4px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 6
    }
  }, "admin \xB7 operator shell"), /*#__PURE__*/React.createElement("h1", {
    className: "h1"
  }, "All trades")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 22,
      fontSize: 11
    }
  }, [['active', '47', 'var(--accent)'], ['manual_rev', '4', 'var(--err)'], ['released 24h', '193', 'var(--ok)'], ['refunded 24h', '6', 'var(--warn)']].map(([l, n, c]) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 2
    }
  }, l), /*#__PURE__*/React.createElement("div", {
    className: "mono",
    style: {
      fontSize: 17,
      fontWeight: 500,
      color: c,
      fontVariantNumeric: 'tabular-nums'
    }
  }, n)))))), /*#__PURE__*/React.createElement(AdminFilters, {
    manualOnly: manualOnly
  }), /*#__PURE__*/React.createElement(AdminListTable, {
    rows: rows
  })));
}
const AdminListEmpty = () => /*#__PURE__*/React.createElement("div", {
  className: "pearl",
  style: {
    display: 'flex',
    flexDirection: 'column'
  }
}, /*#__PURE__*/React.createElement(Chrome, {
  path: "/admin/trades"
}), /*#__PURE__*/React.createElement(AdminTopNav, {
  active: "trades"
}), /*#__PURE__*/React.createElement("div", {
  style: {
    flex: 1,
    overflow: 'auto'
  }
}, /*#__PURE__*/React.createElement("div", {
  style: {
    padding: '22px 28px 4px'
  }
}, /*#__PURE__*/React.createElement("div", {
  className: "eyebrow",
  style: {
    marginBottom: 6
  }
}, "admin \xB7 operator shell"), /*#__PURE__*/React.createElement("h1", {
  className: "h1"
}, "All trades")), /*#__PURE__*/React.createElement(AdminFilters, null), /*#__PURE__*/React.createElement("div", {
  style: {
    padding: '0 28px'
  }
}, /*#__PURE__*/React.createElement("div", {
  style: {
    background: 'var(--surface)',
    border: '1px dashed var(--hairline)',
    borderRadius: 'var(--r-3)',
    marginTop: 18,
    padding: '64px 28px',
    textAlign: 'center'
  }
}, /*#__PURE__*/React.createElement("div", {
  style: {
    width: 36,
    height: 36,
    margin: '0 auto 14px',
    borderRadius: '50%',
    background: 'var(--paper-2)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontFamily: 'var(--font-mono)',
    fontSize: 16,
    color: 'var(--muted-2)'
  }
}, "\u2014"), /*#__PURE__*/React.createElement("div", {
  className: "h2",
  style: {
    marginBottom: 6
  }
}, "No trades yet"), /*#__PURE__*/React.createElement("div", {
  className: "muted",
  style: {
    fontSize: 12,
    maxWidth: 380,
    margin: '0 auto',
    lineHeight: 1.5
  }
}, "No quotes have been accepted in this environment. Trades will appear here within seconds of acceptance.")))));
const AdminListPopulated = () => /*#__PURE__*/React.createElement(AdminListShell, {
  rows: ADMIN_ROWS
});
const AdminListFiltered = () => /*#__PURE__*/React.createElement(AdminListShell, {
  rows: ADMIN_ROWS.filter(r => r.flag !== null),
  manualOnly: true
});

// ── Detail page ─────────────────────────────────────────────────────────────

function OpPanel({
  expanded = false,
  failure
}) {
  return /*#__PURE__*/React.createElement("aside", {
    className: "opbar",
    style: {
      width: 360,
      overflow: 'auto',
      padding: '20px 22px',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 4
    }
  }, "operator"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 24,
      height: 24,
      borderRadius: '50%',
      background: '#c4a87a',
      color: '#1a1a17',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 10,
      fontWeight: 600
    }
  }, "MQ"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 500
    }
  }, "marcus.q ", /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontWeight: 400
    }
  }, "\xB7 op_07")), /*#__PURE__*/React.createElement("div", {
    className: "muted",
    style: {
      fontSize: 10.5,
      fontFamily: 'var(--font-mono)'
    }
  }, "can: read, annotate")))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 22,
      paddingBottom: 22,
      borderBottom: '1px solid var(--hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 8
    }
  }, "actions"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn",
    style: {
      justifyContent: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 14,
      color: 'var(--warn)'
    }
  }, "\u2691"), " Flag for manual review"), /*#__PURE__*/React.createElement("button", {
    className: "btn",
    style: {
      justifyContent: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 14
    }
  }, "\uD83D\uDCCE"), " Attach note"), /*#__PURE__*/React.createElement("button", {
    className: "btn",
    style: {
      justifyContent: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 14
    }
  }, "\u2197"), " Open on basescan")), /*#__PURE__*/React.createElement("div", {
    className: "help",
    style: {
      marginTop: 10,
      fontSize: 10.5
    }
  }, "No release / refund buttons. Operators annotate; state transitions are server-side.")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow"
  }, "record manual side-effect"), expanded ? /*#__PURE__*/React.createElement("span", {
    className: "badge accent",
    style: {
      fontSize: 9.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "open") : null), expanded ? /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-2)',
      border: '1px solid var(--hairline)',
      borderRadius: 'var(--r-2)',
      padding: '14px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "label"
  }, "effect type"), /*#__PURE__*/React.createElement("div", {
    className: "input",
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      fontFamily: 'var(--font-mono)',
      fontSize: 11
    }
  }, /*#__PURE__*/React.createElement("span", null, "manual_pearl_release"), /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, "\u25BE"))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "label"
  }, "tx hash / outpoint"), /*#__PURE__*/React.createElement("input", {
    className: "input mono",
    placeholder: "0x\u2026 or txid:vout",
    readOnly: true,
    style: {
      fontSize: 11
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "label"
  }, "status"), /*#__PURE__*/React.createElement("div", {
    className: "input",
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      fontFamily: 'var(--font-mono)',
      fontSize: 11
    }
  }, /*#__PURE__*/React.createElement("span", null, "broadcast_succeeded"), /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, "\u25BE"))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("label", {
    className: "label"
  }, "metadata (JSON)"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      background: '#0f0f0c',
      color: '#d6cfa3',
      padding: '8px 10px',
      borderRadius: 'var(--r-2)',
      lineHeight: 1.5,
      whiteSpace: 'pre'
    }
  }, `{
  "reason": "manual broadcast after rpc",
  "actor_note": "verified utxo with node 3",
  "approval": "op_07 + op_03"
}`)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn primary sm",
    style: {
      flex: 1,
      justifyContent: 'center'
    }
  }, "Submit side-effect"), /*#__PURE__*/React.createElement("button", {
    className: "btn ghost sm"
  }, "Cancel")), /*#__PURE__*/React.createElement("div", {
    className: "help",
    style: {
      marginTop: 10,
      fontSize: 10.5
    }
  }, "Idempotency key auto-generated. Does not transition state; the indexer picks up the broadcast and re-derives state from on-chain truth.")) : /*#__PURE__*/React.createElement("button", {
    className: "btn",
    style: {
      width: '100%',
      justifyContent: 'center',
      borderStyle: 'dashed'
    }
  }, "+ record side-effect")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 8
    }
  }, "audit log \xB7 last 5"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--muted)',
      lineHeight: 1.7
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--err)'
    }
  }, "ERR"), " \xB7 14:45:14 \xB7 pearl_release_retry_3 \u2192 failed"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--err)'
    }
  }, "ERR"), " \xB7 14:44:14 \xB7 pearl_release_retry_2 \u2192 failed"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--err)'
    }
  }, "ERR"), " \xB7 14:43:11 \xB7 pearl_release_retry_1 \u2192 failed"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--err)'
    }
  }, "ERR"), " \xB7 14:42:14 \xB7 pearl_release_submitted \u2192 failed"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ok)'
    }
  }, " OK"), " \xB7 14:42:01 \xB7 release_authorized"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      display: 'inline-block',
      marginTop: 8,
      color: 'var(--accent)',
      fontFamily: 'var(--font-sans)'
    }
  }, "see full audit log \u2192"))));
}
function AdminDetailShell({
  failure,
  panelExpanded
}) {
  const state = failure || 'pearl_escrow_pending';
  return /*#__PURE__*/React.createElement("div", {
    className: "pearl",
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(Chrome, {
    path: `/admin/trades/${SAMPLE.tradeId}`
  }), /*#__PURE__*/React.createElement(AdminTopNav, {
    active: "trades"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto',
      borderRight: '1px solid var(--hairline)'
    }
  }, /*#__PURE__*/React.createElement(TradeHeader, {
    state: state
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 24px 40px'
    }
  }, failure && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(FailureBanner, {
    state: failure
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginBottom: 14,
      padding: '8px 12px',
      background: 'var(--paper-2)',
      border: '1px solid var(--hairline)',
      borderRadius: 'var(--r-2)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "badge neutral",
    style: {
      fontSize: 9.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), "read-only"), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontSize: 11.5
    }
  }, "Customer view of /trades/", SAMPLE.tradeId, " as seen by the buyer. Mirrors the checkout screen exactly \u2014 no interaction.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(PearlCard, {
    status: failure === 'prl_release_failed' ? 'confirmed' : failure === 'amount_mismatch' ? 'mismatch' : 'pending'
  }), /*#__PURE__*/React.createElement(BaseCard, {
    status: failure ? 'confirmed' : 'awaiting'
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "card-header"
  }, /*#__PURE__*/React.createElement("span", {
    className: "h2"
  }, "Activity"), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontSize: 11
    }
  }, "9 events \xB7 expanded view")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '6px 18px 12px'
    }
  }, /*#__PURE__*/React.createElement(Timeline, {
    events: failure ? TL_EVENTS.failure_generic : TL_EVENTS.pearl_escrow_pending
  })))))), /*#__PURE__*/React.createElement(OpPanel, {
    expanded: panelExpanded,
    failure: failure
  })));
}
const AdminDetailHappy = () => /*#__PURE__*/React.createElement(AdminDetailShell, null);
const AdminDetailFailure = () => /*#__PURE__*/React.createElement(AdminDetailShell, {
  failure: "prl_release_failed",
  panelExpanded: true
});
window.PageAdmin = {
  variants: [{
    id: 'list-empty',
    label: 'list · empty environment',
    Page: AdminListEmpty,
    height: 880
  }, {
    id: 'list-populated',
    label: 'list · populated · mixed states',
    Page: AdminListPopulated,
    height: 880
  }, {
    id: 'list-filtered',
    label: 'list · manual review only',
    Page: AdminListFiltered,
    height: 880
  }, {
    id: 'detail-happy',
    label: 'detail · pearl_escrow_pending',
    Page: AdminDetailHappy,
    height: 1120
  }, {
    id: 'detail-failure',
    label: 'detail · prl_release_failed · panel open',
    Page: AdminDetailFailure,
    height: 1120
  }]
};

// ═══ src/page-offers.jsx ═══

// /offers — Live offer board (NEW)
// Stripe Payments list aesthetic. Single dense table.
// Variants: empty · populated mixed · filtered pearl-funded · one being taken.

const OFFERS_DATA = [
// pearl-funded → green dot (the differentiator)
{
  id: "qte_01J5K9XBHK2NRGV0",
  side: "sell",
  size: "12,500.00000000",
  price: "0.659000",
  total: "8,237.500000",
  funded: true,
  expires: "12m 30s",
  maker: "mkr_4f8a…b21c",
  views: 47,
  takes: 0
}, {
  id: "qte_01J5K9V2D7M3PKAE",
  side: "sell",
  size: "5,000.00000000",
  price: "0.658500",
  total: "3,292.500000",
  funded: true,
  expires: "08m 14s",
  maker: "mkr_d1c9…7a04",
  views: 23,
  takes: 0
}, {
  id: "qte_01J5K9T8B6F0QHCY",
  side: "sell",
  size: "20,000.00000000",
  price: "0.660000",
  total: "13,200.000000",
  funded: false,
  expires: "23m 02s",
  maker: "mkr_92e4…f17b",
  views: 11,
  takes: 0
}, {
  id: "qte_01J5K9SDC4XL8PMR",
  side: "sell",
  size: "1,000.00000000",
  price: "0.659500",
  total: "659.500000",
  funded: true,
  expires: "01m 47s",
  maker: "mkr_a0bb…3c91",
  views: 84,
  takes: 0,
  nearExpiry: true
}, {
  id: "qte_01J5K9R7N9JK1WCP",
  side: "sell",
  size: "45,000.00000000",
  price: "0.661000",
  total: "29,745.000000",
  funded: false,
  expires: "18m 55s",
  maker: "mkr_67d2…e8a3",
  views: 5,
  takes: 0
}, {
  id: "qte_01J5K9PE5G3MTYDB",
  side: "sell",
  size: "3,750.00000000",
  price: "0.659200",
  total: "2,472.000000",
  funded: true,
  expires: "14m 09s",
  maker: "mkr_3f12…b9e7",
  views: 19,
  takes: 0
}, {
  id: "qte_01J5K9NA1B8VFXKQ",
  side: "sell",
  size: "8,000.00000000",
  price: "0.660500",
  total: "5,284.000000",
  funded: false,
  expires: "26m 41s",
  maker: "mkr_c8a4…1e0d",
  views: 7,
  takes: 0
}, {
  id: "qte_01J5K9KFT6C2DPNY",
  side: "sell",
  size: "2,500.00000000",
  price: "0.658800",
  total: "1,647.000000",
  funded: true,
  expires: "06m 12s",
  maker: "mkr_5b97…d4e2",
  views: 31,
  takes: 0
}];
const TAKEN_OFFER = {
  id: "qte_01J5K9XBHK2NRGV0",
  side: "sell",
  size: "12,500.00000000",
  price: "0.659000",
  total: "8,237.500000",
  funded: true,
  expires: "12m 30s",
  maker: "mkr_4f8a…b21c",
  views: 48,
  takes: 1,
  taking: true
};

// ── Offers table row ─────────────────────────────────────────────────────────
function OfferRow({
  o,
  expanded,
  onToggle,
  taking
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("tr", {
    onClick: onToggle,
    style: {
      cursor: 'pointer',
      background: expanded ? 'var(--surface-2)' : taking ? 'var(--accent-soft)' : undefined
    }
  }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: `badge ${o.side === 'buy' ? 'ok' : 'err'}`,
    style: {
      fontSize: 9.5,
      padding: '2px 7px',
      background: o.side === 'buy' ? 'var(--ok-soft)' : '#f6e4e0',
      color: o.side === 'buy' ? 'var(--ok)' : '#a43a2c',
      borderColor: o.side === 'buy' ? 'var(--ok-line)' : '#e6c4b8'
    }
  }, o.side.toUpperCase())), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, o.size.split('.')[0], /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted)'
    }
  }, ".", o.size.split('.')[1]))), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, o.price)), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, o.total.split('.')[0], /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted)'
    }
  }, ".", o.total.split('.')[1]))), /*#__PURE__*/React.createElement("td", null, o.funded ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 50,
      background: 'var(--ok)',
      boxShadow: '0 0 0 3px var(--ok-soft)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ok)',
      fontWeight: 500,
      fontSize: 11.5
    }
  }, "Pearl funded")) : /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 50,
      background: 'var(--muted-2)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted)',
      fontSize: 11.5
    }
  }, "Unfunded"))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      fontSize: 11.5,
      color: o.nearExpiry ? 'var(--warn)' : 'var(--ink)'
    }
  }, o.expires)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--muted)',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5
    }
  }, o.maker, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted-2)'
    }
  }, /*#__PURE__*/React.createElement(CopyIcon, null)))), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right'
    }
  }, taking ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      fontSize: 11.5,
      color: 'var(--accent)',
      fontWeight: 500
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "spin"
  }), " Taking\u2026") : /*#__PURE__*/React.createElement("button", {
    className: "btn sm",
    onClick: e => e.stopPropagation()
  }, "Take \u2192"))), expanded && /*#__PURE__*/React.createElement("tr", {
    style: {
      background: 'var(--surface-2)'
    }
  }, /*#__PURE__*/React.createElement("td", {
    colSpan: 8,
    style: {
      padding: '14px 18px 18px',
      borderBottom: '1px solid var(--hairline-2)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 28
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 6
    }
  }, "quote id"), /*#__PURE__*/React.createElement("div", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--ink)'
    }
  }, o.id)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 6
    }
  }, "maker pubkey"), /*#__PURE__*/React.createElement("div", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--ink)',
      wordBreak: 'break-all'
    }
  }, "03a4f8b21c9e0d5f7a3b2c1e8d4f6a9b0c2d3e4f5a6b7c8d9e")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 6
    }
  }, "fee breakdown"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "12.5 PRL"), " ", /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, "\xB7"), " ", /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "8.24 USDC")), /*#__PURE__*/React.createElement("div", {
    className: "muted",
    style: {
      fontSize: 11,
      marginTop: 2
    }
  }, "maker rebate \u22120.025% \xB7 taker 0.15%")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 6
    }
  }, "deadlines"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      lineHeight: 1.7
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, "pearl_funding"), " ", /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "12m 30s")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, "usdc_deposit"), "  ", /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "10m 12s")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, "settlement"), "    ", /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "42m 04s"))))), o.funded && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14,
      padding: '10px 12px',
      background: 'var(--ok-soft)',
      border: '1px solid var(--ok-line)',
      borderRadius: 'var(--r-2)',
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      fontSize: 11.5,
      color: 'var(--ok)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 50,
      background: 'var(--ok)'
    }
  }), "Maker's PRL is already escrowed at ", /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--ink)'
    }
  }, "prl1pn4g\u2026lyq8m"), " \u2014 settlement starts the moment you deposit USDC."))));
}

// ── Filters bar ──────────────────────────────────────────────────────────────
function FiltersBar({
  pearlFundedOnly = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(FilterChip, {
    label: "Size",
    value: "any"
  }), /*#__PURE__*/React.createElement(FilterChip, {
    label: "Max spread",
    value: "0.5%"
  }), /*#__PURE__*/React.createElement(FilterChip, {
    label: "Network",
    value: "testnet2"
  }), /*#__PURE__*/React.createElement(FilterChip, {
    label: "Escrow",
    value: pearlFundedOnly ? "pearl funded only" : "all",
    active: pearlFundedOnly
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontSize: 11.5
    }
  }, "sorted by ", /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--ink)'
    }
  }, "price \u2191")));
}
function FilterChip({
  label,
  value,
  active
}) {
  return /*#__PURE__*/React.createElement("button", {
    className: "btn sm",
    style: {
      borderColor: active ? 'var(--accent-line)' : 'var(--hairline)',
      background: active ? 'var(--accent-soft)' : 'var(--surface)',
      color: active ? 'var(--accent-ink)' : 'var(--ink)',
      fontSize: 11.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontWeight: 400
    }
  }, label, ":"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      marginLeft: 2
    }
  }, value), /*#__PURE__*/React.createElement("svg", {
    width: "9",
    height: "9",
    viewBox: "0 0 9 9",
    style: {
      marginLeft: 2
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M1.5 3 L4.5 6 L7.5 3",
    stroke: "currentColor",
    fill: "none",
    strokeWidth: "1.2"
  })));
}

// ── Page shell + header ──────────────────────────────────────────────────────
function OffersHeader({
  side = 'buy',
  onSide,
  pearlFundedOnly = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 28px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 4
    }
  }, "liquidity"), /*#__PURE__*/React.createElement("div", {
    className: "h1"
  }, "Open offers"), /*#__PURE__*/React.createElement("div", {
    className: "muted",
    style: {
      fontSize: 12,
      marginTop: 4
    }
  }, "Take liquidity directly from other users without waiting for a desk quote.")), /*#__PURE__*/React.createElement("button", {
    className: "btn accent"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "10",
    height: "10",
    viewBox: "0 0 10 10"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M5 1V9 M1 5H9",
    stroke: "currentColor",
    strokeWidth: "1.3"
  })), "Post my own quote")), /*#__PURE__*/React.createElement("div", {
    className: "tabs",
    style: {
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: `tab ${side === 'buy' ? 'active' : ''}`,
    onClick: () => onSide && onSide('buy')
  }, "Buy PRL", /*#__PURE__*/React.createElement("span", {
    className: "muted mono",
    style: {
      fontSize: 10.5,
      marginLeft: 8
    }
  }, 8)), /*#__PURE__*/React.createElement("div", {
    className: `tab ${side === 'sell' ? 'active' : ''}`,
    onClick: () => onSide && onSide('sell')
  }, "Sell PRL", /*#__PURE__*/React.createElement("span", {
    className: "muted mono",
    style: {
      fontSize: 10.5,
      marginLeft: 8
    }
  }, "3")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      borderBottom: '1px solid var(--hairline)',
      alignSelf: 'flex-end'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(FiltersBar, {
    pearlFundedOnly: pearlFundedOnly
  })));
}
function OffersTable({
  rows,
  takingId
}) {
  const [expanded, setExpanded] = React.useState(null);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 28px 28px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      width: 60
    }
  }, "Side"), /*#__PURE__*/React.createElement("th", {
    className: "num",
    style: {
      width: 160
    }
  }, "Size \xB7 PRL"), /*#__PURE__*/React.createElement("th", {
    className: "num",
    style: {
      width: 90
    }
  }, "Price"), /*#__PURE__*/React.createElement("th", {
    className: "num",
    style: {
      width: 140
    }
  }, "Total \xB7 USDC"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 130
    }
  }, "Escrow status"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 90
    }
  }, "Expires in"), /*#__PURE__*/React.createElement("th", null, "Maker"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 110,
      textAlign: 'right'
    }
  }, "Action"))), /*#__PURE__*/React.createElement("tbody", null, rows.map((o, i) => /*#__PURE__*/React.createElement(OfferRow, {
    key: o.id,
    o: o,
    expanded: expanded === o.id,
    onToggle: () => setExpanded(expanded === o.id ? null : o.id),
    taking: takingId === o.id
  }))))), rows.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "muted",
    style: {
      fontSize: 11.5,
      marginTop: 10,
      display: 'flex',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", null, rows.length, " offers \xB7 click a row to expand \xB7 click ", /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--ink)'
    }
  }, "Take"), " to route to ", /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--ink)'
    }
  }, "/quote/:id/accept")), /*#__PURE__*/React.createElement("span", null, "updated ", /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--ink)'
    }
  }, "1s"), " ago")));
}

// ── Empty state ──────────────────────────────────────────────────────────────
function OffersEmpty() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '60px 28px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      padding: '64px 32px',
      maxWidth: 540,
      margin: '0 auto',
      background: 'var(--surface-2)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: '50%',
      background: 'radial-gradient(circle at 35% 35%, #fff 0%, #ecebe1 35%, #cfcdb8 70%, #8b8973 100%)',
      margin: '0 auto 18px',
      boxShadow: 'inset 0 0 0 0.5px rgba(0,0,0,.12)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "h2",
    style: {
      marginBottom: 6
    }
  }, "The board is empty."), /*#__PURE__*/React.createElement("div", {
    className: "muted",
    style: {
      fontSize: 12.5,
      marginBottom: 22,
      lineHeight: 1.55,
      maxWidth: 380,
      margin: '0 auto 22px'
    }
  }, "No one's posted a quote yet. Post yours and the first taker hits it within a 12-minute window."), /*#__PURE__*/React.createElement("button", {
    className: "btn accent"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "10",
    height: "10",
    viewBox: "0 0 10 10"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M5 1V9 M1 5H9",
    stroke: "currentColor",
    strokeWidth: "1.3"
  })), "Post the first quote"), /*#__PURE__*/React.createElement("div", {
    className: "muted",
    style: {
      fontSize: 11,
      marginTop: 16,
      fontFamily: 'var(--font-mono)'
    }
  }, "or RFQ the desk at ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'var(--accent)'
    }
  }, "/quote"))));
}

// ── Variants ─────────────────────────────────────────────────────────────────

const OffersEmptyV = () => /*#__PURE__*/React.createElement(PageShell, {
  path: "/offers"
}, /*#__PURE__*/React.createElement(OffersHeader, {
  side: "buy"
}), /*#__PURE__*/React.createElement(OffersEmpty, null));
const OffersMixedV = () => /*#__PURE__*/React.createElement(PageShell, {
  path: "/offers"
}, /*#__PURE__*/React.createElement(OffersHeader, {
  side: "buy"
}), /*#__PURE__*/React.createElement(OffersTable, {
  rows: OFFERS_DATA
}));
const OffersFundedOnlyV = () => /*#__PURE__*/React.createElement(PageShell, {
  path: "/offers?escrow=funded"
}, /*#__PURE__*/React.createElement(OffersHeader, {
  side: "buy",
  pearlFundedOnly: true
}), /*#__PURE__*/React.createElement(OffersTable, {
  rows: OFFERS_DATA.filter(o => o.funded)
}));
const OffersTakingV = () => /*#__PURE__*/React.createElement(PageShell, {
  path: "/offers"
}, /*#__PURE__*/React.createElement(OffersHeader, {
  side: "buy"
}), /*#__PURE__*/React.createElement("div", {
  style: {
    padding: '0 28px 8px'
  }
}, /*#__PURE__*/React.createElement("div", {
  className: "banner info",
  style: {
    padding: '9px 14px',
    fontSize: 12
  }
}, /*#__PURE__*/React.createElement("span", {
  className: "ic"
}, /*#__PURE__*/React.createElement("span", {
  className: "spin"
})), /*#__PURE__*/React.createElement("div", {
  className: "body"
}, /*#__PURE__*/React.createElement("strong", null, "Taking offer ", /*#__PURE__*/React.createElement("span", {
  className: "mono"
}, "qte_01J5K9XBHK2NRGV0")), /*#__PURE__*/React.createElement("div", {
  className: "lede"
}, "Locking quote terms \xB7 routing to ", /*#__PURE__*/React.createElement("span", {
  className: "mono"
}, "/quote/:id/accept"), "\u2026")))), /*#__PURE__*/React.createElement(OffersTable, {
  rows: [TAKEN_OFFER, ...OFFERS_DATA.slice(1)],
  takingId: TAKEN_OFFER.id
}));
window.PageOffers = {
  variants: [{
    id: 'empty',
    label: 'empty',
    Page: OffersEmptyV,
    height: 880
  }, {
    id: 'mixed',
    label: 'populated · mixed (funded + unfunded)',
    Page: OffersMixedV,
    height: 1080
  }, {
    id: 'funded-only',
    label: 'filtered: pearl-funded only',
    Page: OffersFundedOnlyV,
    height: 880
  }, {
    id: 'taking',
    label: 'one offer being taken',
    Page: OffersTakingV,
    height: 1080
  }]
};

// ═══ src/page-my-quotes.jsx ═══

// /my-quotes — personal dashboard for makers + RFQ posters.
// Sections: stat tiles · Waiting for counterparty · In flight.
// Variants: empty · all waiting · mixed · one just taken.

const WAITING_ROWS = [{
  id: "qte_01J5K9XBHK2NRGV0",
  side: "sell",
  size: "12,500.00000000",
  price: "0.659000",
  total: "8,237.500000",
  funded: true,
  expires: "12m 30s",
  views: 47,
  takes: 0
}, {
  id: "qte_01J5K9V2D7M3PKAE",
  side: "sell",
  size: "5,000.00000000",
  price: "0.658500",
  total: "3,292.500000",
  funded: false,
  expires: "08m 14s",
  views: 23,
  takes: 0
}, {
  id: "qte_01J5K9SDC4XL8PMR",
  side: "buy",
  size: "1,000.00000000",
  price: "0.660200",
  total: "660.200000",
  funded: true,
  expires: "01m 47s",
  views: 84,
  takes: 0,
  near: true
}, {
  id: "qte_01J5K9P3M7TFXKAB",
  side: "sell",
  size: "3,750.00000000",
  price: "0.659200",
  total: "2,472.000000",
  funded: true,
  expires: "14m 09s",
  views: 19,
  takes: 0
}];
const INFLIGHT_ROWS = [{
  id: "trd_01J5K8B2QHXV9P3Y",
  state: "pearl_escrow_pending",
  counterparty: "tkr_8d72…f04a",
  size: "12,500.00000000 PRL",
  inState: "3m 12s",
  why: "Awaiting USDC deposit"
}, {
  id: "trd_01J5K7Z1M4NTBHGX",
  state: "release_pending",
  counterparty: "tkr_a04b…1e9d",
  size: "3,000.00000000 PRL",
  inState: "0m 47s",
  why: "Releases broadcasting"
}, {
  id: "trd_01J5K7XKE3RMS4DA",
  state: "pearl_escrow_seen",
  counterparty: "tkr_c91e…b73f",
  size: "45,200.00000000 PRL",
  inState: "1m 04s",
  why: "3 / 6 confirmations"
}];

// ── Stat tiles ───────────────────────────────────────────────────────────────
function StatTile({
  label,
  value,
  delta,
  mono = true
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "card card-pad",
    style: {
      padding: '14px 16px',
      flex: 1,
      minWidth: 180
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 8
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
      fontSize: 26,
      fontWeight: 500,
      letterSpacing: '-0.5px',
      fontVariantNumeric: 'tabular-nums'
    }
  }, value), delta && /*#__PURE__*/React.createElement("span", {
    className: `mono`,
    style: {
      fontSize: 11,
      color: delta.startsWith('+') ? 'var(--ok)' : 'var(--muted)'
    }
  }, delta)));
}

// ── Waiting table row ────────────────────────────────────────────────────────
function WaitingRow({
  q,
  highlighted,
  justTaken
}) {
  return /*#__PURE__*/React.createElement("tr", {
    style: {
      background: highlighted ? 'var(--ok-soft)' : justTaken ? 'var(--accent-soft)' : undefined
    }
  }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: `badge ${q.side === 'buy' ? 'ok' : 'err'}`,
    style: {
      fontSize: 9.5,
      padding: '2px 7px',
      background: q.side === 'buy' ? 'var(--ok-soft)' : '#f6e4e0',
      color: q.side === 'buy' ? 'var(--ok)' : '#a43a2c',
      borderColor: q.side === 'buy' ? 'var(--ok-line)' : '#e6c4b8'
    }
  }, q.side.toUpperCase())), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, q.size.split('.')[0], /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted)'
    }
  }, ".", q.size.split('.')[1]))), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, q.price)), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, q.total.split('.')[0], /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted)'
    }
  }, ".", q.total.split('.')[1]))), /*#__PURE__*/React.createElement("td", null, q.funded ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 50,
      background: 'var(--ok)',
      boxShadow: '0 0 0 3px var(--ok-soft)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ok)',
      fontWeight: 500,
      fontSize: 11.5
    }
  }, "Pearl funded")) : /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 50,
      background: 'var(--muted-2)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted)',
      fontSize: 11.5
    }
  }, "Unfunded"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'var(--accent)',
      fontSize: 11,
      marginLeft: 4
    }
  }, "Fund now \u2192"))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      fontSize: 11.5,
      color: q.near ? 'var(--warn)' : 'var(--ink)'
    }
  }, q.expires)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, q.views), " ", /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, "seen"), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      margin: '0 6px'
    }
  }, "\xB7"), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: q.takes > 0 ? 'var(--ok)' : 'var(--muted)'
    }
  }, q.takes, " ", q.takes === 1 ? 'taker' : 'takers'))), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      cursor: 'pointer',
      display: 'inline-flex',
      gap: 3,
      padding: '4px 8px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 3,
      height: 3,
      borderRadius: 50,
      background: 'currentColor'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 3,
      height: 3,
      borderRadius: 50,
      background: 'currentColor'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 3,
      height: 3,
      borderRadius: 50,
      background: 'currentColor'
    }
  }))));
}

// ── In-flight row (links to /trades/:id) ─────────────────────────────────────
function InflightRow({
  t
}) {
  return /*#__PURE__*/React.createElement("tr", {
    style: {
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      fontSize: 11.5,
      color: 'var(--accent)',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5
    }
  }, t.id, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted-2)'
    }
  }, "\u2197"))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(StateBadge, {
    state: t.state
  })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--muted)'
    }
  }, t.counterparty)), /*#__PURE__*/React.createElement("td", {
    className: "num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, t.size)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11.5
    }
  }, t.why), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      marginLeft: 6,
      fontSize: 11
    }
  }, "\xB7"), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      marginLeft: 6,
      fontSize: 11,
      color: 'var(--ink-2)'
    }
  }, t.inState)));
}

// ── Header ───────────────────────────────────────────────────────────────────
function MyQuotesHeader({
  openCount = 4,
  inflightCount = 3,
  notional = "112,400"
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 28px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 4
    }
  }, "my desk"), /*#__PURE__*/React.createElement("div", {
    className: "h1"
  }, "My quotes"), /*#__PURE__*/React.createElement("div", {
    className: "muted",
    style: {
      fontSize: 12,
      marginTop: 4
    }
  }, "Quotes you've posted and trades you're settling. Counterparties never see your address \u2014 only the maker handle.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn"
  }, "Export CSV"), /*#__PURE__*/React.createElement("button", {
    className: "btn accent"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "10",
    height: "10",
    viewBox: "0 0 10 10"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M5 1V9 M1 5H9",
    stroke: "currentColor",
    strokeWidth: "1.3"
  })), "Post a quote"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement(StatTile, {
    label: "open quotes",
    value: openCount,
    delta: "+1 vs. yesterday",
    mono: false
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "in settlement",
    value: inflightCount,
    delta: "updated 4s ago",
    mono: false
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "notional posted \xB7 24h",
    value: notional,
    delta: "USDC"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "median time-to-fill",
    value: "04:11",
    delta: "\u221212% week"
  })));
}

// ── Sections ─────────────────────────────────────────────────────────────────
function WaitingSection({
  rows,
  highlightTopRow = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 28px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "h2"
  }, "Waiting for a counterparty"), /*#__PURE__*/React.createElement("span", {
    className: "muted mono",
    style: {
      fontSize: 11,
      marginLeft: 8
    }
  }, rows.length)), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontSize: 11.5
    }
  }, "posted by ", /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--ink)'
    }
  }, "mkr_4f8a\u2026b21c"), " \xB7 ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'var(--accent)'
    }
  }, "change handle"))), /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      width: 60
    }
  }, "Side"), /*#__PURE__*/React.createElement("th", {
    className: "num",
    style: {
      width: 160
    }
  }, "Size \xB7 PRL"), /*#__PURE__*/React.createElement("th", {
    className: "num",
    style: {
      width: 90
    }
  }, "Price"), /*#__PURE__*/React.createElement("th", {
    className: "num",
    style: {
      width: 140
    }
  }, "Total \xB7 USDC"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 180
    }
  }, "Escrow status"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 90
    }
  }, "Expires in"), /*#__PURE__*/React.createElement("th", null, "Engagement"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 60
    }
  }))), /*#__PURE__*/React.createElement("tbody", null, rows.map((q, i) => /*#__PURE__*/React.createElement(WaitingRow, {
    key: q.id,
    q: q,
    highlighted: highlightTopRow && i === 0
  }))))));
}
function InflightSection({
  rows,
  highlightTopRow = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 28px 28px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "h2"
  }, "In flight"), /*#__PURE__*/React.createElement("span", {
    className: "muted mono",
    style: {
      fontSize: 11,
      marginLeft: 8
    }
  }, rows.length)), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontSize: 11.5
    }
  }, "mid-settlement \xB7 click any row to open ", /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      color: 'var(--ink)'
    }
  }, "/trades/:id"))), /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("table", {
    className: "tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      width: 220
    }
  }, "Trade ID"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 200
    }
  }, "State"), /*#__PURE__*/React.createElement("th", {
    style: {
      width: 170
    }
  }, "Counterparty"), /*#__PURE__*/React.createElement("th", {
    className: "num",
    style: {
      width: 200
    }
  }, "Size"), /*#__PURE__*/React.createElement("th", null, "Time in state"))), /*#__PURE__*/React.createElement("tbody", null, rows.map((t, i) => /*#__PURE__*/React.createElement(InflightRow, {
    key: t.id,
    t: t
  }))))));
}

// ── Empty state ──────────────────────────────────────────────────────────────
function MyQuotesEmpty() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 28px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "eyebrow",
    style: {
      marginBottom: 4
    }
  }, "my desk"), /*#__PURE__*/React.createElement("div", {
    className: "h1"
  }, "My quotes"))), /*#__PURE__*/React.createElement("div", {
    className: "card",
    style: {
      padding: '64px 32px',
      textAlign: 'center',
      background: 'var(--surface-2)',
      maxWidth: 600,
      margin: '40px auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: '50%',
      background: 'radial-gradient(circle at 35% 35%, #fff 0%, #ecebe1 35%, #cfcdb8 70%, #8b8973 100%)',
      margin: '0 auto 18px',
      boxShadow: 'inset 0 0 0 0.5px rgba(0,0,0,.12)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "h2",
    style: {
      marginBottom: 6
    }
  }, "You haven't posted yet."), /*#__PURE__*/React.createElement("div", {
    className: "muted",
    style: {
      fontSize: 12.5,
      marginBottom: 22,
      lineHeight: 1.55,
      maxWidth: 380,
      margin: '0 auto 22px'
    }
  }, "Your open quotes and mid-settlement trades will show up here. Post a quote to the open board, or request one from the desk."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn accent"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "10",
    height: "10",
    viewBox: "0 0 10 10"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M5 1V9 M1 5H9",
    stroke: "currentColor",
    strokeWidth: "1.3"
  })), "Post a quote"), /*#__PURE__*/React.createElement("button", {
    className: "btn"
  }, "RFQ the desk \u2192"))));
}

// ── Just-taken toast ─────────────────────────────────────────────────────────
function JustTakenToast() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 28px',
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "banner info",
    style: {
      background: 'var(--ok-soft)',
      borderColor: 'var(--ok-line)',
      color: 'var(--ok)',
      padding: '11px 14px',
      fontSize: 12.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic",
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-mono)',
      fontWeight: 600
    }
  }, "\u2713"), /*#__PURE__*/React.createElement("div", {
    className: "body"
  }, /*#__PURE__*/React.createElement("strong", null, "Your quote ", /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "qte_01J5K9V2D7M3PKAE"), " just got taken."), /*#__PURE__*/React.createElement("div", {
    className: "lede",
    style: {
      color: 'var(--ok)',
      opacity: .8
    }
  }, "Settlement started 4s ago. ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'inherit'
    }
  }, "Open ", /*#__PURE__*/React.createElement("span", {
    className: "mono"
  }, "trd_01J5KAB7D8FXKL01"), " \u2192"))), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      cursor: 'pointer',
      fontSize: 14,
      color: 'var(--ok)',
      alignSelf: 'center'
    }
  }, "\u2715")));
}

// ── Variants ─────────────────────────────────────────────────────────────────
const MyQuotesEmptyV = () => /*#__PURE__*/React.createElement(PageShell, {
  path: "/my-quotes"
}, /*#__PURE__*/React.createElement(MyQuotesEmpty, null));
const MyQuotesAllWaitingV = () => /*#__PURE__*/React.createElement(PageShell, {
  path: "/my-quotes"
}, /*#__PURE__*/React.createElement(MyQuotesHeader, {
  openCount: WAITING_ROWS.length,
  inflightCount: 0,
  notional: "42,662"
}), /*#__PURE__*/React.createElement(WaitingSection, {
  rows: WAITING_ROWS
}));
const MyQuotesMixedV = () => /*#__PURE__*/React.createElement(PageShell, {
  path: "/my-quotes"
}, /*#__PURE__*/React.createElement(MyQuotesHeader, {
  openCount: WAITING_ROWS.length,
  inflightCount: INFLIGHT_ROWS.length
}), /*#__PURE__*/React.createElement(WaitingSection, {
  rows: WAITING_ROWS
}), /*#__PURE__*/React.createElement(InflightSection, {
  rows: INFLIGHT_ROWS
}));
const MyQuotesJustTakenV = () => {
  const newInflight = [{
    id: "trd_01J5KAB7D8FXKL01",
    state: "pearl_escrow_pending",
    counterparty: "tkr_2f8e…91ca",
    size: "5,000.00000000 PRL",
    inState: "4s",
    why: "Awaiting funding"
  }, ...INFLIGHT_ROWS];
  // remove the just-taken row from waiting (qte_01J5K9V2D7M3PKAE)
  const remainingWaiting = WAITING_ROWS.filter(q => q.id !== 'qte_01J5K9V2D7M3PKAE');
  return /*#__PURE__*/React.createElement(PageShell, {
    path: "/my-quotes"
  }, /*#__PURE__*/React.createElement(MyQuotesHeader, {
    openCount: remainingWaiting.length,
    inflightCount: newInflight.length
  }), /*#__PURE__*/React.createElement(JustTakenToast, null), /*#__PURE__*/React.createElement(WaitingSection, {
    rows: remainingWaiting
  }), /*#__PURE__*/React.createElement(InflightSection, {
    rows: newInflight,
    highlightTopRow: true
  }));
};
window.PageMyQuotes = {
  variants: [{
    id: 'empty',
    label: 'empty · no quotes posted yet',
    Page: MyQuotesEmptyV,
    height: 720
  }, {
    id: 'all-waiting',
    label: 'populated · all waiting for a counterparty',
    Page: MyQuotesAllWaitingV,
    height: 740
  }, {
    id: 'mixed',
    label: 'mixed · waiting + in-flight',
    Page: MyQuotesMixedV,
    height: 980
  }, {
    id: 'just-taken',
    label: 'one quote just got taken (toast)',
    Page: MyQuotesJustTakenV,
    height: 1040
  }]
};

// ═══ src/page-mobile.jsx ═══

// Mobile — one representative frame per customer-facing page.
// 390 × 844, iOS-ish viewport. Same components, single column.

function MobileChrome({
  path
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 38,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 22px',
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--ink)',
      background: 'var(--surface)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 600
    }
  }, "9:41"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--muted)'
    }
  }, "\u2022\u2022\u2022")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '4px 12px 8px',
      background: 'var(--surface)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 30,
      background: 'var(--paper-2)',
      borderRadius: 10,
      display: 'flex',
      alignItems: 'center',
      padding: '0 12px',
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--muted)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "otc.pearl.dev", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ink-2)'
    }
  }, path)))));
}
function MobileNav() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '10px 14px',
      borderTop: '1px solid var(--hairline)',
      borderBottom: '1px solid var(--hairline)',
      background: 'var(--surface)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 16,
      height: 16,
      borderRadius: '50%',
      background: 'radial-gradient(circle at 35% 35%, #fff 0%, #ecebe1 30%, #cfcdb8 60%, #8b8973 100%)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: 13
    }
  }, "Pearl OTC"), /*#__PURE__*/React.createElement("span", {
    className: "env-pill",
    style: {
      fontSize: 9,
      padding: '1px 6px'
    }
  }, "testnet"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "muted",
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10
    }
  }, "desk@"));
}

// ── 1 — /quote on mobile ────────────────────────────────────────────────────

const MobileQuote = () => /*#__PURE__*/React.createElement("div", {
  className: "pearl",
  style: {
    height: '100%',
    display: 'flex',
    flexDirection: 'column'
  }
}, /*#__PURE__*/React.createElement(MobileChrome, {
  path: "/quote"
}), /*#__PURE__*/React.createElement(MobileNav, null), /*#__PURE__*/React.createElement("div", {
  style: {
    flex: 1,
    overflow: 'auto',
    padding: '16px 14px 28px'
  }
}, /*#__PURE__*/React.createElement("div", {
  className: "eyebrow",
  style: {
    marginBottom: 4
  }
}, "Request for quote"), /*#__PURE__*/React.createElement("h1", {
  style: {
    fontSize: 19,
    fontWeight: 600,
    letterSpacing: -0.4,
    margin: '0 0 16px'
  }
}, "Get a PRL \u2194 USDC quote"), /*#__PURE__*/React.createElement("div", {
  style: {
    background: 'var(--surface)',
    border: '1px solid var(--hairline)',
    borderRadius: 'var(--r-3)'
  }
}, /*#__PURE__*/React.createElement("div", {
  className: "tabs",
  style: {
    padding: '0 12px'
  }
}, /*#__PURE__*/React.createElement("div", {
  className: "tab active",
  style: {
    fontSize: 12
  }
}, "Buy PRL"), /*#__PURE__*/React.createElement("div", {
  className: "tab",
  style: {
    fontSize: 12
  }
}, "Sell PRL")), /*#__PURE__*/React.createElement("div", {
  style: {
    padding: '16px 14px'
  }
}, /*#__PURE__*/React.createElement("div", {
  style: {
    marginBottom: 12
  }
}, /*#__PURE__*/React.createElement("label", {
  className: "label"
}, "Amount in PRL"), /*#__PURE__*/React.createElement("input", {
  className: "input mono",
  value: "12,500.00000000",
  readOnly: true
})), /*#__PURE__*/React.createElement("div", {
  style: {
    marginBottom: 12
  }
}, /*#__PURE__*/React.createElement("label", {
  className: "label"
}, "Buyer Pearl address"), /*#__PURE__*/React.createElement("input", {
  className: "input mono",
  value: "tprl1p\u2026fkg7v",
  readOnly: true,
  style: {
    fontSize: 10.5
  }
})), /*#__PURE__*/React.createElement("div", {
  style: {
    marginBottom: 14
  }
}, /*#__PURE__*/React.createElement("label", {
  className: "label"
}, "Refund Base address"), /*#__PURE__*/React.createElement("input", {
  className: "input mono",
  value: "0x7a4c\u20268a4E",
  readOnly: true,
  style: {
    fontSize: 10.5
  }
})), /*#__PURE__*/React.createElement("button", {
  className: "btn accent lg",
  style: {
    width: '100%',
    justifyContent: 'center'
  }
}, "Request quote"))), /*#__PURE__*/React.createElement("div", {
  style: {
    marginTop: 16
  }
}, /*#__PURE__*/React.createElement(QuoteSummary, null)), /*#__PURE__*/React.createElement("button", {
  className: "btn accent lg",
  style: {
    width: '100%',
    justifyContent: 'center',
    marginTop: 12
  }
}, "Accept quote \u2192")));

// ── 2 — /trades/:id on mobile (stacked cards) ───────────────────────────────

const MobileTrade = () => /*#__PURE__*/React.createElement("div", {
  className: "pearl",
  style: {
    height: '100%',
    display: 'flex',
    flexDirection: 'column'
  }
}, /*#__PURE__*/React.createElement(MobileChrome, {
  path: `/trades/${SAMPLE.tradeId.slice(0, 8)}…`
}), /*#__PURE__*/React.createElement(MobileNav, null), /*#__PURE__*/React.createElement("div", {
  style: {
    flex: 1,
    overflow: 'auto'
  }
}, /*#__PURE__*/React.createElement("div", {
  style: {
    padding: '12px 14px 14px',
    background: 'var(--surface)',
    borderBottom: '1px solid var(--hairline)'
  }
}, /*#__PURE__*/React.createElement("div", {
  style: {
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    marginBottom: 10,
    flexWrap: 'wrap'
  }
}, /*#__PURE__*/React.createElement("span", {
  className: "mono",
  style: {
    fontSize: 11
  }
}, SAMPLE.tradeId.slice(0, 18), "\u2026"), /*#__PURE__*/React.createElement(StateBadge, {
  state: "pearl_escrow_seen"
})), /*#__PURE__*/React.createElement("div", {
  style: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: 6
  }
}, /*#__PURE__*/React.createElement(Countdown, {
  label: "pearl_funding",
  value: "00:23:14"
}), /*#__PURE__*/React.createElement(Countdown, {
  label: "usdc_deposit",
  value: "00:19:47"
}), /*#__PURE__*/React.createElement(Countdown, {
  label: "settlement",
  value: "01:43:02"
}), /*#__PURE__*/React.createElement(Countdown, {
  label: "refund_avail",
  value: "01:13:44"
}))), /*#__PURE__*/React.createElement("div", {
  style: {
    padding: '14px 12px 24px',
    display: 'flex',
    flexDirection: 'column',
    gap: 14
  }
}, /*#__PURE__*/React.createElement(PearlCard, {
  status: "seen",
  confirmations: 3
}), /*#__PURE__*/React.createElement(BaseCard, {
  status: "awaiting"
}), /*#__PURE__*/React.createElement("div", {
  className: "card"
}, /*#__PURE__*/React.createElement("div", {
  className: "card-header"
}, /*#__PURE__*/React.createElement("span", {
  className: "h2"
}, "Activity")), /*#__PURE__*/React.createElement("div", {
  style: {
    padding: '4px 14px 10px'
  }
}, /*#__PURE__*/React.createElement(Timeline, {
  events: TL_EVENTS.pearl_seen.slice(0, 4)
}))))));

// ── 3 — /trades/:id/proof on mobile (collapses to single column) ────────────

const MobileProof = () => /*#__PURE__*/React.createElement("div", {
  className: "pearl",
  style: {
    height: '100%',
    display: 'flex',
    flexDirection: 'column'
  }
}, /*#__PURE__*/React.createElement(MobileChrome, {
  path: `/…/proof`
}), /*#__PURE__*/React.createElement("div", {
  style: {
    padding: '12px 14px 14px',
    background: 'var(--surface)',
    borderBottom: '1px solid var(--hairline)'
  }
}, /*#__PURE__*/React.createElement("div", {
  className: "eyebrow",
  style: {
    marginBottom: 4
  }
}, "public proof"), /*#__PURE__*/React.createElement("h1", {
  style: {
    fontSize: 16,
    fontWeight: 600,
    margin: 0,
    lineHeight: 1.25
  }
}, "Verifiable receipt"), /*#__PURE__*/React.createElement("div", {
  className: "mono",
  style: {
    fontSize: 10.5,
    color: 'var(--muted)',
    marginTop: 4
  }
}, SAMPLE.tradeId), /*#__PURE__*/React.createElement("div", {
  style: {
    marginTop: 8
  }
}, /*#__PURE__*/React.createElement(StateBadge, {
  state: "released"
}))), /*#__PURE__*/React.createElement("div", {
  style: {
    flex: 1,
    overflow: 'auto',
    padding: '16px 14px 24px'
  }
}, /*#__PURE__*/React.createElement("div", {
  className: "eyebrow",
  style: {
    marginBottom: 8
  }
}, "01 \xB7 quote terms"), /*#__PURE__*/React.createElement("dl", {
  className: "kv",
  style: {
    gridTemplateColumns: '110px 1fr',
    fontSize: 11,
    marginBottom: 18
  }
}, /*#__PURE__*/React.createElement("dt", null, "side"), /*#__PURE__*/React.createElement("dd", null, "BUY"), /*#__PURE__*/React.createElement("dt", null, "amount PRL"), /*#__PURE__*/React.createElement("dd", {
  className: "mono"
}, "12,500.00000000"), /*#__PURE__*/React.createElement("dt", null, "amount USDC"), /*#__PURE__*/React.createElement("dd", {
  className: "mono"
}, "8,237.500000"), /*#__PURE__*/React.createElement("dt", null, "price"), /*#__PURE__*/React.createElement("dd", {
  className: "mono"
}, "0.659000")), /*#__PURE__*/React.createElement("div", {
  className: "eyebrow",
  style: {
    marginBottom: 8
  }
}, "02 \xB7 pearl leg"), /*#__PURE__*/React.createElement("dl", {
  className: "kv",
  style: {
    gridTemplateColumns: '110px 1fr',
    fontSize: 11,
    marginBottom: 18
  }
}, /*#__PURE__*/React.createElement("dt", null, "network"), /*#__PURE__*/React.createElement("dd", null, "testnet2"), /*#__PURE__*/React.createElement("dt", null, "funding tx"), /*#__PURE__*/React.createElement("dd", {
  className: "mono",
  style: {
    color: 'var(--accent)',
    fontSize: 10.5
  }
}, "f3c1a9\u2026f1a2 \u2197"), /*#__PURE__*/React.createElement("dt", null, "release tx"), /*#__PURE__*/React.createElement("dd", {
  className: "mono",
  style: {
    color: 'var(--accent)',
    fontSize: 10.5
  }
}, "a7b8c9\u2026a7b8 \u2197")), /*#__PURE__*/React.createElement("div", {
  className: "eyebrow",
  style: {
    marginBottom: 8
  }
}, "03 \xB7 base leg"), /*#__PURE__*/React.createElement("dl", {
  className: "kv",
  style: {
    gridTemplateColumns: '110px 1fr',
    fontSize: 11
  }
}, /*#__PURE__*/React.createElement("dt", null, "network"), /*#__PURE__*/React.createElement("dd", null, "sepolia"), /*#__PURE__*/React.createElement("dt", null, "deposit tx"), /*#__PURE__*/React.createElement("dd", {
  className: "mono",
  style: {
    color: 'var(--accent)',
    fontSize: 10.5
  }
}, "0xc4d5\u2026c4d5 \u2197"), /*#__PURE__*/React.createElement("dt", null, "release tx"), /*#__PURE__*/React.createElement("dd", {
  className: "mono",
  style: {
    color: 'var(--accent)',
    fontSize: 10.5
  }
}, "0xa1b2\u2026a1b2 \u2197"))));

// ── 4 — /trades/:id failure-state on mobile (banner-dominant) ───────────────

const MobileFailure = () => /*#__PURE__*/React.createElement("div", {
  className: "pearl",
  style: {
    height: '100%',
    display: 'flex',
    flexDirection: 'column'
  }
}, /*#__PURE__*/React.createElement(MobileChrome, {
  path: `/trades/${SAMPLE.tradeId.slice(0, 8)}…`
}), /*#__PURE__*/React.createElement(MobileNav, null), /*#__PURE__*/React.createElement("div", {
  style: {
    flex: 1,
    overflow: 'auto'
  }
}, /*#__PURE__*/React.createElement("div", {
  style: {
    padding: '12px 14px',
    background: 'var(--surface)',
    borderBottom: '1px solid var(--hairline)'
  }
}, /*#__PURE__*/React.createElement("div", {
  style: {
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    marginBottom: 10,
    flexWrap: 'wrap'
  }
}, /*#__PURE__*/React.createElement("span", {
  className: "mono",
  style: {
    fontSize: 11
  }
}, SAMPLE.tradeId.slice(0, 18), "\u2026"), /*#__PURE__*/React.createElement(StateBadge, {
  state: "late_prl_funding"
}))), /*#__PURE__*/React.createElement("div", {
  style: {
    padding: '14px 12px 24px',
    display: 'flex',
    flexDirection: 'column',
    gap: 12
  }
}, /*#__PURE__*/React.createElement(FailureBanner, {
  state: "late_prl_funding"
}), /*#__PURE__*/React.createElement(PearlCard, {
  status: "late"
}), /*#__PURE__*/React.createElement(BaseCard, {
  status: "closed"
}), /*#__PURE__*/React.createElement("div", {
  className: "card"
}, /*#__PURE__*/React.createElement("div", {
  className: "card-header"
}, /*#__PURE__*/React.createElement("span", {
  className: "h2"
}, "Activity")), /*#__PURE__*/React.createElement("div", {
  style: {
    padding: '4px 14px 10px'
  }
}, /*#__PURE__*/React.createElement(Timeline, {
  events: TL_EVENTS.failure_generic.slice(0, 4)
}))))));
window.PageMobile = {
  variants: [{
    id: 'quote',
    label: '/quote · returned',
    Page: MobileQuote
  }, {
    id: 'trade',
    label: '/trades/:id · pearl_escrow_seen',
    Page: MobileTrade
  }, {
    id: 'proof',
    label: '/trades/:id/proof · released',
    Page: MobileProof
  }, {
    id: 'failure',
    label: '/trades/:id · late_prl_funding',
    Page: MobileFailure
  }]
};

// ═══ src/tweaks-panel.jsx ═══

// tweaks-panel.jsx
// Reusable Tweaks shell + form-control helpers.
//
// Owns the host protocol (listens for __activate_edit_mode / __deactivate_edit_mode,
// posts __edit_mode_available / __edit_mode_set_keys / __edit_mode_dismissed) so
// individual prototypes don't re-roll it. Ships a consistent set of controls so you
// don't hand-draw <input type="range">, segmented radios, steppers, etc.
//
// Usage (in an HTML file that loads React + Babel):
//
//   const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
//     "primaryColor": "#D97757",
//     "palette": ["#D97757", "#29261b", "#f6f4ef"],
//     "fontSize": 16,
//     "density": "regular",
//     "dark": false
//   }/*EDITMODE-END*/;
//
//   function App() {
//     const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
//     return (
//       <div style={{ fontSize: t.fontSize, color: t.primaryColor }}>
//         Hello
//         <TweaksPanel>
//           <TweakSection label="Typography" />
//           <TweakSlider label="Font size" value={t.fontSize} min={10} max={32} unit="px"
//                        onChange={(v) => setTweak('fontSize', v)} />
//           <TweakRadio  label="Density" value={t.density}
//                        options={['compact', 'regular', 'comfy']}
//                        onChange={(v) => setTweak('density', v)} />
//           <TweakSection label="Theme" />
//           <TweakColor  label="Primary" value={t.primaryColor}
//                        options={['#D97757', '#2A6FDB', '#1F8A5B', '#7A5AE0']}
//                        onChange={(v) => setTweak('primaryColor', v)} />
//           <TweakColor  label="Palette" value={t.palette}
//                        options={[['#D97757', '#29261b', '#f6f4ef'],
//                                  ['#475569', '#0f172a', '#f1f5f9']]}
//                        onChange={(v) => setTweak('palette', v)} />
//           <TweakToggle label="Dark mode" value={t.dark}
//                        onChange={(v) => setTweak('dark', v)} />
//         </TweaksPanel>
//       </div>
//     );
//   }
//
// ─────────────────────────────────────────────────────────────────────────────

const __TWEAKS_STYLE = `
  .twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:280px;
    max-height:calc(100vh - 32px);display:flex;flex-direction:column;
    transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom right;
    background:rgba(250,249,247,.78);color:#29261b;
    -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
    border:.5px solid rgba(255,255,255,.6);border-radius:14px;
    box-shadow:0 1px 0 rgba(255,255,255,.5) inset,0 12px 40px rgba(0,0,0,.18);
    font:11.5px/1.4 ui-sans-serif,system-ui,-apple-system,sans-serif;overflow:hidden}
  .twk-hd{display:flex;align-items:center;justify-content:space-between;
    padding:10px 8px 10px 14px;cursor:move;user-select:none}
  .twk-hd b{font-size:12px;font-weight:600;letter-spacing:.01em}
  .twk-x{appearance:none;border:0;background:transparent;color:rgba(41,38,27,.55);
    width:22px;height:22px;border-radius:6px;cursor:default;font-size:13px;line-height:1}
  .twk-x:hover{background:rgba(0,0,0,.06);color:#29261b}
  .twk-body{padding:2px 14px 14px;display:flex;flex-direction:column;gap:10px;
    overflow-y:auto;overflow-x:hidden;min-height:0;
    scrollbar-width:thin;scrollbar-color:rgba(0,0,0,.15) transparent}
  .twk-body::-webkit-scrollbar{width:8px}
  .twk-body::-webkit-scrollbar-track{background:transparent;margin:2px}
  .twk-body::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px;
    border:2px solid transparent;background-clip:content-box}
  .twk-body::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.25);
    border:2px solid transparent;background-clip:content-box}
  .twk-row{display:flex;flex-direction:column;gap:5px}
  .twk-row-h{flex-direction:row;align-items:center;justify-content:space-between;gap:10px}
  .twk-lbl{display:flex;justify-content:space-between;align-items:baseline;
    color:rgba(41,38,27,.72)}
  .twk-lbl>span:first-child{font-weight:500}
  .twk-val{color:rgba(41,38,27,.5);font-variant-numeric:tabular-nums}

  .twk-sect{font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
    color:rgba(41,38,27,.45);padding:10px 0 0}
  .twk-sect:first-child{padding-top:0}

  .twk-field{appearance:none;box-sizing:border-box;width:100%;min-width:0;height:26px;padding:0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;
    background:rgba(255,255,255,.6);color:inherit;font:inherit;outline:none}
  .twk-field:focus{border-color:rgba(0,0,0,.25);background:rgba(255,255,255,.85)}
  select.twk-field{padding-right:22px;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='rgba(0,0,0,.5)' d='M0 0h10L5 6z'/></svg>");
    background-repeat:no-repeat;background-position:right 8px center}

  .twk-slider{appearance:none;-webkit-appearance:none;width:100%;height:4px;margin:6px 0;
    border-radius:999px;background:rgba(0,0,0,.12);outline:none}
  .twk-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
    width:14px;height:14px;border-radius:50%;background:#fff;
    border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}
  .twk-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
    background:#fff;border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}

  .twk-seg{position:relative;display:flex;padding:2px;border-radius:8px;
    background:rgba(0,0,0,.06);user-select:none}
  .twk-seg-thumb{position:absolute;top:2px;bottom:2px;border-radius:6px;
    background:rgba(255,255,255,.9);box-shadow:0 1px 2px rgba(0,0,0,.12);
    transition:left .15s cubic-bezier(.3,.7,.4,1),width .15s}
  .twk-seg.dragging .twk-seg-thumb{transition:none}
  .twk-seg button{appearance:none;position:relative;z-index:1;flex:1;border:0;
    background:transparent;color:inherit;font:inherit;font-weight:500;min-height:22px;
    border-radius:6px;cursor:default;padding:4px 6px;line-height:1.2;
    overflow-wrap:anywhere}

  .twk-toggle{position:relative;width:32px;height:18px;border:0;border-radius:999px;
    background:rgba(0,0,0,.15);transition:background .15s;cursor:default;padding:0}
  .twk-toggle[data-on="1"]{background:#34c759}
  .twk-toggle i{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;
    background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}
  .twk-toggle[data-on="1"] i{transform:translateX(14px)}

  .twk-num{display:flex;align-items:center;box-sizing:border-box;min-width:0;height:26px;padding:0 0 0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;background:rgba(255,255,255,.6)}
  .twk-num-lbl{font-weight:500;color:rgba(41,38,27,.6);cursor:ew-resize;
    user-select:none;padding-right:8px}
  .twk-num input{flex:1;min-width:0;height:100%;border:0;background:transparent;
    font:inherit;font-variant-numeric:tabular-nums;text-align:right;padding:0 8px 0 0;
    outline:none;color:inherit;-moz-appearance:textfield}
  .twk-num input::-webkit-inner-spin-button,.twk-num input::-webkit-outer-spin-button{
    -webkit-appearance:none;margin:0}
  .twk-num-unit{padding-right:8px;color:rgba(41,38,27,.45)}

  .twk-btn{appearance:none;height:26px;padding:0 12px;border:0;border-radius:7px;
    background:rgba(0,0,0,.78);color:#fff;font:inherit;font-weight:500;cursor:default}
  .twk-btn:hover{background:rgba(0,0,0,.88)}
  .twk-btn.secondary{background:rgba(0,0,0,.06);color:inherit}
  .twk-btn.secondary:hover{background:rgba(0,0,0,.1)}

  .twk-swatch{appearance:none;-webkit-appearance:none;width:56px;height:22px;
    border:.5px solid rgba(0,0,0,.1);border-radius:6px;padding:0;cursor:default;
    background:transparent;flex-shrink:0}
  .twk-swatch::-webkit-color-swatch-wrapper{padding:0}
  .twk-swatch::-webkit-color-swatch{border:0;border-radius:5.5px}
  .twk-swatch::-moz-color-swatch{border:0;border-radius:5.5px}

  .twk-chips{display:flex;gap:6px}
  .twk-chip{position:relative;appearance:none;flex:1;min-width:0;height:46px;
    padding:0;border:0;border-radius:6px;overflow:hidden;cursor:default;
    box-shadow:0 0 0 .5px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.06);
    transition:transform .12s cubic-bezier(.3,.7,.4,1),box-shadow .12s}
  .twk-chip:hover{transform:translateY(-1px);
    box-shadow:0 0 0 .5px rgba(0,0,0,.18),0 4px 10px rgba(0,0,0,.12)}
  .twk-chip[data-on="1"]{box-shadow:0 0 0 1.5px rgba(0,0,0,.85),
    0 2px 6px rgba(0,0,0,.15)}
  .twk-chip>span{position:absolute;top:0;bottom:0;right:0;width:34%;
    display:flex;flex-direction:column;box-shadow:-1px 0 0 rgba(0,0,0,.1)}
  .twk-chip>span>i{flex:1;box-shadow:0 -1px 0 rgba(0,0,0,.1)}
  .twk-chip>span>i:first-child{box-shadow:none}
  .twk-chip svg{position:absolute;top:6px;left:6px;width:13px;height:13px;
    filter:drop-shadow(0 1px 1px rgba(0,0,0,.3))}
`;

// ── useTweaks ───────────────────────────────────────────────────────────────
// Single source of truth for tweak values. setTweak persists via the host
// (__edit_mode_set_keys → host rewrites the EDITMODE block on disk).
function useTweaks(defaults) {
  const [values, setValues] = React.useState(defaults);
  // Accepts either setTweak('key', value) or setTweak({ key: value, ... }) so a
  // useState-style call doesn't write a "[object Object]" key into the persisted
  // JSON block.
  const setTweak = React.useCallback((keyOrEdits, val) => {
    const edits = typeof keyOrEdits === 'object' && keyOrEdits !== null ? keyOrEdits : {
      [keyOrEdits]: val
    };
    setValues(prev => ({
      ...prev,
      ...edits
    }));
    window.parent.postMessage({
      type: '__edit_mode_set_keys',
      edits
    }, '*');
    // Same-window signal so in-page listeners (deck-stage rail thumbnails)
    // can react — the parent message only reaches the host, not peers.
    window.dispatchEvent(new CustomEvent('tweakchange', {
      detail: edits
    }));
  }, []);
  return [values, setTweak];
}

// ── TweaksPanel ─────────────────────────────────────────────────────────────
// Floating shell. Registers the protocol listener BEFORE announcing
// availability — if the announce ran first, the host's activate could land
// before our handler exists and the toolbar toggle would silently no-op.
// The close button posts __edit_mode_dismissed so the host's toolbar toggle
// flips off in lockstep; the host echoes __deactivate_edit_mode back which
// is what actually hides the panel.
function TweaksPanel({
  title = 'Tweaks',
  noDeckControls = false,
  children
}) {
  const [open, setOpen] = React.useState(false);
  const dragRef = React.useRef(null);
  // Auto-inject a rail toggle when a <deck-stage> is on the page. The
  // toggle drives the deck's per-viewer _railVisible via window message;
  // state is mirrored from the same localStorage key the deck reads so
  // the control reflects reality across reloads. The mechanism is the
  // message — authors who want custom placement can post it directly
  // and pass noDeckControls to suppress this one.
  const hasDeckStage = React.useMemo(() => typeof document !== 'undefined' && !!document.querySelector('deck-stage'), []);
  // deck-stage enables its rail in connectedCallback, but this panel can
  // mount before that element has upgraded. The initial read catches the
  // common case; the listener covers mounting first. (Older deck-stage.js
  // copies still wait for the host's __omelette_rail_enabled postMessage —
  // same listener handles those.)
  const [railEnabled, setRailEnabled] = React.useState(() => hasDeckStage && !!document.querySelector('deck-stage')?._railEnabled);
  React.useEffect(() => {
    if (!hasDeckStage || railEnabled) return undefined;
    const onMsg = e => {
      if (e.data && e.data.type === '__omelette_rail_enabled') setRailEnabled(true);
    };
    window.addEventListener('message', onMsg);
    return () => window.removeEventListener('message', onMsg);
  }, [hasDeckStage, railEnabled]);
  const [railVisible, setRailVisible] = React.useState(() => {
    try {
      return localStorage.getItem('deck-stage.railVisible') !== '0';
    } catch (e) {
      return true;
    }
  });
  const toggleRail = on => {
    setRailVisible(on);
    window.postMessage({
      type: '__deck_rail_visible',
      on
    }, '*');
  };
  const offsetRef = React.useRef({
    x: 16,
    y: 16
  });
  const PAD = 16;
  const clampToViewport = React.useCallback(() => {
    const panel = dragRef.current;
    if (!panel) return;
    const w = panel.offsetWidth,
      h = panel.offsetHeight;
    const maxRight = Math.max(PAD, window.innerWidth - w - PAD);
    const maxBottom = Math.max(PAD, window.innerHeight - h - PAD);
    offsetRef.current = {
      x: Math.min(maxRight, Math.max(PAD, offsetRef.current.x)),
      y: Math.min(maxBottom, Math.max(PAD, offsetRef.current.y))
    };
    panel.style.right = offsetRef.current.x + 'px';
    panel.style.bottom = offsetRef.current.y + 'px';
  }, []);
  React.useEffect(() => {
    if (!open) return;
    clampToViewport();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', clampToViewport);
      return () => window.removeEventListener('resize', clampToViewport);
    }
    const ro = new ResizeObserver(clampToViewport);
    ro.observe(document.documentElement);
    return () => ro.disconnect();
  }, [open, clampToViewport]);
  React.useEffect(() => {
    const onMsg = e => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') setOpen(true);else if (t === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({
      type: '__edit_mode_available'
    }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const dismiss = () => {
    setOpen(false);
    window.parent.postMessage({
      type: '__edit_mode_dismissed'
    }, '*');
  };
  const onDragStart = e => {
    const panel = dragRef.current;
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    const sx = e.clientX,
      sy = e.clientY;
    const startRight = window.innerWidth - r.right;
    const startBottom = window.innerHeight - r.bottom;
    const move = ev => {
      offsetRef.current = {
        x: startRight - (ev.clientX - sx),
        y: startBottom - (ev.clientY - sy)
      };
      clampToViewport();
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, __TWEAKS_STYLE), /*#__PURE__*/React.createElement("div", {
    ref: dragRef,
    className: "twk-panel",
    "data-noncommentable": "",
    style: {
      right: offsetRef.current.x,
      bottom: offsetRef.current.y
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-hd",
    onMouseDown: onDragStart
  }, /*#__PURE__*/React.createElement("b", null, title), /*#__PURE__*/React.createElement("button", {
    className: "twk-x",
    "aria-label": "Close tweaks",
    onMouseDown: e => e.stopPropagation(),
    onClick: dismiss
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "twk-body"
  }, children, hasDeckStage && railEnabled && !noDeckControls && /*#__PURE__*/React.createElement(TweakSection, {
    label: "Deck"
  }, /*#__PURE__*/React.createElement(TweakToggle, {
    label: "Thumbnail rail",
    value: railVisible,
    onChange: toggleRail
  })))));
}

// ── Layout helpers ──────────────────────────────────────────────────────────

function TweakSection({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "twk-sect"
  }, label), children);
}
function TweakRow({
  label,
  value,
  children,
  inline = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: inline ? 'twk-row twk-row-h' : 'twk-row'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label), value != null && /*#__PURE__*/React.createElement("span", {
    className: "twk-val"
  }, value)), children);
}

// ── Controls ────────────────────────────────────────────────────────────────

function TweakSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  unit = '',
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label,
    value: `${value}${unit}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "range",
    className: "twk-slider",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }));
}
function TweakToggle({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "twk-toggle",
    "data-on": value ? '1' : '0',
    role: "switch",
    "aria-checked": !!value,
    onClick: () => onChange(!value)
  }, /*#__PURE__*/React.createElement("i", null)));
}
function TweakRadio({
  label,
  value,
  options,
  onChange
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  // The active value is read by pointer-move handlers attached for the lifetime
  // of a drag — ref it so a stale closure doesn't fire onChange for every move.
  const valueRef = React.useRef(value);
  valueRef.current = value;

  // Segments wrap mid-word once per-segment width runs out. The track is
  // ~248px (280 panel − 28 body pad − 4 seg pad), each button loses 12px
  // to its own padding, and 11.5px system-ui averages ~6.3px/char — so 2
  // options fit ~16 chars each, 3 fit ~10. Past that (or >3 options), fall
  // back to a dropdown rather than wrap.
  const labelLen = o => String(typeof o === 'object' ? o.label : o).length;
  const maxLen = options.reduce((m, o) => Math.max(m, labelLen(o)), 0);
  const fitsAsSegments = maxLen <= ({
    2: 16,
    3: 10
  }[options.length] ?? 0);
  if (!fitsAsSegments) {
    // <select> emits strings — map back to the original option value so the
    // fallback stays type-preserving (numbers, booleans) like the segment path.
    const resolve = s => {
      const m = options.find(o => String(typeof o === 'object' ? o.value : o) === s);
      return m === undefined ? s : typeof m === 'object' ? m.value : m;
    };
    return /*#__PURE__*/React.createElement(TweakSelect, {
      label: label,
      value: value,
      options: options,
      onChange: s => onChange(resolve(s))
    });
  }
  const opts = options.map(o => typeof o === 'object' ? o : {
    value: o,
    label: o
  });
  const idx = Math.max(0, opts.findIndex(o => o.value === value));
  const n = opts.length;
  const segAt = clientX => {
    const r = trackRef.current.getBoundingClientRect();
    const inner = r.width - 4;
    const i = Math.floor((clientX - r.left - 2) / inner * n);
    return opts[Math.max(0, Math.min(n - 1, i))].value;
  };
  const onPointerDown = e => {
    setDragging(true);
    const v0 = segAt(e.clientX);
    if (v0 !== valueRef.current) onChange(v0);
    const move = ev => {
      if (!trackRef.current) return;
      const v = segAt(ev.clientX);
      if (v !== valueRef.current) onChange(v);
    };
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    role: "radiogroup",
    onPointerDown: onPointerDown,
    className: dragging ? 'twk-seg dragging' : 'twk-seg'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-seg-thumb",
    style: {
      left: `calc(2px + ${idx} * (100% - 4px) / ${n})`,
      width: `calc((100% - 4px) / ${n})`
    }
  }), opts.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    role: "radio",
    "aria-checked": o.value === value
  }, o.label))));
}
function TweakSelect({
  label,
  value,
  options,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("select", {
    className: "twk-field",
    value: value,
    onChange: e => onChange(e.target.value)
  }, options.map(o => {
    const v = typeof o === 'object' ? o.value : o;
    const l = typeof o === 'object' ? o.label : o;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })));
}
function TweakText({
  label,
  value,
  placeholder,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("input", {
    className: "twk-field",
    type: "text",
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakNumber({
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange
}) {
  const clamp = n => {
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  const startRef = React.useRef({
    x: 0,
    val: 0
  });
  const onScrubStart = e => {
    e.preventDefault();
    startRef.current = {
      x: e.clientX,
      val: value
    };
    const decimals = (String(step).split('.')[1] || '').length;
    const move = ev => {
      const dx = ev.clientX - startRef.current.x;
      const raw = startRef.current.val + dx * step;
      const snapped = Math.round(raw / step) * step;
      onChange(clamp(Number(snapped.toFixed(decimals))));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "twk-num-lbl",
    onPointerDown: onScrubStart
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "number",
    value: value,
    min: min,
    max: max,
    step: step,
    onChange: e => onChange(clamp(Number(e.target.value)))
  }), unit && /*#__PURE__*/React.createElement("span", {
    className: "twk-num-unit"
  }, unit));
}

// Relative-luminance contrast pick — checkmarks drawn over a swatch need to
// read on both #111 and #fafafa without per-option configuration. Hex input
// only (#rgb / #rrggbb); named or rgb()/hsl() colors fall through to "light".
function __twkIsLight(hex) {
  const h = String(hex).replace('#', '');
  const x = h.length === 3 ? h.replace(/./g, c => c + c) : h.padEnd(6, '0');
  const n = parseInt(x.slice(0, 6), 16);
  if (Number.isNaN(n)) return true;
  const r = n >> 16 & 255,
    g = n >> 8 & 255,
    b = n & 255;
  return r * 299 + g * 587 + b * 114 > 148000;
}
const __TwkCheck = ({
  light
}) => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 14 14",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("path", {
  d: "M3 7.2 5.8 10 11 4.2",
  fill: "none",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  stroke: light ? 'rgba(0,0,0,.78)' : '#fff'
}));

// TweakColor — curated color/palette picker. Each option is either a single
// hex string or an array of 1-5 hex strings; the card adapts — a lone color
// renders solid, a palette renders colors[0] as the hero (left ~2/3) with the
// rest stacked in a sharp column on the right. onChange emits the
// option in the shape it was passed (string stays string, array stays array).
// Without options it falls back to the native color input for back-compat.
function TweakColor({
  label,
  value,
  options,
  onChange
}) {
  if (!options || !options.length) {
    return /*#__PURE__*/React.createElement("div", {
      className: "twk-row twk-row-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "twk-lbl"
    }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("input", {
      type: "color",
      className: "twk-swatch",
      value: value,
      onChange: e => onChange(e.target.value)
    }));
  }
  // Native <input type=color> emits lowercase hex per the HTML spec, so
  // compare case-insensitively. String() guards JSON.stringify(undefined),
  // which returns the primitive undefined (no .toLowerCase).
  const key = o => String(JSON.stringify(o)).toLowerCase();
  const cur = key(value);
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-chips",
    role: "radiogroup"
  }, options.map((o, i) => {
    const colors = Array.isArray(o) ? o : [o];
    const [hero, ...rest] = colors;
    const sup = rest.slice(0, 4);
    const on = key(o) === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      className: "twk-chip",
      role: "radio",
      "aria-checked": on,
      "data-on": on ? '1' : '0',
      "aria-label": colors.join(', '),
      title: colors.join(' · '),
      style: {
        background: hero
      },
      onClick: () => onChange(o)
    }, sup.length > 0 && /*#__PURE__*/React.createElement("span", null, sup.map((c, j) => /*#__PURE__*/React.createElement("i", {
      key: j,
      style: {
        background: c
      }
    }))), on && /*#__PURE__*/React.createElement(__TwkCheck, {
      light: __twkIsLight(hero)
    }));
  })));
}
function TweakButton({
  label,
  onClick,
  secondary = false
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: secondary ? 'twk-btn secondary' : 'twk-btn',
    onClick: onClick
  }, label);
}
Object.assign(window, {
  useTweaks,
  TweaksPanel,
  TweakSection,
  TweakRow,
  TweakSlider,
  TweakToggle,
  TweakRadio,
  TweakSelect,
  TweakText,
  TweakNumber,
  TweakColor,
  TweakButton
});