// /trades/:tradeId — Customer checkout (hero screen).
// 17 variants — one shared layout, different state inputs.

const { TL_EVENTS } = window.PearlData;

// ── Layout ──────────────────────────────────────────────────────────────────

function TradeLayout({
  state = 'pearl_escrow_pending',
  pearlStatus = 'pending',
  pearlConf = 0,
  baseStatus = 'awaiting',
  baseWallet = 'connected',
  baseNetwork = 'right',
  failureState,
  timeline = TL_EVENTS.pearl_escrow_pending,
  banner,
  extraBelow,
  showRefundAction = false,
  showRefundedBanner = false,
}) {
  return (
    <PageShell path={`/trades/${SAMPLE.tradeId}`}>
      <div style={{ height: '100%', overflow: 'auto' }}>
        <TradeHeader state={state} />
        <div style={{ padding: '24px 28px 60px' }}>
          {failureState && (
            <div style={{ marginBottom: 18 }}>
              <FailureBanner state={failureState} />
            </div>
          )}
          {banner && (
            <div style={{ marginBottom: 18 }}>{banner}</div>
          )}
          {showRefundedBanner && (
            <div style={{ marginBottom: 18 }}>
              <Banner tone="warn"
                title="This trade has been refunded."
                body="USDC was returned to the buyer's refund address. PRL was returned to the seller. No further action required." />
            </div>
          )}
          {showRefundAction && (
            <div style={{ marginBottom: 18 }}>
              <Banner tone="warn"
                title="Refund is now available."
                body="The buyer leg is past its refund window without confirmation. You may request a refund of any deposited USDC."
                action="Request refund →" />
            </div>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, alignItems: 'start' }}>
            <PearlCard status={pearlStatus} confirmations={pearlConf} />
            <BaseCard status={baseStatus} wallet={baseWallet} network={baseNetwork} />
          </div>

          {extraBelow}

          <div style={{ marginTop: 20 }}>
            <div className="card">
              <div className="card-header">
                <span className="h2">Activity</span>
                <span className="muted" style={{ fontSize: 11 }}>events stream · server-authoritative</span>
              </div>
              <div style={{ padding: '6px 18px 12px' }}>
                <Timeline events={timeline} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}

// ── Variant constructors ────────────────────────────────────────────────────

// 1 — pearl_escrow_pending: both legs empty (the hero/canonical state)
const TradePending = () => (
  <TradeLayout
    state="pearl_escrow_pending"
    pearlStatus="pending"
    baseStatus="awaiting"
    timeline={TL_EVENTS.pearl_escrow_pending}
  />
);

// 2 — Pearl funded only (observed + 3/6 confirmations)
const TradePearlOnly = () => (
  <TradeLayout
    state="pearl_escrow_seen"
    pearlStatus="seen"
    pearlConf={3}
    baseStatus="awaiting"
    timeline={TL_EVENTS.pearl_seen}
  />
);

// 3 — Base funded only — Pearl still pending
const TradeBaseOnly = () => (
  <TradeLayout
    state="usdc_escrow_pending"
    pearlStatus="pending"
    baseStatus="confirming"
    timeline={[
      { chain: "sys", ev: "Quote accepted; escrows allocated", meta: "14:22:08 UTC", time: "9 min ago" },
      { chain: "base", ev: "USDC deposit observed", meta: "0xc4d5…c4d5", time: "5 min ago" },
      { chain: "base", ev: "Confirmation 4 of 12", meta: "block 21,007,442", time: "1 min ago" },
    ]}
  />
);

// 4 — Both confirming
const TradeBothConfirming = () => (
  <TradeLayout
    state="usdc_escrow_confirmed"
    pearlStatus="confirmed"
    baseStatus="confirming"
    timeline={TL_EVENTS.both_confirming}
  />
);

// 5 — Release pending (both confirmed, releases broadcasting)
const TradeReleasePending = () => (
  <TradeLayout
    state="release_pending"
    pearlStatus="confirmed"
    baseStatus="confirmed"
    banner={<Banner tone="info" title="Releases broadcasting on both chains."
            body="No action required. Both legs are funded and confirmed; the desk is broadcasting release transactions now."
            action={null} />}
    timeline={[
      ...TL_EVENTS.both_confirming.slice(0, -1),
      { chain: "base", ev: "USDC deposit confirmed", meta: "12/12 confirmations", time: "3 min ago" },
      { chain: "sys", ev: "Release authorized", meta: "server-driven · idempotency 0x7e…2a", time: "1 min ago" },
      { chain: "pearl", ev: "PRL release submitted", meta: "broadcasting…", time: "30s ago" },
      { chain: "base", ev: "USDC release submitted", meta: "broadcasting…", time: "20s ago" },
    ]}
  />
);

// 6 — Released (terminal happy)
const TradeReleased = () => (
  <TradeLayout
    state="released"
    pearlStatus="released"
    baseStatus="confirmed"
    banner={
      <div style={{
        display: 'flex', alignItems: 'center', gap: 14,
        padding: '14px 18px',
        background: 'var(--ok-soft)', border: '1px solid var(--ok-line)', borderRadius: 'var(--r-3)',
      }}>
        <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'var(--ok)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 600 }}>✓</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 600, color: 'var(--ok)', fontSize: 14 }}>Trade released.</div>
          <div style={{ fontSize: 12, color: 'var(--ok)', opacity: 0.85, marginTop: 2 }}>
            12,500.00000000 PRL delivered to buyer · 8,237.500000 USDC delivered to seller · settled in 23m 03s.
          </div>
        </div>
        <a href="#" className="btn sm" style={{ background: 'var(--surface)', borderColor: 'var(--ok-line)', color: 'var(--ok)' }}>View public proof →</a>
      </div>
    }
    timeline={TL_EVENTS.released}
  />
);

// 7–15: Nine failure states. Each shares the standardized banner + the cards
// stay visible behind it so the audit context isn't hidden.

const TradeFailure = ({ failure, pearlStatus, baseStatus, timeline, pearlConf }) => (
  <TradeLayout
    state={failure}
    failureState={failure}
    pearlStatus={pearlStatus}
    baseStatus={baseStatus}
    pearlConf={pearlConf}
    timeline={timeline || TL_EVENTS.failure_generic}
  />
);

const TradeLatePrl       = () => <TradeFailure failure="late_prl_funding" pearlStatus="late" baseStatus="awaiting"
  timeline={[
    { chain: "sys", ev: "Quote accepted; escrows allocated", meta: "14:22:08 UTC", time: "47 min ago" },
    { chain: "err", ev: "pearl_funding deadline crossed", meta: "no Pearl deposit observed · 14:42:08 UTC", time: "27 min ago" },
    { chain: "pearl", ev: "Pearl deposit observed (LATE)", meta: "f3c1a9…f1a2 · 4m 21s after deadline", time: "23 min ago" },
    { chain: "pearl", ev: "Pearl deposit confirmed", meta: "6/6 confirmations · funding will not authorize release", time: "16 min ago" },
    { chain: "err", ev: "State entered: late_prl_funding", meta: "manual review queued", time: "16 min ago" },
  ]} />;

const TradeUsdcRefunded  = () => <TradeFailure failure="usdc_refunded" pearlStatus="confirmed" baseStatus="refunded"
  timeline={[
    { chain: "sys", ev: "Quote accepted; escrows allocated", meta: "14:22:08 UTC", time: "1h 4m ago" },
    { chain: "pearl", ev: "Pearl deposit confirmed", meta: "6/6 confirmations", time: "52 min ago" },
    { chain: "base", ev: "USDC deposit observed", meta: "0xc4d5…c4d5", time: "44 min ago" },
    { chain: "err", ev: "settlement deadline crossed", meta: "auto-refund initiated", time: "21 min ago" },
    { chain: "base", ev: "USDC refund broadcast", meta: "0xe5f6…e5f6", time: "20 min ago" },
    { chain: "base", ev: "USDC refund confirmed", meta: "12/12 confirmations", time: "8 min ago" },
    { chain: "err", ev: "State entered: usdc_refunded", meta: "PRL release blocked pending review", time: "8 min ago" },
  ]} />;

const TradeReleaseFailed = () => <TradeFailure failure="prl_release_failed" pearlStatus="confirmed" baseStatus="confirmed"
  timeline={[
    { chain: "pearl", ev: "Pearl deposit confirmed", meta: "6/6 confirmations", time: "38 min ago" },
    { chain: "base", ev: "USDC deposit confirmed", meta: "12/12 confirmations", time: "29 min ago" },
    { chain: "sys", ev: "Release authorized", meta: "idempotency 0x7e…2a", time: "22 min ago" },
    { chain: "err", ev: "PRL release broadcast failed", meta: "rpc: rejected · reason: utxo_already_spent", time: "22 min ago" },
    { chain: "err", ev: "Retry 1 of 3 failed", meta: "rpc: rejected · 21 min ago", time: "21 min ago" },
    { chain: "err", ev: "Retry 2 of 3 failed", meta: "rpc: rejected · 20 min ago", time: "20 min ago" },
    { chain: "err", ev: "Retry 3 of 3 failed → manual review", meta: "operator notified · 17 min ago", time: "17 min ago" },
  ]} />;

const TradeMismatch      = () => <TradeFailure failure="amount_mismatch" pearlStatus="mismatch" baseStatus="awaiting"
  timeline={[
    { chain: "pearl", ev: "Pearl deposit observed", meta: "f3c1a9…f1a2", time: "31 min ago" },
    { chain: "err", ev: "Amount mismatch detected", meta: "expected 12,500.00000000 PRL · observed 12,498.40000000 PRL · −1.60000000", time: "31 min ago" },
    { chain: "err", ev: "State entered: amount_mismatch", meta: "settlement halted pending review", time: "31 min ago" },
  ]} />;

const TradeReorged       = () => <TradeFailure failure="reorged" pearlStatus="reorged" baseStatus="awaiting"
  timeline={[
    { chain: "pearl", ev: "Pearl deposit observed", meta: "f3c1a9…f1a2 · block 18,432,901", time: "47 min ago" },
    { chain: "pearl", ev: "Confirmations 1–3", meta: "block 18,432,901 → 18,432,903", time: "42 min ago" },
    { chain: "err", ev: "Reorg detected", meta: "block 18,432,901 orphaned · depth 4", time: "12 min ago" },
    { chain: "err", ev: "State entered: reorged", meta: "awaiting re-confirmation on canonical chain", time: "12 min ago" },
  ]} />;

const TradeStaleIdx      = () => <TradeFailure failure="stale_indexer" pearlStatus="confirmed" baseStatus="awaiting"
  timeline={[
    { chain: "pearl", ev: "Pearl deposit confirmed", meta: "6/6 confirmations · 23 min ago", time: "23 min ago" },
    { chain: "sys", ev: "Indexer lag warning", meta: "lag 42s · threshold 30s", time: "4 min ago" },
    { chain: "err", ev: "State entered: stale_indexer", meta: "status may not reflect chain truth", time: "4 min ago" },
  ]} />;

const TradeUnknownSpend  = () => <TradeFailure failure="unknown_spend" pearlStatus="unknown" baseStatus="awaiting"
  timeline={[
    { chain: "pearl", ev: "Pearl deposit confirmed", meta: "6/6 confirmations", time: "1h 12m ago" },
    { chain: "err", ev: "Escrow output spent by unknown tx", meta: "spent in tx 9e2a3b…0c1d · not desk-authored", time: "8 min ago" },
    { chain: "err", ev: "State entered: unknown_spend", meta: "audit triggered · operator paged", time: "8 min ago" },
  ]} />;

const TradeManualReview  = () => <TradeFailure failure="failed_manual_review" pearlStatus="confirmed" baseStatus="confirmed"
  timeline={[
    { chain: "pearl", ev: "Pearl deposit confirmed", meta: "6/6 confirmations", time: "55 min ago" },
    { chain: "base", ev: "USDC deposit confirmed", meta: "12/12 confirmations", time: "47 min ago" },
    { chain: "err", ev: "Flagged for manual review", meta: "by op_07 · reason: counterparty KYC re-check", time: "12 min ago" },
    { chain: "err", ev: "State entered: failed_manual_review", meta: "settlement halted", time: "12 min ago" },
  ]} />;

const TradeDisputed      = () => <TradeFailure failure="disputed" pearlStatus="confirmed" baseStatus="confirmed"
  timeline={[
    { chain: "pearl", ev: "Pearl deposit confirmed", meta: "6/6 confirmations", time: "2h 13m ago" },
    { chain: "base", ev: "USDC deposit confirmed", meta: "12/12 confirmations", time: "2h 7m ago" },
    { chain: "err", ev: "Dispute opened", meta: "by counterparty · ticket DPT-0044 · reason: counterparty_unreachable", time: "1h 8m ago" },
    { chain: "err", ev: "State entered: disputed", meta: "release blocked until dispute resolves", time: "1h 8m ago" },
  ]} />;

// 16 — refund_available
const TradeRefundAvail = () => (
  <TradeLayout
    state="refund_available"
    pearlStatus="pending"
    baseStatus="confirmed"
    showRefundAction
    timeline={[
      { chain: "sys", ev: "Quote accepted; escrows allocated", meta: "14:22:08 UTC", time: "1h 12m ago" },
      { chain: "base", ev: "USDC deposit confirmed", meta: "12/12 confirmations", time: "57 min ago" },
      { chain: "err", ev: "pearl_funding deadline crossed", meta: "no Pearl deposit observed", time: "32 min ago" },
      { chain: "sys", ev: "Refund window opened", meta: "buyer may request refund", time: "just now" },
    ]}
  />
);

// 17 — refunded (terminal refund)
const TradeRefunded = () => (
  <TradeLayout
    state="refunded"
    pearlStatus="pending"
    baseStatus="refunded"
    showRefundedBanner
    timeline={[
      { chain: "sys", ev: "Quote accepted; escrows allocated", meta: "14:22:08 UTC", time: "2h 4m ago" },
      { chain: "base", ev: "USDC deposit confirmed", meta: "12/12 confirmations", time: "1h 49m ago" },
      { chain: "err", ev: "pearl_funding deadline crossed", meta: "no Pearl deposit observed", time: "1h 24m ago" },
      { chain: "sys", ev: "Refund requested", meta: "by buyer", time: "52 min ago" },
      { chain: "base", ev: "USDC refund broadcast", meta: "0xe5f6…e5f6", time: "51 min ago" },
      { chain: "base", ev: "USDC refund confirmed", meta: "12/12 confirmations", time: "40 min ago" },
      { chain: "ok", ev: "Trade refunded", meta: "terminal · ledger closed", time: "40 min ago" },
    ]}
  />
);

window.PageTrade = {
  variants: [
    { id: 'pending',         label: 'pearl_escrow_pending · canonical',        Page: TradePending,        height: 1080 },
    { id: 'pearl-only',      label: 'Pearl funded only · 3/6 confirmations',   Page: TradePearlOnly,      height: 1080 },
    { id: 'base-only',       label: 'Base funded only · Pearl still pending', Page: TradeBaseOnly,       height: 1080 },
    { id: 'both-confirming', label: 'both confirming',                          Page: TradeBothConfirming, height: 1080 },
    { id: 'release-pending', label: 'release_pending',                          Page: TradeReleasePending, height: 1080 },
    { id: 'released',        label: 'released · terminal happy',                Page: TradeReleased,       height: 1080 },

    { id: 'late-prl',        label: 'late_prl_funding',                         Page: TradeLatePrl,        height: 1160 },
    { id: 'usdc-refunded',   label: 'usdc_refunded',                            Page: TradeUsdcRefunded,   height: 1160 },
    { id: 'release-failed',  label: 'prl_release_failed',                       Page: TradeReleaseFailed,  height: 1160 },
    { id: 'mismatch',        label: 'amount_mismatch',                          Page: TradeMismatch,       height: 1100 },
    { id: 'reorged',         label: 'reorged',                                  Page: TradeReorged,        height: 1100 },
    { id: 'stale-indexer',   label: 'stale_indexer',                            Page: TradeStaleIdx,       height: 1100 },
    { id: 'unknown-spend',   label: 'unknown_spend',                            Page: TradeUnknownSpend,   height: 1100 },
    { id: 'manual-review',   label: 'failed_manual_review',                     Page: TradeManualReview,   height: 1100 },
    { id: 'disputed',        label: 'disputed',                                 Page: TradeDisputed,       height: 1100 },

    { id: 'refund-avail',    label: 'refund_available',                         Page: TradeRefundAvail,    height: 1100 },
    { id: 'refunded',        label: 'refunded · terminal',                      Page: TradeRefunded,       height: 1100 },
  ],
};
