// /offers — Live offer board (NEW)
// Stripe Payments list aesthetic. Single dense table.
// Variants: empty · populated mixed · filtered pearl-funded · one being taken.

const OFFERS_DATA = [
  // pearl-funded → green dot (the differentiator)
  { id: "qte_01J5K9XBHK2NRGV0", side: "sell", size: "12,500.00000000", price: "0.659000", total: "8,237.500000", funded: true,  expires: "12m 30s", maker: "mkr_4f8a…b21c", views: 47, takes: 0 },
  { id: "qte_01J5K9V2D7M3PKAE", side: "sell", size: "5,000.00000000",  price: "0.658500", total: "3,292.500000", funded: true,  expires: "08m 14s", maker: "mkr_d1c9…7a04", views: 23, takes: 0 },
  { id: "qte_01J5K9T8B6F0QHCY", side: "sell", size: "20,000.00000000", price: "0.660000", total: "13,200.000000",funded: false, expires: "23m 02s", maker: "mkr_92e4…f17b", views: 11, takes: 0 },
  { id: "qte_01J5K9SDC4XL8PMR", side: "sell", size: "1,000.00000000",  price: "0.659500", total: "659.500000",   funded: true,  expires: "01m 47s", maker: "mkr_a0bb…3c91", views: 84, takes: 0, nearExpiry: true },
  { id: "qte_01J5K9R7N9JK1WCP", side: "sell", size: "45,000.00000000", price: "0.661000", total: "29,745.000000",funded: false, expires: "18m 55s", maker: "mkr_67d2…e8a3", views: 5, takes: 0 },
  { id: "qte_01J5K9PE5G3MTYDB", side: "sell", size: "3,750.00000000",  price: "0.659200", total: "2,472.000000", funded: true,  expires: "14m 09s", maker: "mkr_3f12…b9e7", views: 19, takes: 0 },
  { id: "qte_01J5K9NA1B8VFXKQ", side: "sell", size: "8,000.00000000",  price: "0.660500", total: "5,284.000000", funded: false, expires: "26m 41s", maker: "mkr_c8a4…1e0d", views: 7, takes: 0 },
  { id: "qte_01J5K9KFT6C2DPNY", side: "sell", size: "2,500.00000000",  price: "0.658800", total: "1,647.000000", funded: true,  expires: "06m 12s", maker: "mkr_5b97…d4e2", views: 31, takes: 0 },
];

const TAKEN_OFFER = {
  id: "qte_01J5K9XBHK2NRGV0", side: "sell", size: "12,500.00000000",
  price: "0.659000", total: "8,237.500000", funded: true,
  expires: "12m 30s", maker: "mkr_4f8a…b21c", views: 48, takes: 1,
  taking: true,
};

// ── Offers table row ─────────────────────────────────────────────────────────
function OfferRow({ o, expanded, onToggle, taking }) {
  return (
    <>
      <tr onClick={onToggle} style={{ cursor: 'pointer', background: expanded ? 'var(--surface-2)' : (taking ? 'var(--accent-soft)' : undefined) }}>
        <td>
          <span className={`badge ${o.side === 'buy' ? 'ok' : 'err'}`} style={{
            fontSize: 9.5, padding: '2px 7px',
            background: o.side === 'buy' ? 'var(--ok-soft)' : '#f6e4e0',
            color: o.side === 'buy' ? 'var(--ok)' : '#a43a2c',
            borderColor: o.side === 'buy' ? 'var(--ok-line)' : '#e6c4b8'
          }}>
            {o.side.toUpperCase()}
          </span>
        </td>
        <td className="num">
          <span className="mono">
            {o.size.split('.')[0]}<span style={{ color: 'var(--muted)' }}>.{o.size.split('.')[1]}</span>
          </span>
        </td>
        <td className="num"><span className="mono">{o.price}</span></td>
        <td className="num">
          <span className="mono">
            {o.total.split('.')[0]}<span style={{ color: 'var(--muted)' }}>.{o.total.split('.')[1]}</span>
          </span>
        </td>
        <td>
          {o.funded ? (
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
              <span style={{
                width: 8, height: 8, borderRadius: 50, background: 'var(--ok)',
                boxShadow: '0 0 0 3px var(--ok-soft)'
              }} />
              <span style={{ color: 'var(--ok)', fontWeight: 500, fontSize: 11.5 }}>Pearl funded</span>
            </span>
          ) : (
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
              <span style={{ width: 8, height: 8, borderRadius: 50, background: 'var(--muted-2)' }} />
              <span style={{ color: 'var(--muted)', fontSize: 11.5 }}>Unfunded</span>
            </span>
          )}
        </td>
        <td>
          <span className="mono" style={{ fontSize: 11.5, color: o.nearExpiry ? 'var(--warn)' : 'var(--ink)' }}>
            {o.expires}
          </span>
        </td>
        <td>
          <span className="mono" style={{ fontSize: 11, color: 'var(--muted)', display: 'inline-flex', alignItems: 'center', gap: 5 }}>
            {o.maker}
            <span style={{ color: 'var(--muted-2)' }}><CopyIcon /></span>
          </span>
        </td>
        <td style={{ textAlign: 'right' }}>
          {taking ? (
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11.5, color: 'var(--accent)', fontWeight: 500 }}>
              <span className="spin" /> Taking…
            </span>
          ) : (
            <button className="btn sm" onClick={(e)=>e.stopPropagation()}>Take →</button>
          )}
        </td>
      </tr>
      {expanded && (
        <tr style={{ background: 'var(--surface-2)' }}>
          <td colSpan={8} style={{ padding: '14px 18px 18px', borderBottom: '1px solid var(--hairline-2)' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 28 }}>
              <div>
                <div className="eyebrow" style={{ marginBottom: 6 }}>quote id</div>
                <div className="mono" style={{ fontSize: 11, color: 'var(--ink)' }}>{o.id}</div>
              </div>
              <div>
                <div className="eyebrow" style={{ marginBottom: 6 }}>maker pubkey</div>
                <div className="mono" style={{ fontSize: 11, color: 'var(--ink)', wordBreak: 'break-all' }}>
                  03a4f8b21c9e0d5f7a3b2c1e8d4f6a9b0c2d3e4f5a6b7c8d9e
                </div>
              </div>
              <div>
                <div className="eyebrow" style={{ marginBottom: 6 }}>fee breakdown</div>
                <div style={{ fontSize: 11.5 }}>
                  <span className="mono">12.5 PRL</span> <span className="muted">·</span> <span className="mono">8.24 USDC</span>
                </div>
                <div className="muted" style={{ fontSize: 11, marginTop: 2 }}>maker rebate −0.025% · taker 0.15%</div>
              </div>
              <div>
                <div className="eyebrow" style={{ marginBottom: 6 }}>deadlines</div>
                <div style={{ fontSize: 11, lineHeight: 1.7 }}>
                  <div><span className="muted">pearl_funding</span> <span className="mono">12m 30s</span></div>
                  <div><span className="muted">usdc_deposit</span>  <span className="mono">10m 12s</span></div>
                  <div><span className="muted">settlement</span>    <span className="mono">42m 04s</span></div>
                </div>
              </div>
            </div>
            {o.funded && (
              <div style={{ marginTop: 14, padding: '10px 12px', background: 'var(--ok-soft)', border: '1px solid var(--ok-line)', borderRadius: 'var(--r-2)', display: 'flex', alignItems: 'center', gap: 10, fontSize: 11.5, color: 'var(--ok)' }}>
                <span style={{ width: 6, height: 6, borderRadius: 50, background: 'var(--ok)' }} />
                Maker's PRL is already escrowed at <span className="mono" style={{ color: 'var(--ink)' }}>prl1pn4g…lyq8m</span> — settlement starts the moment you deposit USDC.
              </div>
            )}
          </td>
        </tr>
      )}
    </>
  );
}

// ── Filters bar ──────────────────────────────────────────────────────────────
function FiltersBar({ pearlFundedOnly = false }) {
  return (
    <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
      <FilterChip label="Size" value="any" />
      <FilterChip label="Max spread" value="0.5%" />
      <FilterChip label="Network" value="testnet2" />
      <FilterChip label="Escrow" value={pearlFundedOnly ? "pearl funded only" : "all"} active={pearlFundedOnly} />
      <div style={{ flex: 1 }} />
      <span className="muted" style={{ fontSize: 11.5 }}>
        sorted by <span className="mono" style={{ color: 'var(--ink)' }}>price ↑</span>
      </span>
    </div>
  );
}

function FilterChip({ label, value, active }) {
  return (
    <button className="btn sm" style={{
      borderColor: active ? 'var(--accent-line)' : 'var(--hairline)',
      background: active ? 'var(--accent-soft)' : 'var(--surface)',
      color: active ? 'var(--accent-ink)' : 'var(--ink)',
      fontSize: 11.5,
    }}>
      <span className="muted" style={{ fontWeight: 400 }}>{label}:</span>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, marginLeft: 2 }}>{value}</span>
      <svg width="9" height="9" viewBox="0 0 9 9" style={{ marginLeft: 2 }}><path d="M1.5 3 L4.5 6 L7.5 3" stroke="currentColor" fill="none" strokeWidth="1.2" /></svg>
    </button>
  );
}

// ── Page shell + header ──────────────────────────────────────────────────────
function OffersHeader({ side = 'buy', onSide, pearlFundedOnly = false }) {
  return (
    <div style={{ padding: '20px 28px 0' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 16 }}>
        <div>
          <div className="eyebrow" style={{ marginBottom: 4 }}>liquidity</div>
          <div className="h1">Open offers</div>
          <div className="muted" style={{ fontSize: 12, marginTop: 4 }}>
            Take liquidity directly from other users without waiting for a desk quote.
          </div>
        </div>
        <button className="btn accent">
          <svg width="10" height="10" viewBox="0 0 10 10"><path d="M5 1V9 M1 5H9" stroke="currentColor" strokeWidth="1.3" /></svg>
          Post my own quote
        </button>
      </div>

      {/* Tab strip */}
      <div className="tabs" style={{ marginBottom: 14 }}>
        <div className={`tab ${side === 'buy' ? 'active' : ''}`} onClick={() => onSide && onSide('buy')}>
          Buy PRL
          <span className="muted mono" style={{ fontSize: 10.5, marginLeft: 8 }}>{8}</span>
        </div>
        <div className={`tab ${side === 'sell' ? 'active' : ''}`} onClick={() => onSide && onSide('sell')}>
          Sell PRL
          <span className="muted mono" style={{ fontSize: 10.5, marginLeft: 8 }}>3</span>
        </div>
        <div style={{ flex: 1, borderBottom: '1px solid var(--hairline)', alignSelf: 'flex-end' }} />
      </div>

      <div style={{ marginBottom: 14 }}>
        <FiltersBar pearlFundedOnly={pearlFundedOnly} />
      </div>
    </div>
  );
}

function OffersTable({ rows, takingId }) {
  const [expanded, setExpanded] = React.useState(null);
  return (
    <div style={{ padding: '0 28px 28px' }}>
      <div className="card" style={{ overflow: 'hidden' }}>
        <table className="tbl">
          <thead>
            <tr>
              <th style={{ width: 60 }}>Side</th>
              <th className="num" style={{ width: 160 }}>Size · PRL</th>
              <th className="num" style={{ width: 90 }}>Price</th>
              <th className="num" style={{ width: 140 }}>Total · USDC</th>
              <th style={{ width: 130 }}>Escrow status</th>
              <th style={{ width: 90 }}>Expires in</th>
              <th>Maker</th>
              <th style={{ width: 110, textAlign: 'right' }}>Action</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((o, i) => (
              <OfferRow
                key={o.id}
                o={o}
                expanded={expanded === o.id}
                onToggle={() => setExpanded(expanded === o.id ? null : o.id)}
                taking={takingId === o.id}
              />
            ))}
          </tbody>
        </table>
      </div>
      {rows.length > 0 && (
        <div className="muted" style={{ fontSize: 11.5, marginTop: 10, display: 'flex', justifyContent: 'space-between' }}>
          <span>{rows.length} offers · click a row to expand · click <span className="mono" style={{ color: 'var(--ink)' }}>Take</span> to route to <span className="mono" style={{ color: 'var(--ink)' }}>/quote/:id/accept</span></span>
          <span>updated <span className="mono" style={{ color: 'var(--ink)' }}>1s</span> ago</span>
        </div>
      )}
    </div>
  );
}

// ── Empty state ──────────────────────────────────────────────────────────────
function OffersEmpty() {
  return (
    <div style={{ padding: '60px 28px', textAlign: 'center' }}>
      <div className="card" style={{ padding: '64px 32px', maxWidth: 540, margin: '0 auto', background: 'var(--surface-2)' }}>
        <div style={{
          width: 56, height: 56, borderRadius: '50%',
          background: 'radial-gradient(circle at 35% 35%, #fff 0%, #ecebe1 35%, #cfcdb8 70%, #8b8973 100%)',
          margin: '0 auto 18px',
          boxShadow: 'inset 0 0 0 0.5px rgba(0,0,0,.12)',
        }} />
        <div className="h2" style={{ marginBottom: 6 }}>The board is empty.</div>
        <div className="muted" style={{ fontSize: 12.5, marginBottom: 22, lineHeight: 1.55, maxWidth: 380, margin: '0 auto 22px' }}>
          No one's posted a quote yet. Post yours and the first taker hits it within a 12-minute window.
        </div>
        <button className="btn accent">
          <svg width="10" height="10" viewBox="0 0 10 10"><path d="M5 1V9 M1 5H9" stroke="currentColor" strokeWidth="1.3" /></svg>
          Post the first quote
        </button>
        <div className="muted" style={{ fontSize: 11, marginTop: 16, fontFamily: 'var(--font-mono)' }}>
          or RFQ the desk at <a href="#" style={{ color: 'var(--accent)' }}>/quote</a>
        </div>
      </div>
    </div>
  );
}

// ── Variants ─────────────────────────────────────────────────────────────────

const OffersEmptyV = () => (
  <PageShell path="/offers">
    <OffersHeader side="buy" />
    <OffersEmpty />
  </PageShell>
);

const OffersMixedV = () => (
  <PageShell path="/offers">
    <OffersHeader side="buy" />
    <OffersTable rows={OFFERS_DATA} />
  </PageShell>
);

const OffersFundedOnlyV = () => (
  <PageShell path="/offers?escrow=funded">
    <OffersHeader side="buy" pearlFundedOnly={true} />
    <OffersTable rows={OFFERS_DATA.filter(o => o.funded)} />
  </PageShell>
);

const OffersTakingV = () => (
  <PageShell path="/offers">
    <OffersHeader side="buy" />
    <div style={{ padding: '0 28px 8px' }}>
      <div className="banner info" style={{ padding: '9px 14px', fontSize: 12 }}>
        <span className="ic"><span className="spin" /></span>
        <div className="body">
          <strong>Taking offer <span className="mono">qte_01J5K9XBHK2NRGV0</span></strong>
          <div className="lede">Locking quote terms · routing to <span className="mono">/quote/:id/accept</span>…</div>
        </div>
      </div>
    </div>
    <OffersTable
      rows={[TAKEN_OFFER, ...OFFERS_DATA.slice(1)]}
      takingId={TAKEN_OFFER.id}
    />
  </PageShell>
);

window.PageOffers = {
  variants: [
    { id: 'empty',          label: 'empty',                                          Page: OffersEmptyV,        height: 880 },
    { id: 'mixed',          label: 'populated · mixed (funded + unfunded)',          Page: OffersMixedV,        height: 1080 },
    { id: 'funded-only',    label: 'filtered: pearl-funded only',                    Page: OffersFundedOnlyV,   height: 880 },
    { id: 'taking',         label: 'one offer being taken',                          Page: OffersTakingV,       height: 1080 },
  ],
};
