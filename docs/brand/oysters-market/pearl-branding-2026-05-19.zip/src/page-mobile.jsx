// Mobile — one representative frame per customer-facing page.
// 390 × 844, iOS-ish viewport. Same components, single column.

function MobileChrome({ path }) {
  return (
    <>
      {/* status bar */}
      <div style={{
        height: 38, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '0 22px', fontSize: 14, fontWeight: 600, color: 'var(--ink)',
        background: 'var(--surface)',
      }}>
        <span className="mono" style={{ fontFamily: 'var(--font-sans)', fontWeight: 600 }}>9:41</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted)' }}>•••</span>
      </div>
      {/* address bar */}
      <div style={{
        padding: '4px 12px 8px',
        background: 'var(--surface)',
      }}>
        <div style={{
          height: 30, background: 'var(--paper-2)',
          borderRadius: 10, display: 'flex', alignItems: 'center',
          padding: '0 12px', fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted)',
        }}>
          <span>otc.pearl.dev<span style={{ color: 'var(--ink-2)' }}>{path}</span></span>
        </div>
      </div>
    </>
  );
}

function MobileNav() {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10,
      padding: '10px 14px', borderTop: '1px solid var(--hairline)', borderBottom: '1px solid var(--hairline)',
      background: 'var(--surface)',
    }}>
      <span style={{
        width: 16, height: 16, borderRadius: '50%',
        background: 'radial-gradient(circle at 35% 35%, #fff 0%, #ecebe1 30%, #cfcdb8 60%, #8b8973 100%)',
      }} />
      <span style={{ fontWeight: 600, fontSize: 13 }}>Pearl OTC</span>
      <span className="env-pill" style={{ fontSize: 9, padding: '1px 6px' }}>testnet</span>
      <div style={{ flex: 1 }} />
      <span className="muted" style={{ fontFamily: 'var(--font-mono)', fontSize: 10 }}>desk@</span>
    </div>
  );
}

// ── 1 — /quote on mobile ────────────────────────────────────────────────────

const MobileQuote = () => (
  <div className="pearl" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
    <MobileChrome path="/quote" />
    <MobileNav />
    <div style={{ flex: 1, overflow: 'auto', padding: '16px 14px 28px' }}>
      <div className="eyebrow" style={{ marginBottom: 4 }}>Request for quote</div>
      <h1 style={{ fontSize: 19, fontWeight: 600, letterSpacing: -0.4, margin: '0 0 16px' }}>Get a PRL ↔ USDC quote</h1>

      <div style={{ background: 'var(--surface)', border: '1px solid var(--hairline)', borderRadius: 'var(--r-3)' }}>
        <div className="tabs" style={{ padding: '0 12px' }}>
          <div className="tab active" style={{ fontSize: 12 }}>Buy PRL</div>
          <div className="tab" style={{ fontSize: 12 }}>Sell PRL</div>
        </div>
        <div style={{ padding: '16px 14px' }}>
          <div style={{ marginBottom: 12 }}>
            <label className="label">Amount in PRL</label>
            <input className="input mono" value="12,500.00000000" readOnly />
          </div>
          <div style={{ marginBottom: 12 }}>
            <label className="label">Buyer Pearl address</label>
            <input className="input mono" value="tprl1p…fkg7v" readOnly style={{ fontSize: 10.5 }} />
          </div>
          <div style={{ marginBottom: 14 }}>
            <label className="label">Refund Base address</label>
            <input className="input mono" value="0x7a4c…8a4E" readOnly style={{ fontSize: 10.5 }} />
          </div>
          <button className="btn accent lg" style={{ width: '100%', justifyContent: 'center' }}>
            Request quote
          </button>
        </div>
      </div>

      <div style={{ marginTop: 16 }}>
        <QuoteSummary />
      </div>
      <button className="btn accent lg" style={{ width: '100%', justifyContent: 'center', marginTop: 12 }}>
        Accept quote →
      </button>
    </div>
  </div>
);

// ── 2 — /trades/:id on mobile (stacked cards) ───────────────────────────────

const MobileTrade = () => (
  <div className="pearl" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
    <MobileChrome path={`/trades/${SAMPLE.tradeId.slice(0, 8)}…`} />
    <MobileNav />
    <div style={{ flex: 1, overflow: 'auto' }}>
      <div style={{ padding: '12px 14px 14px', background: 'var(--surface)', borderBottom: '1px solid var(--hairline)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10, flexWrap: 'wrap' }}>
          <span className="mono" style={{ fontSize: 11 }}>{SAMPLE.tradeId.slice(0, 18)}…</span>
          <StateBadge state="pearl_escrow_seen" />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
          <Countdown label="pearl_funding"  value="00:23:14" />
          <Countdown label="usdc_deposit"   value="00:19:47" />
          <Countdown label="settlement"     value="01:43:02" />
          <Countdown label="refund_avail"   value="01:13:44" />
        </div>
      </div>

      <div style={{ padding: '14px 12px 24px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <PearlCard status="seen" confirmations={3} />
        <BaseCard status="awaiting" />

        <div className="card">
          <div className="card-header"><span className="h2">Activity</span></div>
          <div style={{ padding: '4px 14px 10px' }}>
            <Timeline events={TL_EVENTS.pearl_seen.slice(0, 4)} />
          </div>
        </div>
      </div>
    </div>
  </div>
);

// ── 3 — /trades/:id/proof on mobile (collapses to single column) ────────────

const MobileProof = () => (
  <div className="pearl" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
    <MobileChrome path={`/…/proof`} />
    <div style={{ padding: '12px 14px 14px', background: 'var(--surface)', borderBottom: '1px solid var(--hairline)' }}>
      <div className="eyebrow" style={{ marginBottom: 4 }}>public proof</div>
      <h1 style={{ fontSize: 16, fontWeight: 600, margin: 0, lineHeight: 1.25 }}>Verifiable receipt</h1>
      <div className="mono" style={{ fontSize: 10.5, color: 'var(--muted)', marginTop: 4 }}>{SAMPLE.tradeId}</div>
      <div style={{ marginTop: 8 }}><StateBadge state="released" /></div>
    </div>
    <div style={{ flex: 1, overflow: 'auto', padding: '16px 14px 24px' }}>
      <div className="eyebrow" style={{ marginBottom: 8 }}>01 · quote terms</div>
      <dl className="kv" style={{ gridTemplateColumns: '110px 1fr', fontSize: 11, marginBottom: 18 }}>
        <dt>side</dt><dd>BUY</dd>
        <dt>amount PRL</dt><dd className="mono">12,500.00000000</dd>
        <dt>amount USDC</dt><dd className="mono">8,237.500000</dd>
        <dt>price</dt><dd className="mono">0.659000</dd>
      </dl>
      <div className="eyebrow" style={{ marginBottom: 8 }}>02 · pearl leg</div>
      <dl className="kv" style={{ gridTemplateColumns: '110px 1fr', fontSize: 11, marginBottom: 18 }}>
        <dt>network</dt><dd>testnet2</dd>
        <dt>funding tx</dt>
        <dd className="mono" style={{ color: 'var(--accent)', fontSize: 10.5 }}>f3c1a9…f1a2 ↗</dd>
        <dt>release tx</dt>
        <dd className="mono" style={{ color: 'var(--accent)', fontSize: 10.5 }}>a7b8c9…a7b8 ↗</dd>
      </dl>
      <div className="eyebrow" style={{ marginBottom: 8 }}>03 · base leg</div>
      <dl className="kv" style={{ gridTemplateColumns: '110px 1fr', fontSize: 11 }}>
        <dt>network</dt><dd>sepolia</dd>
        <dt>deposit tx</dt>
        <dd className="mono" style={{ color: 'var(--accent)', fontSize: 10.5 }}>0xc4d5…c4d5 ↗</dd>
        <dt>release tx</dt>
        <dd className="mono" style={{ color: 'var(--accent)', fontSize: 10.5 }}>0xa1b2…a1b2 ↗</dd>
      </dl>
    </div>
  </div>
);

// ── 4 — /trades/:id failure-state on mobile (banner-dominant) ───────────────

const MobileFailure = () => (
  <div className="pearl" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
    <MobileChrome path={`/trades/${SAMPLE.tradeId.slice(0, 8)}…`} />
    <MobileNav />
    <div style={{ flex: 1, overflow: 'auto' }}>
      <div style={{ padding: '12px 14px', background: 'var(--surface)', borderBottom: '1px solid var(--hairline)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10, flexWrap: 'wrap' }}>
          <span className="mono" style={{ fontSize: 11 }}>{SAMPLE.tradeId.slice(0, 18)}…</span>
          <StateBadge state="late_prl_funding" />
        </div>
      </div>
      <div style={{ padding: '14px 12px 24px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <FailureBanner state="late_prl_funding" />
        <PearlCard status="late" />
        <BaseCard status="closed" />
        <div className="card">
          <div className="card-header"><span className="h2">Activity</span></div>
          <div style={{ padding: '4px 14px 10px' }}>
            <Timeline events={TL_EVENTS.failure_generic.slice(0, 4)} />
          </div>
        </div>
      </div>
    </div>
  </div>
);

window.PageMobile = {
  variants: [
    { id: 'quote',   label: '/quote · returned',                    Page: MobileQuote },
    { id: 'trade',   label: '/trades/:id · pearl_escrow_seen',      Page: MobileTrade },
    { id: 'proof',   label: '/trades/:id/proof · released',         Page: MobileProof },
    { id: 'failure', label: '/trades/:id · late_prl_funding',       Page: MobileFailure },
  ],
};
