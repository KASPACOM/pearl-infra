// /quote/:id/accept — confirm and accept
// Variants: buyer (seller fields hidden) · seller (?role=seller) · admin · expired · in-flight

function AcceptForm({ role = 'buyer', expired = false, submitting = false }) {
  return (
    <div style={{ background: 'var(--surface)', border: '1px solid var(--hairline)', borderRadius: 'var(--r-3)' }}>
      <div className="card-header">
        <span className="h2">Confirm details</span>
        <span className="muted" style={{ fontSize: 11 }}>quote <span className="mono">qte_01J5K8AB2</span></span>
      </div>
      <div style={{ padding: '20px 22px' }}>

        {role === 'admin' && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: 10,
            padding: '8px 12px', marginBottom: 18,
            background: 'var(--accent-soft)',
            border: '1px solid var(--accent-line)',
            borderRadius: 'var(--r-2)',
            fontSize: 11.5, color: 'var(--accent-ink)',
          }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11 }}>admin override</span>
            <span style={{ flex: 1 }}>All four addresses are editable. Use <a href="#">Fill from defaults →</a> to seed seller fields from the desk preset.</span>
          </div>
        )}

        <div className="eyebrow" style={{ marginBottom: 10 }}>Buyer · counterparty receiving PRL</div>

        <div style={{ marginBottom: 14 }}>
          <label className="label">Buyer Pearl address <span className="req">*</span></label>
          <input className="input mono" value={SAMPLE.buyerPearl} readOnly />
          <div className="help">Pre-filled from quote · editable</div>
        </div>

        <div style={{ marginBottom: 14 }}>
          <label className="label">Buyer USDC address <span className="req">*</span></label>
          <div style={{ position: 'relative' }}>
            <input className="input mono" value={SAMPLE.buyerBase} readOnly style={{ paddingRight: 130 }} />
            <span className="pill ok" style={{ position: 'absolute', right: 8, top: 6 }}>
              <span className="dot" /> auto-filled · MetaMask
            </span>
          </div>
          <div className="help">Auto-filled from connected EVM wallet · editable</div>
        </div>

        {(role === 'seller' || role === 'admin') && (
          <>
            <div className="eyebrow" style={{ marginTop: 22, marginBottom: 10, color: role === 'admin' ? 'var(--accent)' : 'var(--muted-2)' }}>
              Seller · counterparty receiving USDC {role === 'seller' && <span className="muted" style={{ textTransform: 'none', letterSpacing: 0, marginLeft: 6 }}>visible because <span className="mono">?role=seller</span></span>}
            </div>
            <div style={{ marginBottom: 14 }}>
              <label className="label">Seller Pearl refund address <span className="req">*</span></label>
              <input className="input mono" value={role === 'admin' ? SAMPLE.pearlAddr : ''} placeholder="tprl1p…" readOnly />
              <div className="help">PRL is returned here if the trade refunds.</div>
            </div>
            <div style={{ marginBottom: 14 }}>
              <label className="label">Seller USDC receive address <span className="req">*</span></label>
              <input className="input mono" value={role === 'admin' ? SAMPLE.baseReceive : ''} placeholder="0x…" readOnly />
              <div className="help">Where the buyer's USDC is sent on release.</div>
            </div>
          </>
        )}

        {role === 'buyer' && (
          <div style={{
            marginTop: 18, padding: '10px 12px',
            background: 'var(--paper-2)',
            border: '1px solid var(--hairline)',
            borderRadius: 'var(--r-2)',
            fontSize: 11.5, color: 'var(--muted)', lineHeight: 1.55,
          }}>
            Seller addresses are filled by the desk; you will see them on the trade's public proof page after settlement.
          </div>
        )}

        <div style={{ marginTop: 22, display: 'flex', gap: 10 }}>
          {expired ? (
            <button className="btn lg primary" disabled style={{ flex: 1, justifyContent: 'center' }}>
              Quote expired — request a new one
            </button>
          ) : submitting ? (
            <button className="btn lg primary" disabled style={{ flex: 1, justifyContent: 'center' }}>
              <span className="spin" /> Allocating escrows…
            </button>
          ) : (
            <button className="btn lg accent" style={{ flex: 1, justifyContent: 'center' }}>
              Accept and continue →
            </button>
          )}
          <button className="btn lg ghost" disabled={submitting}>Back</button>
        </div>

        <div style={{ marginTop: 12, fontSize: 11, color: 'var(--muted)', lineHeight: 1.5 }}>
          By accepting you authorize the desk to allocate escrow addresses on both chains.
          Funding is your responsibility; releases are server-driven.
        </div>
      </div>
    </div>
  );
}

function PageAcceptBase({ role = 'buyer', expired = false, submitting = false }) {
  return (
    <PageShell path={`/quote/qte_01J5K8AB2/accept${role !== 'buyer' ? `?role=${role}` : ''}`}>
      <div style={{ height: '100%', overflow: 'auto', padding: '32px 56px 60px' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 22 }}>
          <div>
            <div className="eyebrow" style={{ marginBottom: 6 }}>
              accept quote · {role === 'admin' ? 'admin view' : role === 'seller' ? 'seller view' : 'buyer view'}
            </div>
            <h1 className="h1">Confirm and accept this quote</h1>
          </div>
          <div className="muted" style={{ fontSize: 12, display: 'flex', alignItems: 'center', gap: 8 }}>
            <ClockIcon />
            {expired ? (
              <>quote expired at <span className="mono" style={{ color: 'var(--neutral)' }}>14:22:26 UTC</span></>
            ) : (
              <>expires in <span className="mono" style={{ color: 'var(--warn)' }}>00:38</span></>
            )}
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 440px', gap: 28, alignItems: 'start' }}>
          <AcceptForm role={role} expired={expired} submitting={submitting} />
          <QuoteSummary expired={expired} />
        </div>
      </div>
    </PageShell>
  );
}

const AcceptBuyer    = () => <PageAcceptBase role="buyer" />;
const AcceptSeller   = () => <PageAcceptBase role="seller" />;
const AcceptAdmin    = () => <PageAcceptBase role="admin" />;
const AcceptExpired  = () => <PageAcceptBase role="buyer" expired />;
const AcceptInFlight = () => <PageAcceptBase role="buyer" submitting />;

window.PageAccept = {
  variants: [
    { id: 'buyer',      label: 'buyer view (seller fields hidden)', Page: AcceptBuyer },
    { id: 'seller',     label: 'seller view · ?role=seller',         Page: AcceptSeller },
    { id: 'admin',      label: 'admin view · all fields editable',   Page: AcceptAdmin },
    { id: 'expired',    label: 'quote expired during fill',          Page: AcceptExpired },
    { id: 'inflight',   label: 'submit in flight',                   Page: AcceptInFlight },
  ],
};
