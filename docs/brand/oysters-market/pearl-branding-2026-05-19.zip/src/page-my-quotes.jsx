// /my-quotes — personal dashboard for makers + RFQ posters.
// Sections: stat tiles · Waiting for counterparty · In flight.
// Variants: empty · all waiting · mixed · one just taken.

const WAITING_ROWS = [
  { id: "qte_01J5K9XBHK2NRGV0", side: "sell", size: "12,500.00000000", price: "0.659000", total: "8,237.500000", funded: true,  expires: "12m 30s", views: 47, takes: 0 },
  { id: "qte_01J5K9V2D7M3PKAE", side: "sell", size: "5,000.00000000",  price: "0.658500", total: "3,292.500000", funded: false, expires: "08m 14s", views: 23, takes: 0 },
  { id: "qte_01J5K9SDC4XL8PMR", side: "buy",  size: "1,000.00000000",  price: "0.660200", total: "660.200000",   funded: true,  expires: "01m 47s", views: 84, takes: 0, near: true },
  { id: "qte_01J5K9P3M7TFXKAB", side: "sell", size: "3,750.00000000",  price: "0.659200", total: "2,472.000000", funded: true,  expires: "14m 09s", views: 19, takes: 0 },
];

const INFLIGHT_ROWS = [
  { id: "trd_01J5K8B2QHXV9P3Y", state: "pearl_escrow_pending", counterparty: "tkr_8d72…f04a", size: "12,500.00000000 PRL", inState: "3m 12s",  why: "Awaiting USDC deposit" },
  { id: "trd_01J5K7Z1M4NTBHGX", state: "release_pending",      counterparty: "tkr_a04b…1e9d", size: "3,000.00000000 PRL",  inState: "0m 47s",  why: "Releases broadcasting" },
  { id: "trd_01J5K7XKE3RMS4DA", state: "pearl_escrow_seen",    counterparty: "tkr_c91e…b73f", size: "45,200.00000000 PRL", inState: "1m 04s",  why: "3 / 6 confirmations" },
];

// ── Stat tiles ───────────────────────────────────────────────────────────────
function StatTile({ label, value, delta, mono = true }) {
  return (
    <div className="card card-pad" style={{ padding: '14px 16px', flex: 1, minWidth: 180 }}>
      <div className="eyebrow" style={{ marginBottom: 8 }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
        <span style={{
          fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
          fontSize: 26, fontWeight: 500, letterSpacing: '-0.5px',
          fontVariantNumeric: 'tabular-nums',
        }}>
          {value}
        </span>
        {delta && (
          <span className={`mono`} style={{ fontSize: 11, color: delta.startsWith('+') ? 'var(--ok)' : 'var(--muted)' }}>
            {delta}
          </span>
        )}
      </div>
    </div>
  );
}

// ── Waiting table row ────────────────────────────────────────────────────────
function WaitingRow({ q, highlighted, justTaken }) {
  return (
    <tr style={{ background: highlighted ? 'var(--ok-soft)' : (justTaken ? 'var(--accent-soft)' : undefined) }}>
      <td>
        <span className={`badge ${q.side === 'buy' ? 'ok' : 'err'}`} style={{
          fontSize: 9.5, padding: '2px 7px',
          background: q.side === 'buy' ? 'var(--ok-soft)' : '#f6e4e0',
          color: q.side === 'buy' ? 'var(--ok)' : '#a43a2c',
          borderColor: q.side === 'buy' ? 'var(--ok-line)' : '#e6c4b8'
        }}>
          {q.side.toUpperCase()}
        </span>
      </td>
      <td className="num">
        <span className="mono">
          {q.size.split('.')[0]}<span style={{ color: 'var(--muted)' }}>.{q.size.split('.')[1]}</span>
        </span>
      </td>
      <td className="num"><span className="mono">{q.price}</span></td>
      <td className="num">
        <span className="mono">
          {q.total.split('.')[0]}<span style={{ color: 'var(--muted)' }}>.{q.total.split('.')[1]}</span>
        </span>
      </td>
      <td>
        {q.funded ? (
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <span style={{
              width: 8, height: 8, borderRadius: 50, background: 'var(--ok)',
              boxShadow: '0 0 0 3px var(--ok-soft)'
            }} />
            <span style={{ color: 'var(--ok)', fontWeight: 500, fontSize: 11.5 }}>Pearl funded</span>
          </span>
        ) : (
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 8, height: 8, borderRadius: 50, background: 'var(--muted-2)' }} />
            <span style={{ color: 'var(--muted)', fontSize: 11.5 }}>Unfunded</span>
            <a href="#" style={{ color: 'var(--accent)', fontSize: 11, marginLeft: 4 }}>Fund now →</a>
          </span>
        )}
      </td>
      <td>
        <span className="mono" style={{ fontSize: 11.5, color: q.near ? 'var(--warn)' : 'var(--ink)' }}>
          {q.expires}
        </span>
      </td>
      <td>
        <span style={{ fontSize: 11.5 }}>
          <span className="mono">{q.views}</span> <span className="muted">seen</span>
          <span className="muted" style={{ margin: '0 6px' }}>·</span>
          <span className="mono" style={{ color: q.takes > 0 ? 'var(--ok)' : 'var(--muted)' }}>
            {q.takes} {q.takes === 1 ? 'taker' : 'takers'}
          </span>
        </span>
      </td>
      <td style={{ textAlign: 'right' }}>
        <span className="muted" style={{ cursor: 'pointer', display: 'inline-flex', gap: 3, padding: '4px 8px' }}>
          <span style={{ width: 3, height: 3, borderRadius: 50, background: 'currentColor' }} />
          <span style={{ width: 3, height: 3, borderRadius: 50, background: 'currentColor' }} />
          <span style={{ width: 3, height: 3, borderRadius: 50, background: 'currentColor' }} />
        </span>
      </td>
    </tr>
  );
}

// ── In-flight row (links to /trades/:id) ─────────────────────────────────────
function InflightRow({ t }) {
  return (
    <tr style={{ cursor: 'pointer' }}>
      <td>
        <span className="mono" style={{ fontSize: 11.5, color: 'var(--accent)', display: 'inline-flex', alignItems: 'center', gap: 5 }}>
          {t.id}
          <span style={{ color: 'var(--muted-2)' }}>↗</span>
        </span>
      </td>
      <td><StateBadge state={t.state} /></td>
      <td><span className="mono" style={{ fontSize: 11, color: 'var(--muted)' }}>{t.counterparty}</span></td>
      <td className="num"><span className="mono">{t.size}</span></td>
      <td>
        <span style={{ fontSize: 11.5 }}>{t.why}</span>
        <span className="muted" style={{ marginLeft: 6, fontSize: 11 }}>·</span>
        <span className="mono" style={{ marginLeft: 6, fontSize: 11, color: 'var(--ink-2)' }}>{t.inState}</span>
      </td>
    </tr>
  );
}

// ── Header ───────────────────────────────────────────────────────────────────
function MyQuotesHeader({ openCount = 4, inflightCount = 3, notional = "112,400" }) {
  return (
    <div style={{ padding: '20px 28px 0' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 18 }}>
        <div>
          <div className="eyebrow" style={{ marginBottom: 4 }}>my desk</div>
          <div className="h1">My quotes</div>
          <div className="muted" style={{ fontSize: 12, marginTop: 4 }}>
            Quotes you've posted and trades you're settling. Counterparties never see your address — only the maker handle.
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn">Export CSV</button>
          <button className="btn accent">
            <svg width="10" height="10" viewBox="0 0 10 10"><path d="M5 1V9 M1 5H9" stroke="currentColor" strokeWidth="1.3" /></svg>
            Post a quote
          </button>
        </div>
      </div>

      {/* Stat tiles */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 28 }}>
        <StatTile label="open quotes" value={openCount} delta="+1 vs. yesterday" mono={false} />
        <StatTile label="in settlement" value={inflightCount} delta="updated 4s ago" mono={false} />
        <StatTile label="notional posted · 24h" value={notional} delta="USDC" />
        <StatTile label="median time-to-fill" value="04:11" delta="−12% week" />
      </div>
    </div>
  );
}

// ── Sections ─────────────────────────────────────────────────────────────────
function WaitingSection({ rows, highlightTopRow = false }) {
  return (
    <div style={{ padding: '0 28px 24px' }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 10 }}>
        <div>
          <span className="h2">Waiting for a counterparty</span>
          <span className="muted mono" style={{ fontSize: 11, marginLeft: 8 }}>{rows.length}</span>
        </div>
        <span className="muted" style={{ fontSize: 11.5 }}>
          posted by <span className="mono" style={{ color: 'var(--ink)' }}>mkr_4f8a…b21c</span> · <a href="#" style={{ color: 'var(--accent)' }}>change handle</a>
        </span>
      </div>
      <div className="card" style={{ overflow: 'hidden' }}>
        <table className="tbl">
          <thead>
            <tr>
              <th style={{ width: 60 }}>Side</th>
              <th className="num" style={{ width: 160 }}>Size · PRL</th>
              <th className="num" style={{ width: 90 }}>Price</th>
              <th className="num" style={{ width: 140 }}>Total · USDC</th>
              <th style={{ width: 180 }}>Escrow status</th>
              <th style={{ width: 90 }}>Expires in</th>
              <th>Engagement</th>
              <th style={{ width: 60 }}></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((q, i) => (
              <WaitingRow key={q.id} q={q} highlighted={highlightTopRow && i === 0} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function InflightSection({ rows, highlightTopRow = false }) {
  return (
    <div style={{ padding: '0 28px 28px' }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 10 }}>
        <div>
          <span className="h2">In flight</span>
          <span className="muted mono" style={{ fontSize: 11, marginLeft: 8 }}>{rows.length}</span>
        </div>
        <span className="muted" style={{ fontSize: 11.5 }}>
          mid-settlement · click any row to open <span className="mono" style={{ color: 'var(--ink)' }}>/trades/:id</span>
        </span>
      </div>
      <div className="card" style={{ overflow: 'hidden' }}>
        <table className="tbl">
          <thead>
            <tr>
              <th style={{ width: 220 }}>Trade ID</th>
              <th style={{ width: 200 }}>State</th>
              <th style={{ width: 170 }}>Counterparty</th>
              <th className="num" style={{ width: 200 }}>Size</th>
              <th>Time in state</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((t, i) => (
              <InflightRow key={t.id} t={t} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Empty state ──────────────────────────────────────────────────────────────
function MyQuotesEmpty() {
  return (
    <div style={{ padding: '20px 28px 0' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 28 }}>
        <div>
          <div className="eyebrow" style={{ marginBottom: 4 }}>my desk</div>
          <div className="h1">My quotes</div>
        </div>
      </div>
      <div className="card" style={{ padding: '64px 32px', textAlign: 'center', background: 'var(--surface-2)', maxWidth: 600, margin: '40px auto' }}>
        <div style={{
          width: 56, height: 56, borderRadius: '50%',
          background: 'radial-gradient(circle at 35% 35%, #fff 0%, #ecebe1 35%, #cfcdb8 70%, #8b8973 100%)',
          margin: '0 auto 18px',
          boxShadow: 'inset 0 0 0 0.5px rgba(0,0,0,.12)',
        }} />
        <div className="h2" style={{ marginBottom: 6 }}>You haven't posted yet.</div>
        <div className="muted" style={{ fontSize: 12.5, marginBottom: 22, lineHeight: 1.55, maxWidth: 380, margin: '0 auto 22px' }}>
          Your open quotes and mid-settlement trades will show up here. Post a quote to the open board, or request one from the desk.
        </div>
        <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
          <button className="btn accent">
            <svg width="10" height="10" viewBox="0 0 10 10"><path d="M5 1V9 M1 5H9" stroke="currentColor" strokeWidth="1.3" /></svg>
            Post a quote
          </button>
          <button className="btn">RFQ the desk →</button>
        </div>
      </div>
    </div>
  );
}

// ── Just-taken toast ─────────────────────────────────────────────────────────
function JustTakenToast() {
  return (
    <div style={{ padding: '0 28px', marginBottom: 14 }}>
      <div className="banner info" style={{
        background: 'var(--ok-soft)', borderColor: 'var(--ok-line)', color: 'var(--ok)',
        padding: '11px 14px', fontSize: 12.5
      }}>
        <span className="ic" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--font-mono)', fontWeight: 600 }}>✓</span>
        <div className="body">
          <strong>Your quote <span className="mono">qte_01J5K9V2D7M3PKAE</span> just got taken.</strong>
          <div className="lede" style={{ color: 'var(--ok)', opacity: .8 }}>
            Settlement started 4s ago. <a href="#" style={{ color: 'inherit' }}>Open <span className="mono">trd_01J5KAB7D8FXKL01</span> →</a>
          </div>
        </div>
        <span className="muted" style={{ cursor: 'pointer', fontSize: 14, color: 'var(--ok)', alignSelf: 'center' }}>✕</span>
      </div>
    </div>
  );
}

// ── Variants ─────────────────────────────────────────────────────────────────
const MyQuotesEmptyV = () => (
  <PageShell path="/my-quotes">
    <MyQuotesEmpty />
  </PageShell>
);

const MyQuotesAllWaitingV = () => (
  <PageShell path="/my-quotes">
    <MyQuotesHeader openCount={WAITING_ROWS.length} inflightCount={0} notional="42,662" />
    <WaitingSection rows={WAITING_ROWS} />
  </PageShell>
);

const MyQuotesMixedV = () => (
  <PageShell path="/my-quotes">
    <MyQuotesHeader openCount={WAITING_ROWS.length} inflightCount={INFLIGHT_ROWS.length} />
    <WaitingSection rows={WAITING_ROWS} />
    <InflightSection rows={INFLIGHT_ROWS} />
  </PageShell>
);

const MyQuotesJustTakenV = () => {
  const newInflight = [
    { id: "trd_01J5KAB7D8FXKL01", state: "pearl_escrow_pending", counterparty: "tkr_2f8e…91ca", size: "5,000.00000000 PRL", inState: "4s", why: "Awaiting funding" },
    ...INFLIGHT_ROWS,
  ];
  // remove the just-taken row from waiting (qte_01J5K9V2D7M3PKAE)
  const remainingWaiting = WAITING_ROWS.filter(q => q.id !== 'qte_01J5K9V2D7M3PKAE');
  return (
    <PageShell path="/my-quotes">
      <MyQuotesHeader openCount={remainingWaiting.length} inflightCount={newInflight.length} />
      <JustTakenToast />
      <WaitingSection rows={remainingWaiting} />
      <InflightSection rows={newInflight} highlightTopRow />
    </PageShell>
  );
};

window.PageMyQuotes = {
  variants: [
    { id: 'empty',       label: 'empty · no quotes posted yet',               Page: MyQuotesEmptyV,       height: 720 },
    { id: 'all-waiting', label: 'populated · all waiting for a counterparty', Page: MyQuotesAllWaitingV,  height: 740 },
    { id: 'mixed',       label: 'mixed · waiting + in-flight',                Page: MyQuotesMixedV,       height: 980 },
    { id: 'just-taken',  label: 'one quote just got taken (toast)',           Page: MyQuotesJustTakenV,   height: 1040 },
  ],
};
