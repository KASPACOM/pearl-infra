// /quote — Request For Quote
// Variants: empty · validated · invalid · loading · returned · expired-before-accept

function QuoteForm({ values = {}, errors = {}, loading = false, submitted = false }) {
  const v = {
    side: 'buy', amount: '', pearlAddr: '', refundAddr: '',
    ...values,
  };
  return (
    <div style={{ background: 'var(--surface)', border: '1px solid var(--hairline)', borderRadius: 'var(--r-3)' }}>
      {/* Buy/Sell tabs */}
      <div className="tabs" style={{ padding: '0 18px' }}>
        <div className={`tab ${v.side === 'buy' ? 'active' : ''}`}>Buy PRL</div>
        <div className={`tab ${v.side === 'sell' ? 'active' : ''}`}>Sell PRL</div>
      </div>

      <div style={{ padding: '22px 24px' }}>
        <div style={{ marginBottom: 16 }}>
          <label className="label">Amount in PRL <span className="req">*</span></label>
          <div style={{ position: 'relative' }}>
            <input
              className={`input mono ${errors.amount ? 'error' : ''}`}
              value={v.amount}
              placeholder="0.00000000"
              readOnly
              style={{ paddingRight: 50 }}
            />
            <span className="mono" style={{
              position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)',
              fontSize: 11, color: 'var(--muted)', pointerEvents: 'none',
            }}>PRL</span>
          </div>
          {errors.amount
            ? <div className="help err">{errors.amount}</div>
            : <div className="help">8-decimal precision · minimum 100.00000000 PRL · maximum 2,000,000.00000000 PRL</div>}
        </div>

        <div style={{ marginBottom: 16 }}>
          <label className="label">Buyer Pearl address <span className="req">*</span></label>
          <input
            className={`input mono ${errors.pearlAddr ? 'error' : ''}`}
            value={v.pearlAddr}
            placeholder="tprl1p…"
            readOnly
          />
          {errors.pearlAddr
            ? <div className="help err">{errors.pearlAddr}</div>
            : <div className="help">bech32m, network <span className="mono">testnet2</span> (HRP <span className="mono">tprl</span>)</div>}
        </div>

        <div style={{ marginBottom: 18 }}>
          <label className="label">Refund Base address <span className="req">*</span></label>
          <input
            className={`input mono ${errors.refundAddr ? 'error' : ''}`}
            value={v.refundAddr}
            placeholder="0x…"
            readOnly
          />
          {errors.refundAddr
            ? <div className="help err">{errors.refundAddr}</div>
            : <div className="help">EVM hex · used only if the trade is refunded</div>}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 20 }}>
          <div>
            <label className="label">Settlement asset</label>
            <div className="input locked mono" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span>USDC</span>
              <span style={{ fontSize: 10, color: 'var(--muted-2)' }}>LOCKED</span>
            </div>
          </div>
          <div>
            <label className="label">Settlement network</label>
            <div className="input locked mono" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span>Base · sepolia</span>
              <span style={{ fontSize: 10, color: 'var(--muted-2)' }}>LOCKED</span>
            </div>
          </div>
        </div>

        <button
          className={`btn lg ${submitted || loading ? 'primary' : 'accent'}`}
          disabled={loading}
          style={{ width: '100%', justifyContent: 'center' }}>
          {loading ? <><span className="spin" />Requesting quote…</> : 'Request quote'}
        </button>

        <div style={{
          marginTop: 14, padding: '10px 12px',
          background: 'var(--surface-2)', border: '1px solid var(--hairline)', borderRadius: 'var(--r-2)',
          display: 'flex', gap: 10, alignItems: 'flex-start',
        }}>
          <span style={{ color: 'var(--muted-2)', fontSize: 12 }}>ⓘ</span>
          <div style={{ fontSize: 11.5, color: 'var(--muted)', lineHeight: 1.5 }}>
            Quotes are valid for 60 seconds after issue. The desk fills <span className="mono">sellerPearlRefund</span> and <span className="mono">sellerUsdcReceive</span> automatically; you'll only ever see them on the proof page.
          </div>
        </div>
      </div>
    </div>
  );
}

function QuoteResultCard({ expired = false }) {
  return (
    <>
      <QuoteSummary expired={expired} />
      <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
        {expired ? (
          <button className="btn primary" style={{ flex: 1, justifyContent: 'center' }}>
            Quote expired — request a new one
          </button>
        ) : (
          <>
            <button className="btn accent lg" style={{ flex: 1, justifyContent: 'center' }}>
              Accept quote →
            </button>
            <button className="btn ghost lg" style={{ justifyContent: 'center' }}>
              Cancel
            </button>
          </>
        )}
      </div>

      <div style={{ marginTop: 18, fontSize: 11, color: 'var(--muted)', lineHeight: 1.55 }}>
        Accepting allocates an escrow address on each chain. You commit to funding the
        Base leg within the deposit window shown on the next screen. Releases are
        server-driven and irreversible.
      </div>
    </>
  );
}

function PageBase({ children, leftAnnot, rightAnnot, path = "/quote", env = "testnet" }) {
  return (
    <PageShell path={path} env={env}>
      <div style={{ height: '100%', overflow: 'auto', padding: '32px 56px 60px' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 20 }}>
          <div>
            <div className="eyebrow" style={{ marginBottom: 6 }}>Request for quote</div>
            <h1 className="h1">Get a PRL ↔ USDC quote</h1>
          </div>
          <div className="muted" style={{ fontSize: 12 }}>
            indicative pricing · valid 60s after issue
          </div>
        </div>
        {children}
      </div>
      {leftAnnot}
      {rightAnnot}
    </PageShell>
  );
}

// ── Variants ────────────────────────────────────────────────────────────────

function QuoteEmpty() {
  return (
    <PageBase>
      <div style={{ display: 'grid', gridTemplateColumns: '520px 1fr', gap: 28, alignItems: 'start' }}>
        <QuoteForm />
        <div style={{
          background: 'var(--paper-2)',
          border: '1px dashed var(--hairline)',
          borderRadius: 'var(--r-3)',
          padding: '40px 28px',
          color: 'var(--muted)',
          fontSize: 12.5,
          lineHeight: 1.55,
          minHeight: 360,
        }}>
          <div className="eyebrow" style={{ marginBottom: 10 }}>Quote</div>
          <div style={{ color: 'var(--muted-2)', fontSize: 12 }}>
            Fill out the form on the left and request a quote. The desk will return
            an indicative price along with a 60-second window to accept.
          </div>
        </div>
      </div>
    </PageBase>
  );
}

function QuoteValidated() {
  return (
    <PageBase
      rightAnnot={<Annot top={210} left={530} arrow="tl-arrow">Form is valid, but the Quote panel only populates after submit — the user still has to click <strong>Request quote</strong>.</Annot>}>
      <div style={{ display: 'grid', gridTemplateColumns: '520px 1fr', gap: 28, alignItems: 'start' }}>
        <QuoteForm values={{
          amount: '12,500.00000000',
          pearlAddr: SAMPLE.buyerPearl,
          refundAddr: SAMPLE.buyerBase,
        }} />
        <div style={{
          background: 'var(--paper-2)',
          border: '1px dashed var(--hairline)',
          borderRadius: 'var(--r-3)',
          padding: '40px 28px',
          color: 'var(--muted)',
          fontSize: 12.5,
          minHeight: 360,
        }}>
          <div className="eyebrow" style={{ marginBottom: 10 }}>Quote</div>
          <div style={{ color: 'var(--muted-2)' }}>Awaiting quote — click <span style={{ color: 'var(--ink)', fontWeight: 500 }}>Request quote</span>.</div>
        </div>
      </div>
    </PageBase>
  );
}

function QuoteInvalid() {
  return (
    <PageBase>
      <div style={{ display: 'grid', gridTemplateColumns: '520px 1fr', gap: 28, alignItems: 'start' }}>
        <QuoteForm
          values={{
            amount: '12.5',
            pearlAddr: 'prl1pBADHRPxxx',
            refundAddr: '0x7a4',
          }}
          errors={{
            amount: 'Amount must be at least 100.00000000 PRL.',
            pearlAddr: 'Address HRP "prl1" is mainnet, but this environment is testnet2. Expected "tprl1…".',
            refundAddr: 'Address is not a valid 42-char hex.',
          }}
        />
        <div style={{
          background: 'var(--err-soft)',
          border: '1px solid var(--err-line)',
          borderRadius: 'var(--r-3)',
          padding: '18px 20px',
          minHeight: 360,
        }}>
          <div className="eyebrow" style={{ color: 'var(--err)', marginBottom: 10 }}>3 issues to resolve</div>
          <ul style={{ margin: 0, paddingLeft: 0, listStyle: 'none', fontSize: 12.5, color: 'var(--err)', lineHeight: 1.7 }}>
            <li style={{ display: 'flex', gap: 8 }}><span className="mono" style={{ color: 'var(--err)' }}>·</span> Amount below minimum (100 PRL)</li>
            <li style={{ display: 'flex', gap: 8 }}><span className="mono" style={{ color: 'var(--err)' }}>·</span> Pearl address HRP doesn't match environment</li>
            <li style={{ display: 'flex', gap: 8 }}><span className="mono" style={{ color: 'var(--err)' }}>·</span> Refund Base address malformed</li>
          </ul>
          <div style={{ marginTop: 14, paddingTop: 14, borderTop: '1px solid var(--err-line)', fontSize: 11.5, color: 'var(--err)', opacity: 0.85 }}>
            Validation runs client-side as you type. The desk re-validates on submit; address checks include checksums for both chains.
          </div>
        </div>
      </div>
    </PageBase>
  );
}

function QuoteLoading() {
  return (
    <PageBase>
      <div style={{ display: 'grid', gridTemplateColumns: '520px 1fr', gap: 28, alignItems: 'start' }}>
        <QuoteForm
          values={{
            amount: '12,500.00000000',
            pearlAddr: SAMPLE.buyerPearl,
            refundAddr: SAMPLE.buyerBase,
          }}
          loading
        />
        <div style={{ background: 'var(--surface-2)', border: '1px solid var(--hairline)', borderRadius: 'var(--r-3)', padding: '18px 20px', minHeight: 360 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <span className="h2">Quote</span>
            <span className="muted" style={{ fontSize: 11, display: 'flex', alignItems: 'center', gap: 6 }}>
              <span className="spin" /> requesting…
            </span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, marginBottom: 18 }}>
            <div>
              <div className="eyebrow" style={{ marginBottom: 6 }}>you receive</div>
              <div className="skel" style={{ height: 30, width: '85%' }} />
            </div>
            <div>
              <div className="eyebrow" style={{ marginBottom: 6 }}>you pay</div>
              <div className="skel" style={{ height: 30, width: '85%' }} />
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', gap: '10px 18px' }}>
            {['price', 'fee (PRL)', 'fee (USDC)', 'settlement'].map(l => (
              <React.Fragment key={l}>
                <div className="muted" style={{ fontSize: 12 }}>{l}</div>
                <div className="skel" style={{ height: 14, width: '60%' }} />
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>
    </PageBase>
  );
}

function QuoteReturned() {
  return (
    <PageBase>
      <div style={{ display: 'grid', gridTemplateColumns: '520px 1fr', gap: 28, alignItems: 'start' }}>
        <QuoteForm
          values={{
            amount: '12,500.00000000',
            pearlAddr: SAMPLE.buyerPearl,
            refundAddr: SAMPLE.buyerBase,
          }}
          submitted
        />
        <div>
          <QuoteResultCard />
        </div>
      </div>
    </PageBase>
  );
}

function QuoteExpired() {
  return (
    <PageBase>
      <div style={{ display: 'grid', gridTemplateColumns: '520px 1fr', gap: 28, alignItems: 'start' }}>
        <QuoteForm
          values={{
            amount: '12,500.00000000',
            pearlAddr: SAMPLE.buyerPearl,
            refundAddr: SAMPLE.buyerBase,
          }}
          submitted
        />
        <div>
          <Banner tone="neutral" title="Quote expired before accept." body="Quote qte_01J5K8AB2 was issued at 14:21:26 UTC; window closed at 14:22:26 UTC." action={null} />
          <div style={{ height: 14 }} />
          <QuoteResultCard expired />
        </div>
      </div>
    </PageBase>
  );
}

window.PageQuote = {
  variants: [
    { id: 'empty',     label: 'empty',                    Page: QuoteEmpty },
    { id: 'validated', label: 'validated · pre-submit',   Page: QuoteValidated },
    { id: 'invalid',   label: 'invalid · 3 form errors',  Page: QuoteInvalid },
    { id: 'loading',   label: 'requesting quote',         Page: QuoteLoading },
    { id: 'returned',  label: 'quote returned',           Page: QuoteReturned },
    { id: 'expired',   label: 'quote expired',            Page: QuoteExpired },
  ],
};
