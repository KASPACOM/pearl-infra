// Pearl OTC — sample trade data for mockups.
// Realistic-looking PRL bech32m addresses, Base 0x addresses, txids.

const PRL_BUYER_ADDR  = "prl1pzlfqvr3rg5pny5pk3w7v2g3q3p7d6t6mklqe9zr4t76uwmas20s8fkg7v";
const PRL_ESCROW_ADDR = "prl1pn4gxqzx4t4q2dye7yawd0kc7ynvtqj0wj9c4v5l7m0kfgs8lyq8mzkdr2";
const PRL_REFUND_ADDR = "prl1pl3w7v2g3q3p7d6t6mklqe9zr4t76uwmas20s8fkg7vzlfqvr3rg5pny5pk";

const BASE_BUYER_ADDR    = "0x7a4c8E2bAa5f1D9C3E04F7B6c9A2dB3e5fF6C8a4E";
const BASE_ESCROW_ADDR   = "0x9F2B4D5fA3eC1c6dD8B2F9c7AaE5b1D7f6A0c3B8";
const BASE_RECEIVE_ADDR  = "0x4eC2D8a3fB7d9C0e2A1F5b6c8D9E0F1A2B3C4D5E";

const PRL_FUND_TXID     = "f3c1a9b2d4e5f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2";
const PRL_RELEASE_TXID  = "a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8";
const PRL_REFUND_TXID   = "b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3";

const BASE_DEPOSIT_HASH = "0xc4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5";
const BASE_RELEASE_HASH = "0xa1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2";
const BASE_REFUND_HASH  = "0xe5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6";

const TRADE_KEY = "0x3b91...c7f4";   // short
const TRADE_KEY_FULL = "0x3b9142f6a8c0e7b5d2f1a9e4c8b3d6f0a5e7c2b9d4f1a8e3c6b0d5f2a7e9c7f4";

const TRADE_ID = "trd_01J5K8B2QHXV9P3Y";

const SAMPLE = {
  tradeId: TRADE_ID,
  side: "buy",
  amountPrl: { whole: "12,500", frac: ".000_000_00" },
  amountPrlPlain: "12,500.00000000",
  amountUsdc: { whole: "8,237", frac: ".500_000" },
  amountUsdcPlain: "8,237.500000",
  feePrl: "12.50000000",
  feeUsdc: "8.235000",
  price: "0.659000",
  pearlAddr: PRL_ESCROW_ADDR,
  baseEscrow: BASE_ESCROW_ADDR,
  tradeKey: TRADE_KEY,
  tradeKeyFull: TRADE_KEY_FULL,
  buyerPearl: PRL_BUYER_ADDR,
  buyerBase: BASE_BUYER_ADDR,
  baseReceive: BASE_RECEIVE_ADDR,
  fundTxid: PRL_FUND_TXID,
  releaseTxid: PRL_RELEASE_TXID,
  refundTxid: PRL_REFUND_TXID,
  depositHash: BASE_DEPOSIT_HASH,
  releaseHash: BASE_RELEASE_HASH,
  refundHash: BASE_REFUND_HASH,

  // Lifecycle markers (display strings)
  deadlines: {
    quote:       "00:42",
    pearlFund:   "00:23:14",
    usdcDeposit: "00:19:47",
    settlement:  "01:43:02",
    refundAvail: "—",
  },

  acceptedAt: "2026-05-17 14:22:08 UTC",
};

// State family → badge config
const STATE_BADGES = {
  quoted:                  { tone: "accent",  label: "quoted" },
  pearl_escrow_pending:    { tone: "neutral", label: "pearl_escrow_pending" },
  pearl_escrow_seen:       { tone: "accent",  label: "pearl_escrow_seen" },
  pearl_escrow_confirmed:  { tone: "ok",      label: "pearl_escrow_confirmed" },
  usdc_escrow_pending:     { tone: "neutral", label: "usdc_escrow_pending" },
  usdc_escrow_confirmed:   { tone: "ok",      label: "usdc_escrow_confirmed" },
  release_pending:         { tone: "accent",  label: "release_pending" },
  released:                { tone: "ok",      label: "released" },
  refund_available:        { tone: "warn",    label: "refund_available" },
  refund_pending:          { tone: "warn",    label: "refund_pending" },
  refunded:                { tone: "warn",    label: "refunded" },
  quote_expired:           { tone: "neutral", label: "quote_expired" },
  cancelled:               { tone: "neutral", label: "cancelled" },
  disputed:                { tone: "err",     label: "disputed" },
  failed_manual_review:    { tone: "err",     label: "failed_manual_review" },
  late_prl_funding:        { tone: "err",     label: "late_prl_funding" },
  usdc_refunded:           { tone: "warn",    label: "usdc_refunded" },
  prl_release_failed:      { tone: "err",     label: "prl_release_failed" },
  amount_mismatch:         { tone: "err",     label: "amount_mismatch" },
  reorged:                 { tone: "warn",    label: "reorged" },
  stale_indexer:           { tone: "warn",    label: "stale_indexer" },
  unknown_spend:           { tone: "err",     label: "unknown_spend" },
};

// Failure banner copy (per brief §8)
const FAILURE_BANNERS = {
  late_prl_funding:     { tone: "err",  head: "PRL was funded after the deadline. This trade will not auto-release." },
  usdc_refunded:        { tone: "warn", head: "USDC was refunded. PRL release is blocked." },
  prl_release_failed:   { tone: "err",  head: "PRL release transaction failed to broadcast. Manual review required." },
  amount_mismatch:      { tone: "err",  head: "Funded amount does not match the expected escrow amount." },
  reorged:              { tone: "warn", head: "A funding block was orphaned by a chain reorg. Awaiting re-confirmation." },
  stale_indexer:        { tone: "warn", head: "Indexer lag exceeds threshold. Status may be stale." },
  unknown_spend:        { tone: "err",  head: "Escrow output was spent by an unrecognized transaction. Audit pending." },
  failed_manual_review: { tone: "err",  head: "Trade flagged for manual review." },
  disputed:             { tone: "err",  head: "Trade is under dispute." },
};

// Timeline events for various states
const TL_EVENTS = {
  quoted: [
    { chain: "sys",  ev: "Quote issued", meta: "qte_01J5K8AB2 · 14:21:26 UTC", time: "2 min ago" },
  ],
  pearl_escrow_pending: [
    { chain: "sys",  ev: "Quote issued", meta: "qte_01J5K8AB2 · 14:21:26 UTC", time: "4 min ago" },
    { chain: "sys",  ev: "Quote accepted; escrows allocated", meta: "by buyer · 14:22:08 UTC", time: "3 min ago" },
  ],
  pearl_seen: [
    { chain: "sys",  ev: "Quote accepted; escrows allocated", meta: "14:22:08 UTC", time: "9 min ago" },
    { chain: "pearl", ev: "Pearl deposit observed", meta: "f3c1a9…f1a2 · 12,500.00000000 PRL", time: "6 min ago" },
    { chain: "pearl", ev: "Confirmation 1 of 6", meta: "block 18,432,901", time: "4 min ago" },
    { chain: "pearl", ev: "Confirmation 2 of 6", meta: "block 18,432,902", time: "3 min ago" },
    { chain: "pearl", ev: "Confirmation 3 of 6", meta: "block 18,432,903", time: "1 min ago" },
  ],
  both_confirming: [
    { chain: "sys",  ev: "Quote accepted; escrows allocated", meta: "14:22:08 UTC", time: "11 min ago" },
    { chain: "pearl", ev: "Pearl deposit observed", meta: "f3c1a9…f1a2", time: "8 min ago" },
    { chain: "pearl", ev: "Pearl deposit confirmed", meta: "6/6 confirmations", time: "3 min ago" },
    { chain: "base", ev: "USDC deposit observed", meta: "0xc4d5…c4d5", time: "2 min ago" },
    { chain: "base", ev: "Confirmation 4 of 12", meta: "block 21,007,442", time: "47s ago" },
  ],
  released: [
    { chain: "sys",  ev: "Quote accepted; escrows allocated", meta: "14:22:08 UTC", time: "23 min ago" },
    { chain: "pearl", ev: "Pearl deposit confirmed", meta: "6/6 confirmations", time: "16 min ago" },
    { chain: "base", ev: "USDC deposit confirmed", meta: "12/12 confirmations", time: "8 min ago" },
    { chain: "sys",  ev: "Release authorized", meta: "server-driven · idempotency 0x7e…2a", time: "3 min ago" },
    { chain: "pearl", ev: "PRL release broadcast", meta: "a7b8c9…a7b8", time: "2 min ago" },
    { chain: "base", ev: "USDC release broadcast", meta: "0xa1b2…a1b2", time: "1 min ago" },
    { chain: "ok",   ev: "Trade released", meta: "14:45:11 UTC", time: "just now" },
  ],
  failure_generic: [
    { chain: "sys",  ev: "Quote accepted; escrows allocated", meta: "14:22:08 UTC", time: "47 min ago" },
    { chain: "pearl", ev: "Pearl deposit observed", meta: "f3c1a9…f1a2", time: "38 min ago" },
    { chain: "pearl", ev: "Pearl deposit confirmed", meta: "6/6 confirmations", time: "31 min ago" },
    { chain: "err",  ev: "State entered: manual_review", meta: "system · 14:53:44 UTC", time: "12 min ago" },
  ],
};

// Admin list rows
const ADMIN_ROWS = [
  { id: "trd_01J5K8B2QHXV9P3Y", state: "pearl_escrow_pending", age: "2m",  prl: "12,500.00000000", usdc: "8,237.500000", side: "buy", flag: null },
  { id: "trd_01J5K7Z1M4NTBHGX", state: "released",             age: "14m", prl: "3,000.00000000",  usdc: "1,977.000000", side: "buy", flag: null },
  { id: "trd_01J5K7Y8VFJCQ2WP", state: "late_prl_funding",     age: "23m", prl: "8,000.00000000",  usdc: "5,272.000000", side: "buy", flag: "Funding 4m past deadline" },
  { id: "trd_01J5K7XKE3RMS4DA", state: "usdc_escrow_pending",  age: "31m", prl: "45,200.00000000", usdc: "29,786.800000",side: "sell",flag: null },
  { id: "trd_01J5K7W9QH8FLPCN", state: "released",             age: "47m", prl: "1,250.00000000",  usdc: "823.750000",   side: "buy", flag: null },
  { id: "trd_01J5K7VC2A9BHE6T", state: "amount_mismatch",      age: "1h",  prl: "10,000.00000000", usdc: "6,590.000000", side: "sell",flag: "Funded 9,998.4 PRL (-1.6)" },
  { id: "trd_01J5K7U6PXMK1DRQ", state: "released",             age: "1h",  prl: "500.00000000",    usdc: "329.500000",   side: "buy", flag: null },
  { id: "trd_01J5K7T0NWCG4PFE", state: "reorged",              age: "2h",  prl: "22,000.00000000", usdc: "14,498.000000",side: "buy", flag: "Block 18432901 orphaned" },
  { id: "trd_01J5K7S5HJDB3MUL", state: "refund_pending",       age: "2h",  prl: "6,750.00000000",  usdc: "4,448.250000", side: "sell",flag: null },
  { id: "trd_01J5K7R9F8AT2CXK", state: "stale_indexer",        age: "3h",  prl: "1,800.00000000",  usdc: "1,186.200000", side: "buy", flag: "Lag 42s" },
  { id: "trd_01J5K7Q3B4MV0KFP", state: "released",             age: "3h",  prl: "9,200.00000000",  usdc: "6,062.800000", side: "buy", flag: null },
  { id: "trd_01J5K7P7DC5HX1YN", state: "refunded",             age: "4h",  prl: "3,500.00000000",  usdc: "2,306.500000", side: "buy", flag: null },
];

window.PearlData = { SAMPLE, STATE_BADGES, FAILURE_BANNERS, TL_EVENTS, ADMIN_ROWS };
