// /admin/trades — operator shell · list + detail
// Darker chrome; pgAdmin/Linear-board feel; operators annotate, never release.

const { ADMIN_ROWS } = window.PearlData;

// ── List page ───────────────────────────────────────────────────────────────

function AdminFilters({ manualOnly = false }) {
  return (
    <div style={{
      display: 'flex', gap: 10, alignItems: 'center',
      padding: '14px 28px',
      background: 'var(--surface)',
      borderBottom: '1px solid var(--hairline)',
    }}>
      <div style={{ position: 'relative', flex: '0 0 280px' }}>
        <input className="input mono" placeholder="search by trade id…" readOnly style={{ paddingLeft: 30, fontSize: 11.5 }} />
        <span style={{ position: 'absolute', left: 10, top: 8, color: 'var(--muted-2)', fontFamily: 'var(--font-mono)', fontSize: 13 }}>⌕</span>
      </div>
      <span style={{ width: 1, height: 22, background: 'var(--hairline)' }} />
      <button className="btn sm">
        state <span style={{ marginLeft: 4 }} className="muted">▾</span>
      </button>
      <button className="btn sm">
        side <span style={{ marginLeft: 4 }} className="muted">▾</span>
      </button>
      <button className="btn sm">
        last 24h <span style={{ marginLeft: 4 }} className="muted">▾</span>
      </button>
      <label style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 12, color: manualOnly ? 'var(--err)' : 'var(--muted)', cursor: 'pointer' }}>
        <span style={{
          width: 28, height: 16, borderRadius: 8,
          background: manualOnly ? 'var(--err)' : 'var(--neutral-soft)',
          border: '1px solid ' + (manualOnly ? 'var(--err)' : 'var(--hairline)'),
          position: 'relative',
          transition: 'background .15s',
        }}>
          <span style={{
            position: 'absolute', top: 1,
            left: manualOnly ? 13 : 1,
            width: 12, height: 12,
            background: '#fff', borderRadius: '50%',
            transition: 'left .15s',
          }} />
        </span>
        manual review only
      </label>
      <div style={{ flex: 1 }} />
      <span className="muted" style={{ fontSize: 11, fontFamily: 'var(--font-mono)' }}>
        showing {manualOnly ? '4' : '12'} of 247
      </span>
      <button className="btn sm">↓ export</button>
    </div>
  );
}

function AdminListTable({ rows }) {
  return (
    <div style={{ padding: '0 28px' }}>
      <table className="tbl" style={{ background: 'var(--surface)', border: '1px solid var(--hairline)', borderRadius: 'var(--r-3)', marginTop: 18 }}>
        <thead>
          <tr>
            <th style={{ width: 220 }}>trade id</th>
            <th style={{ width: 200 }}>state</th>
            <th style={{ width: 50 }}>side</th>
            <th style={{ width: 60 }}>age</th>
            <th className="num">amount PRL</th>
            <th className="num">amount USDC</th>
            <th>manual review reason</th>
            <th style={{ width: 40 }}></th>
          </tr>
        </thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.id}>
              <td className="mono" style={{ fontSize: 11.5 }}>
                <a href="#" style={{ color: 'var(--accent)', textDecoration: 'none' }}>{r.id}</a>
              </td>
              <td><StateBadge state={r.state} /></td>
              <td style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted)' }}>{r.side}</td>
              <td className="mono" style={{ fontSize: 11, color: 'var(--muted)' }}>{r.age}</td>
              <td className="num" style={{ fontSize: 11.5 }}>{r.prl}</td>
              <td className="num" style={{ fontSize: 11.5 }}>{r.usdc}</td>
              <td style={{ fontSize: 11.5, color: r.flag ? 'var(--err)' : 'var(--muted-2)' }}>
                {r.flag || '—'}
              </td>
              <td>
                <button className="btn ghost sm" style={{ padding: '0 6px', height: 22 }}>···</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function AdminListShell({ rows, manualOnly = false }) {
  return (
    <div className="pearl" style={{ display: 'flex', flexDirection: 'column' }}>
      <Chrome path="/admin/trades" />
      <AdminTopNav active="trades" />
      <div style={{ flex: 1, overflow: 'auto' }}>
        <div style={{ padding: '22px 28px 4px' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
            <div>
              <div className="eyebrow" style={{ marginBottom: 6 }}>admin · operator shell</div>
              <h1 className="h1">All trades</h1>
            </div>
            <div style={{ display: 'flex', gap: 22, fontSize: 11 }}>
              {[
                ['active',     '47',  'var(--accent)'],
                ['manual_rev', '4',   'var(--err)'],
                ['released 24h', '193', 'var(--ok)'],
                ['refunded 24h', '6',   'var(--warn)'],
              ].map(([l, n, c]) => (
                <div key={l} style={{ textAlign: 'right' }}>
                  <div className="eyebrow" style={{ marginBottom: 2 }}>{l}</div>
                  <div className="mono" style={{ fontSize: 17, fontWeight: 500, color: c, fontVariantNumeric: 'tabular-nums' }}>{n}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <AdminFilters manualOnly={manualOnly} />
        <AdminListTable rows={rows} />
      </div>
    </div>
  );
}

const AdminListEmpty = () => (
  <div className="pearl" style={{ display: 'flex', flexDirection: 'column' }}>
    <Chrome path="/admin/trades" />
    <AdminTopNav active="trades" />
    <div style={{ flex: 1, overflow: 'auto' }}>
      <div style={{ padding: '22px 28px 4px' }}>
        <div className="eyebrow" style={{ marginBottom: 6 }}>admin · operator shell</div>
        <h1 className="h1">All trades</h1>
      </div>
      <AdminFilters />
      <div style={{ padding: '0 28px' }}>
        <div style={{
          background: 'var(--surface)', border: '1px dashed var(--hairline)',
          borderRadius: 'var(--r-3)', marginTop: 18,
          padding: '64px 28px', textAlign: 'center',
        }}>
          <div style={{
            width: 36, height: 36, margin: '0 auto 14px',
            borderRadius: '50%', background: 'var(--paper-2)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: 'var(--font-mono)', fontSize: 16, color: 'var(--muted-2)',
          }}>—</div>
          <div className="h2" style={{ marginBottom: 6 }}>No trades yet</div>
          <div className="muted" style={{ fontSize: 12, maxWidth: 380, margin: '0 auto', lineHeight: 1.5 }}>
            No quotes have been accepted in this environment. Trades will appear here within seconds of acceptance.
          </div>
        </div>
      </div>
    </div>
  </div>
);

const AdminListPopulated = () => <AdminListShell rows={ADMIN_ROWS} />;
const AdminListFiltered = () => (
  <AdminListShell
    rows={ADMIN_ROWS.filter(r => r.flag !== null)}
    manualOnly
  />
);

// ── Detail page ─────────────────────────────────────────────────────────────

function OpPanel({ expanded = false, failure }) {
  return (
    <aside className="opbar" style={{ width: 360, overflow: 'auto', padding: '20px 22px', flexShrink: 0 }}>
      <div style={{ marginBottom: 22 }}>
        <div className="eyebrow" style={{ marginBottom: 4 }}>operator</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ width: 24, height: 24, borderRadius: '50%', background: '#c4a87a', color: '#1a1a17', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 600 }}>MQ</span>
          <div style={{ fontSize: 12 }}>
            <div style={{ fontWeight: 500 }}>marcus.q <span className="muted" style={{ fontWeight: 400 }}>· op_07</span></div>
            <div className="muted" style={{ fontSize: 10.5, fontFamily: 'var(--font-mono)' }}>can: read, annotate</div>
          </div>
        </div>
      </div>

      <div style={{ marginBottom: 22, paddingBottom: 22, borderBottom: '1px solid var(--hairline)' }}>
        <div className="eyebrow" style={{ marginBottom: 8 }}>actions</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <button className="btn" style={{ justifyContent: 'flex-start' }}>
            <span style={{ width: 14, color: 'var(--warn)' }}>⚑</span> Flag for manual review
          </button>
          <button className="btn" style={{ justifyContent: 'flex-start' }}>
            <span style={{ width: 14 }}>📎</span> Attach note
          </button>
          <button className="btn" style={{ justifyContent: 'flex-start' }}>
            <span style={{ width: 14 }}>↗</span> Open on basescan
          </button>
        </div>
        <div className="help" style={{ marginTop: 10, fontSize: 10.5 }}>
          No release / refund buttons. Operators annotate; state transitions are server-side.
        </div>
      </div>

      <div style={{ marginBottom: 22 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
          <div className="eyebrow">record manual side-effect</div>
          {expanded ? (
            <span className="badge accent" style={{ fontSize: 9.5 }}><span className="dot" />open</span>
          ) : null}
        </div>

        {expanded ? (
          <div style={{ background: 'var(--surface-2)', border: '1px solid var(--hairline)', borderRadius: 'var(--r-2)', padding: '14px' }}>
            <div style={{ marginBottom: 10 }}>
              <label className="label">effect type</label>
              <div className="input" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontFamily: 'var(--font-mono)', fontSize: 11 }}>
                <span>manual_pearl_release</span><span className="muted">▾</span>
              </div>
            </div>
            <div style={{ marginBottom: 10 }}>
              <label className="label">tx hash / outpoint</label>
              <input className="input mono" placeholder="0x… or txid:vout" readOnly style={{ fontSize: 11 }} />
            </div>
            <div style={{ marginBottom: 10 }}>
              <label className="label">status</label>
              <div className="input" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontFamily: 'var(--font-mono)', fontSize: 11 }}>
                <span>broadcast_succeeded</span><span className="muted">▾</span>
              </div>
            </div>
            <div style={{ marginBottom: 10 }}>
              <label className="label">metadata (JSON)</label>
              <div style={{
                fontFamily: 'var(--font-mono)', fontSize: 10.5,
                background: '#0f0f0c', color: '#d6cfa3',
                padding: '8px 10px', borderRadius: 'var(--r-2)',
                lineHeight: 1.5, whiteSpace: 'pre',
              }}>{`{
  "reason": "manual broadcast after rpc",
  "actor_note": "verified utxo with node 3",
  "approval": "op_07 + op_03"
}`}</div>
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
              <button className="btn primary sm" style={{ flex: 1, justifyContent: 'center' }}>Submit side-effect</button>
              <button className="btn ghost sm">Cancel</button>
            </div>
            <div className="help" style={{ marginTop: 10, fontSize: 10.5 }}>
              Idempotency key auto-generated. Does not transition state; the indexer picks up the broadcast and re-derives state from on-chain truth.
            </div>
          </div>
        ) : (
          <button className="btn" style={{ width: '100%', justifyContent: 'center', borderStyle: 'dashed' }}>
            + record side-effect
          </button>
        )}
      </div>

      <div>
        <div className="eyebrow" style={{ marginBottom: 8 }}>audit log · last 5</div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 10.5, color: 'var(--muted)', lineHeight: 1.7 }}>
          <div><span style={{ color: 'var(--err)' }}>ERR</span> · 14:45:14 · pearl_release_retry_3 → failed</div>
          <div><span style={{ color: 'var(--err)' }}>ERR</span> · 14:44:14 · pearl_release_retry_2 → failed</div>
          <div><span style={{ color: 'var(--err)' }}>ERR</span> · 14:43:11 · pearl_release_retry_1 → failed</div>
          <div><span style={{ color: 'var(--err)' }}>ERR</span> · 14:42:14 · pearl_release_submitted → failed</div>
          <div><span style={{ color: 'var(--ok)' }}> OK</span> · 14:42:01 · release_authorized</div>
          <a href="#" style={{ display: 'inline-block', marginTop: 8, color: 'var(--accent)', fontFamily: 'var(--font-sans)' }}>see full audit log →</a>
        </div>
      </div>
    </aside>
  );
}

function AdminDetailShell({ failure, panelExpanded }) {
  const state = failure || 'pearl_escrow_pending';
  return (
    <div className="pearl" style={{ display: 'flex', flexDirection: 'column' }}>
      <Chrome path={`/admin/trades/${SAMPLE.tradeId}`} />
      <AdminTopNav active="trades" />
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        <div style={{ flex: 1, overflow: 'auto', borderRight: '1px solid var(--hairline)' }}>
          <TradeHeader state={state} />
          <div style={{ padding: '20px 24px 40px' }}>
            {failure && (
              <div style={{ marginBottom: 16 }}>
                <FailureBanner state={failure} />
              </div>
            )}
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14, padding: '8px 12px', background: 'var(--paper-2)', border: '1px solid var(--hairline)', borderRadius: 'var(--r-2)' }}>
              <span className="badge neutral" style={{ fontSize: 9.5 }}><span className="dot" />read-only</span>
              <span className="muted" style={{ fontSize: 11.5 }}>
                Customer view of /trades/{SAMPLE.tradeId} as seen by the buyer. Mirrors the checkout screen exactly — no interaction.
              </span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <PearlCard status={failure === 'prl_release_failed' ? 'confirmed' : (failure === 'amount_mismatch' ? 'mismatch' : 'pending')} />
              <BaseCard status={failure ? 'confirmed' : 'awaiting'} />
            </div>

            <div style={{ marginTop: 18 }}>
              <div className="card">
                <div className="card-header">
                  <span className="h2">Activity</span>
                  <span className="muted" style={{ fontSize: 11 }}>9 events · expanded view</span>
                </div>
                <div style={{ padding: '6px 18px 12px' }}>
                  <Timeline events={failure ? TL_EVENTS.failure_generic : TL_EVENTS.pearl_escrow_pending} />
                </div>
              </div>
            </div>
          </div>
        </div>
        <OpPanel expanded={panelExpanded} failure={failure} />
      </div>
    </div>
  );
}

const AdminDetailHappy = () => <AdminDetailShell />;
const AdminDetailFailure = () => <AdminDetailShell failure="prl_release_failed" panelExpanded />;

window.PageAdmin = {
  variants: [
    { id: 'list-empty',     label: 'list · empty environment',                  Page: AdminListEmpty,     height: 880 },
    { id: 'list-populated', label: 'list · populated · mixed states',           Page: AdminListPopulated, height: 880 },
    { id: 'list-filtered',  label: 'list · manual review only',                 Page: AdminListFiltered,  height: 880 },
    { id: 'detail-happy',   label: 'detail · pearl_escrow_pending',             Page: AdminDetailHappy,   height: 1120 },
    { id: 'detail-failure', label: 'detail · prl_release_failed · panel open',  Page: AdminDetailFailure, height: 1120 },
  ],
};
